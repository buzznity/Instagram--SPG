"""Buzznity Web UI bridge.
Runs beside the existing Telegram bot and uses the SAME database, scheduler,
and poster flow. It does not create a second Instagram automation engine.
"""
import os
import time
import threading
from datetime import datetime
from functools import wraps
from flask import Flask, jsonify, request, send_from_directory, render_template, session, redirect, url_for

import database as db
import session_store
from config import ACCOUNT_COUNT, ALLOWED_CHAT_ID, WEB_UI_HOST, WEB_UI_PORT, WEB_UI_TOKEN, DOWNLOAD_DIR, HIDE_LIKE_COUNTS

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, template_folder=os.path.join(BASE, 'web_ui', 'templates'),
            static_folder=os.path.join(BASE, 'web_ui', 'static'))
app.secret_key = os.getenv('WEB_SESSION_SECRET', 'change-this-buzznity-session-secret')
LOGIN_USERNAME = os.getenv('WEB_LOGIN_USERNAME', 'User')
LOGIN_PASSWORD = os.getenv('WEB_LOGIN_PASSWORD', 'SUDIPTA@1234')


def _auth_ok():
    if session.get('web_authenticated'):
        return True
    if WEB_UI_TOKEN:
        supplied = request.headers.get('X-Buzznity-Token') or request.args.get('token')
        return supplied == WEB_UI_TOKEN
    return False



@app.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('web_authenticated'):
        return redirect(url_for('index'))
    error = None
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        if username == LOGIN_USERNAME and password == LOGIN_PASSWORD:
            session.clear()
            session['web_authenticated'] = True
            session['web_user'] = username
            return redirect(url_for('index'))
        error = 'Invalid username or password.'
    return render_template('login.html', error=error)


@app.get('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


def protected(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not _auth_ok():
            return jsonify({'ok': False, 'error': 'Unauthorized'}), 401
        return fn(*args, **kwargs)
    return wrapper


def _accounts():
    out = []
    for acc in range(1, ACCOUNT_COUNT + 1):
        st = db.get_account_status(acc) or {'account': acc, 'status': 'unknown', 'username': None, 'last_checked': None}
        out.append(st)
    return out


def _jobs():
    rows = db.get_all_jobs(100)
    for r in rows:
        r['created_at_iso'] = datetime.fromtimestamp(r['created_at']).isoformat(timespec='seconds') if r.get('created_at') else None
        r['scheduled_for_iso'] = datetime.fromtimestamp(r['scheduled_for']).isoformat(timespec='minutes') if r.get('scheduled_for') else None
    return rows


@app.get('/')
@protected
def index():
    return render_template('index.html', account_count=ACCOUNT_COUNT)


@app.get('/api/dashboard')
@protected
def dashboard():
    jobs = _jobs()
    metrics = db.get_all_metrics(100)
    counts = {}
    for j in jobs:
        counts[j['status']] = counts.get(j['status'], 0) + 1
    return jsonify({
        'ok': True,
        'accounts': _accounts(),
        'jobs': jobs,
        'metrics': metrics,
        'counts': counts,
        'account_count': ACCOUNT_COUNT,
    })


@app.post('/api/jobs')
@protected
def create_job():
    account = request.form.get('account', type=int)
    caption = request.form.get('caption', '')
    schedule = request.form.get('scheduled_for', '').strip()
    file = request.files.get('video')

    if not account or account < 1 or account > ACCOUNT_COUNT:
        return jsonify({'ok': False, 'error': 'Invalid account'}), 400
    if not file or not file.filename:
        return jsonify({'ok': False, 'error': 'Video file is required'}), 400

    safe_name = os.path.basename(file.filename).replace(' ', '_')
    stamp = int(time.time() * 1000)
    path = os.path.join(DOWNLOAD_DIR, f'web_{stamp}_{safe_name}')
    file.save(path)

    scheduled_for = None
    if schedule:
        try:
            dt = datetime.fromisoformat(schedule)
            scheduled_for = dt.timestamp()
        except ValueError:
            try:
                scheduled_for = float(schedule)
            except ValueError:
                return jsonify({'ok': False, 'error': 'Invalid schedule time'}), 400

    job_id = db.create_job(
        chat_id=ALLOWED_CHAT_ID,
        account=account,
        video_path=path,
        caption=caption,
        scheduled_for=scheduled_for,
        hide_likes=int(HIDE_LIKE_COUNTS),
    )
    return jsonify({'ok': True, 'job_id': job_id})


@app.post('/api/accounts/add')
@protected
def add_account():
    data = request.get_json(silent=True) or {}
    try:
        account = int(data.get('account'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Invalid account slot'}), 400
    if account < 1 or account > ACCOUNT_COUNT:
        return jsonify({'ok': False, 'error': f'Account must be between 1 and {ACCOUNT_COUNT}'}), 400
    cookies = {k: str(data.get(k, '')).strip() for k in ('sessionid','csrftoken','ds_user_id','mid')}
    if not all(cookies.values()):
        return jsonify({'ok': False, 'error': 'sessionid, csrftoken, ds_user_id and mid are required'}), 400
    try:
        path = session_store.save_cookie_session(account, cookies)
        db.set_account_status(account, 'unknown', username=None)
        return jsonify({'ok': True, 'account': account, 'session_kind': 'cookie', 'path': os.path.basename(path)})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.delete('/api/accounts/<int:account>')
@protected
def delete_account(account):
    if account < 1 or account > ACCOUNT_COUNT:
        return jsonify({'ok': False, 'error': 'Invalid account'}), 400
    try:
        session_store.delete_session(account)
        db.set_account_status(account, 'no_session', username=None)
        return jsonify({'ok': True, 'account': account})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.post('/api/accounts/<int:account>/test')
@protected
def test_account(account):
    if account < 1 or account > ACCOUNT_COUNT:
        return jsonify({'ok': False, 'error': 'Invalid account'}), 400
    try:
        from health_checker import _check_account
        status, username = _check_account(account)
        if status != 'network_error':
            db.set_account_status(account, status, username=username)
        return jsonify({'ok': True, 'account': account, 'status': status, 'username': username})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.post('/api/jobs/<int:job_id>/cancel')
@protected
def cancel(job_id):
    job = db.get_job(job_id)
    if not job:
        return jsonify({'ok': False, 'error': 'Job not found'}), 404
    db.cancel_job(job_id)
    return jsonify({'ok': True})


def start_web_ui():
    def run():
        app.run(host=WEB_UI_HOST, port=WEB_UI_PORT, debug=False, use_reloader=False, threaded=True)
    thread = threading.Thread(target=run, name='buzznity-web-ui', daemon=True)
    thread.start()
    return thread
