"""
scheduler.py — background thread that:
  1. Publishes 'pending' jobs (posted immediately, but still rate-limited)
  2. Publishes 'scheduled' jobs once their time is due
  3. Enforces MIN_MINUTES_BETWEEN_POSTS per account
Runs inside the same process as the bot, started as a daemon thread.
"""
import threading
import time
import os
from telebot import types
from config import MIN_MINUTES_BETWEEN_POSTS, MAX_CONCURRENT_PUBLISHES
from logger import logger
import database as db
from poster import publish_reel, SessionExpiredError, ChallengeRequiredError, PublishError, PublishUncertainError

CHECK_INTERVAL_SECONDS = 10

# Shared across all _process_job threads — see MAX_CONCURRENT_PUBLISHES in
# config.py for why this exists. A plain module-level Semaphore is safe to
# share between threads without extra locking; that's exactly what it's for.
_PUBLISH_SEMAPHORE = threading.Semaphore(MAX_CONCURRENT_PUBLISHES)

# Telegram messages have a hard ~4096 character cap — a send_message() call
# over that limit throws instead of sending, which (if unhandled) silently
# swallows the very failure notification it was trying to deliver. Some
# Playwright TimeoutErrors embed their entire internal retry log (dozens of
# lines) in the exception text, easily blowing past this. Always truncate
# any exception text before it goes into a Telegram message body.
TELEGRAM_MSG_SAFE_LIMIT = 3500


def _short(text, limit=TELEGRAM_MSG_SAFE_LIMIT):
    text = str(text)
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n... (truncated, {len(text) - limit} more characters — see logs/buzznity.log)"


def _send_screenshot_if_any(bot, chat_id, account, exc):
    """If the exception carries a screenshot_path and/or elements_path (set
    by poster.py on failure), send them directly to Telegram instead of
    requiring a manual VPS file-manager trip to fetch them. Sends BOTH the
    immediate and (if present) delayed follow-up screenshot for an
    uncertain outcome — the page can still be settling right after an
    ambiguous click, so the later one sometimes shows something the first
    didn't catch yet."""
    for label, attr in (("debug screenshot", "screenshot_path"), ("~10s later", "screenshot_path_delayed")):
        shot = getattr(exc, attr, None)
        if shot and os.path.exists(shot):
            try:
                with open(shot, "rb") as f:
                    bot.send_photo(chat_id, f, caption=f"📸 Account {account} — {label}")
            except Exception as send_err:
                logger.warning(f"Could not send screenshot {shot} to chat {chat_id}: {send_err}")

    dump = getattr(exc, "elements_path", None)
    if dump and os.path.exists(dump):
        try:
            with open(dump, "rb") as f:
                bot.send_document(
                    chat_id, f,
                    caption=f"🔍 Account {account} — page elements at time of failure",
                )
        except Exception as send_err:
            logger.warning(f"Could not send element dump {dump} to chat {chat_id}: {send_err}")


def _render_progress_bar(percent):
    filled = int(round(percent / 10))
    filled = max(0, min(10, filled))
    return "█" * filled + "░" * (10 - filled)


def _process_job(job, bot):
    account = job["account"]
    # The MIN_MINUTES_BETWEEN_POSTS rate-limit check now happens in the
    # main loop, BEFORE status is flipped to 'publishing' and this function
    # is even called — see _loop() below. Doing it there instead of here
    # avoids a job getting stuck at 'publishing' with nothing actually
    # happening, since by the time this function runs the status has
    # already been committed.

    db.update_job(job["id"], status="publishing", attempts=job["attempts"] + 1)
    logger.info(f"Publishing job {job['id']} on account {account}")

    # Single message, edited in place as progress updates come in — much
    # cleaner in the chat than a new message per step.
    progress_state = {"percent": 0, "message_id": None}
    try:
        sent = bot.send_message(
            job["chat_id"],
            f"⏳ Account {account}: starting...\n{_render_progress_bar(0)} 0%",
        )
        progress_state["message_id"] = sent.message_id
    except Exception:
        pass

    success_already_sent = {"flag": False}

    def status_cb(msg, percent=None):
        if percent is not None:
            progress_state["percent"] = percent
        pct = progress_state["percent"]
        text = f"⏳ Account {account}: {_short(msg, 500)}\n{_render_progress_bar(pct)} {pct}%"
        try:
            if progress_state["message_id"] is not None:
                bot.edit_message_text(
                    text, chat_id=job["chat_id"], message_id=progress_state["message_id"]
                )
            else:
                bot.send_message(job["chat_id"], text)
        except Exception:
            # Edits can fail harmlessly (e.g. identical text, or the
            # message is too old) — never let a status update crash the
            # actual publish flow.
            pass

        # Fire the celebratory success message the MOMENT Share is
        # confirmed, not after publish_reel() fully returns — there's a
        # ~60s post-publish profile-verification screenshot step after
        # this point (PUBLISH_VERIFY_DELAY_SECONDS) that used to delay the
        # "success" notification by that whole extra minute for no good
        # reason. The verification screenshot still arrives afterward as
        # a bonus confirmation, it just doesn't block this message anymore.
        if msg.startswith("Publish confirmed") and not success_already_sent["flag"]:
            success_already_sent["flag"] = True
            bot.send_message(job["chat_id"], f"🎉 Reel published successfully on Account {account}!")

    def screenshot_cb(path, msg):
        # Always wired up (not gated by DEBUG_SCREENSHOTS) since
        # poster.py now also uses this for the final post-publish profile
        # verification screenshot, which should always be sent. When
        # DEBUG_SCREENSHOTS=true, poster.py additionally calls this for
        # every intermediate step too, so the whole flow can be watched
        # screen by screen.
        try:
            with open(path, "rb") as f:
                bot.send_photo(job["chat_id"], f, caption=f"Account {account}: {msg}")
        except Exception as e:
            logger.warning(f"Could not send screenshot {path}: {e}")

    def document_cb(path, msg):
        # Same idea as screenshot_cb but for non-image debug files (the
        # page-elements .txt dumps), which Telegram won't accept via
        # send_photo.
        try:
            with open(path, "rb") as f:
                bot.send_document(job["chat_id"], f, caption=f"Account {account}: {msg}")
        except Exception as e:
            logger.warning(f"Could not send document {path}: {e}")

    keep_video_file = False  # set True only for the "uncertain outcome" case

    # job["hide_likes"] is 0/1/None from SQLite — None means "use the .env
    # global default" (poster.py handles that fallback itself).
    hide_likes = job.get("hide_likes")
    if hide_likes is not None:
        hide_likes = bool(hide_likes)

    try:
        # MAX_CONCURRENT_PUBLISHES limit — only the actual browser session
        # (the resource-heavy part) needs to wait for a slot, not any of
        # the bookkeeping above/below it. A non-blocking check first, so a
        # clear "waiting for a slot" message goes out immediately instead
        # of the person just seeing silence while this blocks.
        if not _PUBLISH_SEMAPHORE.acquire(blocking=False):
            logger.info(
                f"[account {account}] Waiting for a free publish slot "
                f"(MAX_CONCURRENT_PUBLISHES={MAX_CONCURRENT_PUBLISHES})..."
            )
            try:
                bot.send_message(
                    job["chat_id"],
                    f"⏳ Account {account}: waiting for a free slot — another "
                    f"account's post is using the VPS's browser capacity right now...",
                )
            except Exception:
                pass
            _PUBLISH_SEMAPHORE.acquire(blocking=True)
        try:
            publish_reel(
                account, job["video_path"], job["caption"],
                status_cb=status_cb,
                screenshot_cb=screenshot_cb,
                document_cb=document_cb,
                hide_likes=hide_likes,
            )
        finally:
            _PUBLISH_SEMAPHORE.release()
        db.update_job(job["id"], status="done", error=None)
        db.record_post(account, job_id=job["id"])
        if not success_already_sent["flag"]:
            # Fallback, e.g. if the exact "Publish confirmed" wording ever
            # changes — never leave the person with NO success message.
            bot.send_message(
                job["chat_id"],
                f"🎉 Reel published successfully on Account {account}!",
            )
    except SessionExpiredError as e:
        db.update_job(job["id"], status="failed", error=str(e))
        bot.send_message(
            job["chat_id"],
            f"❌ Session expired for Account {account}. Run login.py to re-authenticate, "
            f"then resend the video.",
        )
    except ChallengeRequiredError as e:
        db.update_job(job["id"], status="failed", error=str(e))
        bot.send_message(
            job["chat_id"],
            f"🚫 Account {account}: Instagram has flagged this account with a checkpoint/"
            f"challenge/restriction. {_short(e)}\n\nThis requires manual action in a real "
            f"browser — automated retries will not fix it and may look worse to Instagram.",
        )
        _send_screenshot_if_any(bot, job["chat_id"], account, e)
    except PublishUncertainError as e:
        # Deliberately NOT auto-retried and NOT marked plain "failed" — this
        # needs a human to check the account before anyone resends the video,
        # or a duplicate post is likely. The video file is kept (not deleted
        # below) so it can be resent once a human confirms it's safe.
        keep_video_file = True
        db.update_job(job["id"], status="needs_review", error=str(e))
        # Review buttons right here, not just buried in /status — one less
        # step than checking /status separately to find them.
        review_markup = types.InlineKeyboardMarkup(row_width=2)
        review_markup.add(
            types.InlineKeyboardButton(
                "✅ Checked — not posted, retry", callback_data=f"review_retry_{job['id']}"
            ),
            types.InlineKeyboardButton("🗑️ Discard", callback_data=f"review_discard_{job['id']}"),
        )
        bot.send_message(
            job["chat_id"],
            f"⚠️ Account {account}: publish outcome UNKNOWN. {_short(e)}\n\n"
            f"Please check the account manually. Do NOT resend this video until you've "
            f"confirmed whether it already posted — resending an already-posted reel "
            f"will duplicate it.",
            reply_markup=review_markup,
        )
        _send_screenshot_if_any(bot, job["chat_id"], account, e)
    except PublishError as e:
        # Keep the video file after a failure (not just the "uncertain"
        # case) — PublishError specifically means nothing was posted, so
        # there's no duplicate-post risk in keeping it, and having it
        # around makes debugging (checking the file itself, or manually
        # retrying) much easier than needing to re-upload from scratch.
        keep_video_file = True
        db.update_job(job["id"], status="failed", error=str(e))
        bot.send_message(
            job["chat_id"],
            f"❌ Publish failed for Account {account}: {_short(e)}\n\n"
            f"(Video file kept on the VPS at {job['video_path']} for inspection — "
            f"it won't auto-retry further. Delete it manually once you're done "
            f"checking it, or resend the video fresh to try again.)",
        )
        _send_screenshot_if_any(bot, job["chat_id"], account, e)
    except Exception as e:
        keep_video_file = True
        db.update_job(job["id"], status="failed", error=str(e))
        logger.exception(f"Unexpected error on job {job['id']}")
        bot.send_message(job["chat_id"], f"❌ Unexpected error on Account {account}: {_short(e)}")
    finally:
        if not keep_video_file and os.path.exists(job["video_path"]):
            try:
                os.remove(job["video_path"])
            except OSError:
                pass
    return True


def _loop(bot):
    logger.info("Scheduler thread started.")
    while True:
        try:
            with db.get_conn() as conn:
                rows = conn.execute(
                    "SELECT * FROM jobs WHERE status='pending'"
                ).fetchall()
                pending = [dict(r) for r in rows]
            due_scheduled = db.get_due_scheduled_jobs()

            for job in pending + due_scheduled:
                # Not due yet under MIN_MINUTES_BETWEEN_POSTS — check
                # BEFORE flipping status, so it correctly stays 'pending'
                # for the next cycle to re-check, instead of getting stuck
                # at 'publishing' with nothing actually happening.
                minutes_since = db.minutes_since_last_post(job["account"])
                if minutes_since is not None and minutes_since < MIN_MINUTES_BETWEEN_POSTS:
                    continue

                # Different accounts can safely publish at the same time —
                # each has its own browser session, and account_lock (used
                # deep inside poster.py) is keyed per-account-number, so
                # there's no correctness reason to serialize across
                # DIFFERENT accounts. Same-account jobs are still safe:
                # account_lock makes a second thread for the SAME account
                # simply wait its turn there, exactly as before — this
                # only adds real parallelism across different accounts.
                #
                # Flip to 'publishing' HERE, synchronously, before handing
                # off to a thread — closes a race where the next polling
                # cycle (CHECK_INTERVAL_SECONDS later) could otherwise pick
                # up the same still-'pending' job a second time if its
                # thread hadn't started running yet.
                db.update_job(job["id"], status="publishing")
                threading.Thread(target=_process_job, args=(job, bot), daemon=True).start()
        except Exception:
            logger.exception("Scheduler loop error")
        time.sleep(CHECK_INTERVAL_SECONDS)


def start_scheduler(bot):
    t = threading.Thread(target=_loop, args=(bot,), daemon=True)
    t.start()
    return t
