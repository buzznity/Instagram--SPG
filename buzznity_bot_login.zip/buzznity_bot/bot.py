# bot.py — Telegram control panel for the Instagram reel publisher.
import os
import re
import time
import json
import datetime
import threading
import requests
import telebot
from telebot import types, apihelper

from config import (
    BOT_TOKEN, ALLOWED_CHAT_ID, DOWNLOAD_DIR, ACCOUNT_COUNT, HIDE_LIKE_COUNTS,
    MAX_URL_VIDEO_MB, URL_DOWNLOAD_TIMEOUT_SECONDS, VIDEO_ENHANCE, BASE_DIR,
)
from logger import logger
import database as db
import session_store
import analytics
import poster
import video_enhance
import instagram_source
from scheduler import start_scheduler, _short
from web_ui import start_web_ui
from health_checker import start_health_checker
from video_check import validate_video

# Without an explicit timeout, a stalled network call (e.g. sending a large
# screenshot over a slow VPS connection) can hang the underlying HTTP
# request indefinitely — and since publishing runs sequentially in the
# scheduler thread, that hang blocks EVERY future job too, not just the
# current one, with no error and no log line to explain why. Seen directly
# in production: "Publish confirmed" logged, then nothing for 12+ minutes
# until the process was killed. These caps turn a silent infinite hang into
# a normal, catchable timeout error instead.
apihelper.READ_TIMEOUT = 30
apihelper.CONNECT_TIMEOUT = 15

db.init_db()
bot = telebot.TeleBot(BOT_TOKEN)


def _get_chat_id(message_or_call):
    return message_or_call.chat.id if hasattr(message_or_call, "chat") else message_or_call.message.chat.id


def is_owner(message_or_call):
    """The single .env-configured ALLOWED_CHAT_ID — the only one who can
    add/remove other admins, so an added admin can never chain-add others
    on their own."""
    return _get_chat_id(message_or_call) == ALLOWED_CHAT_ID


def is_authorized(message_or_call):
    """Owner, or anyone the owner has explicitly added via /addadmin."""
    chat_id = _get_chat_id(message_or_call)
    return chat_id == ALLOWED_CHAT_ID or db.is_admin(chat_id)


def account_exists(account_num):
    return session_store.session_kind(account_num) is not None


def _try_delete(message):
    """Best-effort delete of a message that contained a live session cookie.
    Never raises — Telegram sometimes refuses deletion (message too old,
    bot lacks delete rights in some chat types), and that must not break
    the flow, just leave the message visible."""
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception as e:
        logger.info(f"Could not delete cookie-input message {message.message_id}: {e}")


# ---------------- Commands ----------------

def _main_keyboard(show_owner_row=False):
    """Persistent bottom keyboard — stays visible across the conversation
    so the common commands are one tap away instead of typed."""
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    kb.add(
        types.KeyboardButton("📊 Status"),
        types.KeyboardButton("📈 Analytics"),
    )
    kb.add(
        types.KeyboardButton("📷 Quick Report"),
        types.KeyboardButton("➕ Add Account"),
    )
    kb.add(
        types.KeyboardButton("🗑️ Delete Post"),
        types.KeyboardButton("❌ Cancel"),
    )
    if show_owner_row:
        kb.add(types.KeyboardButton("🔑 Set OpenRouter Key"))
    kb.add(types.KeyboardButton("❓ Help"))
    return kb


@bot.message_handler(commands=["start", "help"])
def send_welcome(message):
    if not is_authorized(message):
        return
    bot.reply_to(
        message,
        "👋 *Instagram Reel Publisher*\n\n"
        "Send a reel video (MP4) — uploaded directly, as a direct *.mp4 link* "
        "(bypasses Telegram's 20MB upload cap), or an *Instagram Reel link* "
        "(downloads it with the original caption, for content you own or "
        "are authorized to repost) — to begin.\n\n"
        "Or use the buttons below — they cover the same commands "
        "(/status, /analytics, /addaccount, /cancel, /deletepost) without typing."
        + ("\n\nAs the owner, you can also:\n"
           "/addadmin <user_id> — let someone else use this bot too\n"
           "/removeadmin <user_id> — revoke their access\n"
           "/listadmins — see who currently has access" if is_owner(message) else ""),
        parse_mode="Markdown",
        reply_markup=_main_keyboard(show_owner_row=is_owner(message)),
    )


def _write_openrouter_key(new_key):
    """Shared by both /setopenrouterkey and the button-driven flow. Writes
    (or replaces) OPENROUTER_API_KEY in .env. Raises on failure."""
    env_path = os.path.join(BASE_DIR, ".env")
    with open(env_path, "r") as f:
        lines = f.readlines()
    found = False
    for i, line in enumerate(lines):
        if line.startswith("OPENROUTER_API_KEY="):
            lines[i] = f"OPENROUTER_API_KEY={new_key}\n"
            found = True
            break
    if not found:
        lines.append(f"OPENROUTER_API_KEY={new_key}\n")
    with open(env_path, "w") as f:
        f.writelines(lines)


@bot.message_handler(commands=["setopenrouterkey"])
def cmd_set_openrouter_key(message):
    # Owner-only — this is a billed credential, same sensitivity level as
    # the bot token itself.
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can change this.")
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2 or not parts[1].strip():
        bot.reply_to(
            message,
            "Usage: /setopenrouterkey <your_key>\n\nGet a key at https://openrouter.ai/keys — "
            "paste it here and I'll delete this message right after reading it, same as the "
            "/addaccount cookie flow.",
        )
        return
    new_key = parts[1].strip()

    try:
        _write_openrouter_key(new_key)
    except Exception as e:
        bot.reply_to(message, f"❌ Couldn't update .env: {_short(str(e), 500)}")
        return

    # Delete the message containing the live key immediately — same
    # safety practice as /addaccount's cookie values.
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception as e:
        logger.info(f"Could not delete OpenRouter key message: {e}")

    bot.send_message(
        message.chat.id,
        "✅ OpenRouter API key updated in .env (and the message with the key was deleted).\n\n"
        "⚠️ Restart for it to take effect: `sudo systemctl restart buzznity-bot`",
        parse_mode="Markdown",
    )


@bot.message_handler(func=lambda m: m.text == "🔑 Set OpenRouter Key")
def kb_set_openrouter_key(message):
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can change this.")
        return
    msg = bot.reply_to(
        message,
        "🔑 Paste your OpenRouter API key (from https://openrouter.ai/keys). "
        "I'll delete your message right after reading it, since it's a live credential.",
    )
    bot.register_next_step_handler(msg, _handle_openrouter_key_step)


def _handle_openrouter_key_step(message):
    if not is_owner(message):
        return
    new_key = (message.text or "").strip()
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception as e:
        logger.info(f"Could not delete OpenRouter key message: {e}")

    if not new_key:
        bot.send_message(message.chat.id, "That was empty — nothing changed. Try 🔑 Set OpenRouter Key again.")
        return
    try:
        _write_openrouter_key(new_key)
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Couldn't update .env: {_short(str(e), 500)}")
        return

    bot.send_message(
        message.chat.id,
        "✅ OpenRouter API key updated in .env (your message with the key was deleted).\n\n"
        "⚠️ Restart for it to take effect: `sudo systemctl restart buzznity-bot`",
        parse_mode="Markdown",
    )


@bot.message_handler(commands=["addadmin"])
def cmd_add_admin(message):
    # Owner-only — an added admin can use the bot but can never add/remove
    # other admins themselves, so access can't silently chain-expand.
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can add admins.")
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].lstrip("-").isdigit():
        bot.reply_to(
            message,
            "Usage: /addadmin <user_id> [label]\n\n"
            "The person can get their own numeric user ID by messaging "
            "@userinfobot on Telegram.",
        )
        return
    new_chat_id = int(parts[1])
    label = " ".join(parts[2:]) if len(parts) > 2 else None
    db.add_admin(new_chat_id, added_by=message.chat.id, label=label)
    bot.reply_to(message, f"✅ Added {new_chat_id}{f' ({label})' if label else ''} as an admin.")
    try:
        bot.send_message(
            new_chat_id,
            "👋 You've been added as an admin on the Instagram Reel Publisher bot. "
            "Send /start to see what you can do.",
        )
    except Exception as e:
        logger.info(f"Could not DM new admin {new_chat_id} (they may not have started the bot yet): {e}")


@bot.message_handler(commands=["removeadmin"])
def cmd_remove_admin(message):
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can remove admins.")
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].lstrip("-").isdigit():
        bot.reply_to(message, "Usage: /removeadmin <user_id>")
        return
    target = int(parts[1])
    if db.remove_admin(target):
        bot.reply_to(message, f"✅ Removed {target} as an admin.")
    else:
        bot.reply_to(message, f"{target} wasn't an admin.")


@bot.message_handler(commands=["listadmins"])
def cmd_list_admins(message):
    if not is_authorized(message):
        return
    lines = [f"👑 Owner: {ALLOWED_CHAT_ID}"]
    for a in db.list_admins():
        tag = f" ({a['label']})" if a.get("label") else ""
        lines.append(f"👤 {a['chat_id']}{tag}")
    bot.reply_to(message, "\n".join(lines))


def _send_analytics_picker(chat_id):
    markup = types.InlineKeyboardMarkup(row_width=1)
    any_account = False
    for i in range(1, ACCOUNT_COUNT + 1):
        if account_exists(i):
            any_account = True
            markup.add(types.InlineKeyboardButton(f"👤 Account {i}", callback_data=f"analytics_acc_{i}"))
    if not any_account:
        bot.send_message(
            chat_id,
            "No accounts have a saved session yet — use /addaccount or login.py first.",
        )
        return
    bot.send_message(chat_id, "📊 Which account?", reply_markup=markup)


def _send_quick_report_picker(chat_id):
    markup = types.InlineKeyboardMarkup(row_width=1)
    any_account = False
    for i in range(1, ACCOUNT_COUNT + 1):
        if account_exists(i):
            any_account = True
            markup.add(types.InlineKeyboardButton(f"👤 Account {i}", callback_data=f"quickreport_acc_{i}"))
    if not any_account:
        bot.send_message(
            chat_id,
            "No accounts have a saved session yet — use /addaccount or login.py first.",
        )
        return
    bot.send_message(chat_id, "📷 Which account?", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("quickreport_acc_"))
def quick_report_pick(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[-1])
    if not account_exists(account_num):
        bot.send_message(call.message.chat.id, f"❌ No saved session for Account {account_num}.")
        return

    chat_id = call.message.chat.id
    bot.send_message(chat_id, f"📷 Getting Account {account_num}'s current snapshot...")

    def run():
        def screenshot_cb(path, msg):
            try:
                with open(path, "rb") as f:
                    bot.send_photo(chat_id, f, caption=msg)
            except Exception as e:
                logger.warning(f"[quick_report] screenshot_cb failed: {e}")

        try:
            stats = analytics.quick_profile_report(account_num, screenshot_cb=screenshot_cb)
        except Exception as e:
            bot.send_message(chat_id, f"❌ Couldn't get a snapshot for Account {account_num}: {_short(str(e), 1000)}")
            return

        username = stats.get("username")
        lines = [f"📷 Account {account_num}" + (f" (@{username})" if username else "")]
        if stats.get("followers") is not None:
            lines.append(f"👥 {stats['followers']:,} followers")
        if stats.get("following") is not None:
            lines.append(f"➡️ {stats['following']:,} following")
        if stats.get("posts") is not None:
            lines.append(f"🎞️ {stats['posts']:,} total posts")
        bot.send_message(chat_id, "\n".join(lines))

    threading.Thread(target=run, daemon=True).start()


@bot.callback_query_handler(func=lambda call: call.data == "analytics_menu")
def analytics_menu(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    _send_analytics_picker(call.message.chat.id)


@bot.message_handler(commands=["cancel"])
def cancel_flow(message):
    if not is_authorized(message):
        return
    state = db.get_user_state(message.chat.id)
    if state and state.get("video_path") and os.path.exists(state["video_path"]):
        try:
            os.remove(state["video_path"])
        except OSError:
            pass
    db.clear_user_state(message.chat.id)
    bot.reply_to(message, "❌ Current flow cancelled.")


# ---------------- Add account via pasted cookies ----------------
# Alternative to running login.py: paste the 4 core Instagram session
# cookies (from a browser's dev tools) instead. Each value is asked for
# separately and the message containing it is deleted immediately after
# being read, since these are live login credentials sitting in Telegram's
# chat history otherwise. Less robust than login.py's full browser profile
# (see session_store.py), but faster to set up.
_COOKIE_PROMPTS = {
    "sessionid": "🔑 Step 1/4 — paste the *sessionid* cookie value:",
    "csrftoken": "🔑 Step 2/4 — paste the *csrftoken* cookie value:",
    "ds_user_id": "🔑 Step 3/4 — paste the *ds_user_id* cookie value:",
    "mid": "🔑 Step 4/4 — paste the *mid* cookie value:",
}
_COOKIE_ORDER = list(_COOKIE_PROMPTS.keys())


@bot.message_handler(commands=["addaccount"])
def add_account_start(message):
    if not is_authorized(message):
        return
    existing = db.get_user_state(message.chat.id)
    if existing and existing.get("video_path"):
        bot.reply_to(message, "⚠️ You have an unfinished post in progress. Send /cancel first.")
        return

    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in range(1, ACCOUNT_COUNT + 1):
        tag = " (already has a session — this will overwrite it)" if account_exists(i) else ""
        markup.add(types.InlineKeyboardButton(f"👤 Account {i}{tag}", callback_data=f"addacc_{i}"))

    note = ""
    if all(account_exists(i) for i in range(1, ACCOUNT_COUNT + 1)):
        note = (
            f"\n\nℹ️ All {ACCOUNT_COUNT} configured account slot(s) already have a session. "
            f"To add a genuinely NEW account (not overwrite one of these), first increase "
            f"ACCOUNT_COUNT in .env on the VPS (e.g. `nano .env`, set it one higher, then "
            f"`sudo systemctl restart buzznity-bot`) — then run /addaccount again and the "
            f"new number will show up here."
        )
    bot.reply_to(
        message,
        "Which account number is this session for?\n\n"
        "You'll be asked to paste 4 values from Instagram's cookies "
        "(sessionid, csrftoken, ds_user_id, mid — from your browser's dev tools, "
        "Application → Cookies → instagram.com).\n\n"
        "⚠️ Each message you send will be deleted right after I read it, since "
        "these are live login credentials." + note,
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("addacc_"))
def add_account_choose(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[1])
    # The "caption" column is repurposed here purely as scratch storage for
    # the cookie values collected so far (JSON-encoded) — it has no
    # relation to a post caption during this flow.
    db.set_user_state(
        call.message.chat.id, video_path=None, account=account_num,
        caption=json.dumps({}), stage="add_account:sessionid",
    )
    msg = bot.send_message(
        call.message.chat.id, _COOKIE_PROMPTS["sessionid"], parse_mode="Markdown"
    )
    bot.register_next_step_handler(msg, _handle_cookie_step)


def _handle_cookie_step(message):
    if not is_authorized(message):
        return
    state = db.get_user_state(message.chat.id)
    if not state or not state.get("stage", "").startswith("add_account:"):
        _try_delete(message)
        bot.reply_to(message, "Session lost, please run /addaccount again.")
        return

    current_field = state["stage"].split(":", 1)[1]
    value = message.text.strip() if message.text else ""
    _try_delete(message)  # delete the credential immediately, success or not

    if not value:
        msg = bot.send_message(
            message.chat.id,
            f"That was empty — {_COOKIE_PROMPTS[current_field]}",
            parse_mode="Markdown",
        )
        bot.register_next_step_handler(msg, _handle_cookie_step)
        return

    collected = json.loads(state.get("caption") or "{}")
    collected[current_field] = value

    next_index = _COOKIE_ORDER.index(current_field) + 1
    if next_index < len(_COOKIE_ORDER):
        next_field = _COOKIE_ORDER[next_index]
        db.set_user_state(
            message.chat.id, caption=json.dumps(collected), stage=f"add_account:{next_field}"
        )
        msg = bot.send_message(message.chat.id, _COOKIE_PROMPTS[next_field], parse_mode="Markdown")
        bot.register_next_step_handler(msg, _handle_cookie_step)
        return

    # All 4 values collected — save and clean up.
    account_num = state["account"]
    try:
        session_store.save_cookie_session(account_num, collected)
    except ValueError as e:
        bot.send_message(message.chat.id, f"❌ Couldn't save session: {e}. Run /addaccount to try again.")
        db.clear_user_state(message.chat.id)
        return

    db.clear_user_state(message.chat.id)
    logger.info(f"Cookie-based session saved for account {account_num} via Telegram.")
    bot.send_message(
        message.chat.id,
        f"✅ Session saved for Account {account_num}. The credential messages above have been "
        f"deleted from this chat. Use /status to check it's recognized as logged in — the "
        f"next health check (or a manual test post) will confirm it's actually valid.",
    )


@bot.message_handler(commands=["analytics"])
def cmd_analytics(message):
    if not is_authorized(message):
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].isdigit():
        bot.reply_to(message, "Usage: /analytics <account_number>, e.g. /analytics 1")
        return
    account_num = int(parts[1])
    if not account_exists(account_num):
        bot.reply_to(message, f"❌ No saved session for Account {account_num}.")
        return
    _run_analytics(message.chat.id, account_num)


@bot.callback_query_handler(func=lambda call: call.data.startswith("analytics_acc_"))
def analytics_button_pick(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[-1])
    if not account_exists(account_num):
        bot.send_message(call.message.chat.id, f"❌ No saved session for Account {account_num}.")
        return
    _run_analytics(call.message.chat.id, account_num)


def _run_analytics(chat_id, account_num):
    """Shared by both the /analytics command and the 📊 Analytics button —
    keeps the two entry points from drifting out of sync. Purely
    additive/read-only: does not touch anything in the posting flow
    (bot.py's video/caption/account-checkbox handlers, poster.py,
    scheduler.py) — a completely separate feature living alongside it."""
    progress_msg = bot.send_message(
        chat_id,
        f"📊 Checking Account {account_num}'s recent posts — this opens a real browser "
        f"session and opens each post individually to read its view count, so it can take "
        f"a few minutes for an account with many posts...",
    )

    def run():
        def status_cb(msg):
            try:
                bot.edit_message_text(f"📊 Account {account_num}: {msg}", chat_id, progress_msg.message_id)
            except Exception:
                pass  # e.g. identical text, or message too old — harmless, just skip this update

        def screenshot_cb(path, msg):
            try:
                with open(path, "rb") as f:
                    bot.send_photo(chat_id, f, caption=msg)
            except Exception as e:
                logger.warning(f"[analytics] screenshot_cb failed: {e}")

        def document_cb(path, msg):
            try:
                with open(path, "rb") as f:
                    bot.send_document(chat_id, f, caption=msg)
            except Exception as e:
                logger.warning(f"[analytics] document_cb failed: {e}")

        try:
            profile_stats, entries = analytics.scrape_recent_posts(
                account_num, status_cb=status_cb, screenshot_cb=screenshot_cb, document_cb=document_cb
            )
        except Exception as e:
            bot.send_message(
                chat_id,
                f"❌ Couldn't fetch analytics for Account {account_num}: {_short(str(e), 1500)}",
            )
            return

        if not entries:
            bot.send_message(chat_id, f"No posts found for Account {account_num}.")
            return

        db.save_post_metrics(account_num, entries)

        username = profile_stats.get("username")
        header = f"📊 Account {account_num}" + (f" (@{username})" if username else " — ⚠️ username not detected")
        lines = [header]
        followers = profile_stats.get("followers")
        posts_total = profile_stats.get("posts")
        if followers is not None or posts_total is not None:
            stat_bits = []
            if followers is not None:
                stat_bits.append(f"{followers:,} followers")
            if posts_total is not None:
                stat_bits.append(f"{posts_total:,} total posts")
            lines.append(" · ".join(stat_bits))
        lines.append(f"\nAll {len(entries)} post(s) checked:")
        if posts_total is not None and len(entries) < posts_total:
            lines.append(
                f"⚠️ Profile shows {posts_total} total posts, but only {len(entries)} loaded "
                f"after scrolling — the rest may need a retry."
            )
        for i, e in enumerate(entries, 1):
            v = f"{e['views']:,}" if e.get("views") is not None else "?"
            tag = " 🔥 likely viral" if e.get("is_likely_viral") else ""
            lines.append(f"{i}. 👁️ {v} views{tag}")
        bot.send_message(chat_id, _short("\n".join(lines)))

        summary = analytics.summarize_with_ai(account_num, profile_stats, entries)
        if summary:
            bot.send_message(chat_id, f"🤖 AI insight:\n\n{_short(summary, 3500)}")
        else:
            bot.send_message(
                chat_id,
                "(Set OPENROUTER_API_KEY in .env to also get an AI-generated summary of "
                "these numbers — see .env.example.)",
            )

    # Scraping opens a real browser and can take a while — run it off the
    # main bot thread so /status, /addaccount etc. stay responsive
    # meanwhile, same reasoning as the scheduler running in its own thread.
    threading.Thread(target=run, daemon=True).start()


_STATUS_ICON = {
    "logged_in": "✅",
    "expired": "⚠️",
    "challenge": "🚫",
    "no_session": "➖",
    None: "❔",
}


@bot.message_handler(commands=["status"])
def show_status(message):
    if not is_authorized(message):
        return

    account_lines = []
    for acc in range(1, ACCOUNT_COUNT + 1):
        row = db.get_account_status(acc)
        status = row["status"] if row else None
        username = row.get("username") if row else None
        label = f"Account {acc}" + (f" (@{username})" if username else "")
        account_lines.append(f"{_STATUS_ICON.get(status, '❔')} {label}: {status or 'not checked yet'}")

    jobs = db.get_pending_jobs_for_chat(message.chat.id)
    text = "👤 Account health:\n" + "\n".join(account_lines)

    if not jobs:
        text += "\n\nNo pending, scheduled, or review-needed jobs."
        bot.reply_to(message, text)
        return

    lines = []
    for j in jobs:
        if j["status"] == "needs_review":
            # "ASAP" here would wrongly imply this is about to be
            # processed automatically — needs_review jobs are DELIBERATELY
            # never auto-processed (duplicate-post safety), so make that
            # explicit instead of reusing the "immediate" wording.
            when = "awaiting your review — use the buttons above, or /status again for them"
        elif not j["scheduled_for"]:
            when = "ASAP"
        else:
            when = datetime.datetime.fromtimestamp(j["scheduled_for"]).strftime("%Y-%m-%d %H:%M")
        lines.append(f"#{j['id']} · Account {j['account']} · {j['status']} · {when}")
    text += "\n\n📋 Your jobs:\n" + "\n".join(lines)
    bot.reply_to(message, text)

    # Offer explicit action buttons for anything needing manual review,
    # instead of requiring direct database/code intervention.
    review_jobs = [j for j in jobs if j["status"] == "needs_review"]
    for j in review_jobs:
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("✅ Checked — not posted, retry", callback_data=f"review_retry_{j['id']}"),
            types.InlineKeyboardButton("🗑️ Discard", callback_data=f"review_discard_{j['id']}"),
        )
        bot.send_message(
            message.chat.id,
            f"Job #{j['id']} (Account {j['account']}) needs review:\n{j.get('error') or 'Unknown outcome.'}",
            reply_markup=markup,
        )


@bot.callback_query_handler(func=lambda call: call.data.startswith("review_retry_"))
def review_retry(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    job_id = int(call.data.split("_")[-1])
    job = db.get_job(job_id)
    if not job:
        bot.send_message(call.message.chat.id, f"Job #{job_id} not found — may already be handled.")
        return
    if job["status"] != "needs_review":
        bot.send_message(
            call.message.chat.id,
            f"Job #{job_id} is no longer awaiting review (status: {job['status']}).",
        )
        return
    if not job.get("video_path") or not os.path.exists(job["video_path"]):
        bot.send_message(
            call.message.chat.id,
            f"❌ Job #{job_id}'s video file is no longer on the VPS — can't retry. "
            f"Please resend the video fresh instead.",
        )
        return
    # Back to pending (or scheduled, if it had a future time) so the
    # scheduler's normal loop picks it up again on its next pass — reset
    # attempts too, since this is a fresh confirmed-safe start, not a
    # continuation of the earlier ambiguous attempt.
    new_status = "scheduled" if job.get("scheduled_for") else "pending"
    db.update_job(job_id, status=new_status, error=None, attempts=0)
    bot.send_message(call.message.chat.id, f"🔁 Job #{job_id} confirmed safe and requeued for publishing.")


@bot.callback_query_handler(func=lambda call: call.data.startswith("review_discard_"))
def review_discard(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    job_id = int(call.data.split("_")[-1])
    job = db.get_job(job_id)
    if not job:
        bot.send_message(call.message.chat.id, f"Job #{job_id} not found — may already be handled.")
        return
    if job["status"] != "needs_review":
        bot.send_message(
            call.message.chat.id,
            f"Job #{job_id} is no longer awaiting review (status: {job['status']}).",
        )
        return
    if job.get("video_path") and os.path.exists(job["video_path"]):
        try:
            os.remove(job["video_path"])
        except OSError as e:
            logger.warning(f"Could not remove discarded job {job_id}'s video file: {e}")
    db.update_job(job_id, status="failed", error="Discarded after manual review.")
    bot.send_message(call.message.chat.id, f"🗑️ Job #{job_id} discarded.")


# ---------------- Persistent keyboard button routing ----------------
# The buttons on _main_keyboard() aren't inline callbacks — Telegram just
# sends their label back as a plain text message, so route those exact
# strings to the same handlers the equivalent /command already uses.

@bot.message_handler(func=lambda m: m.text == "📊 Status")
def kb_status(message):
    show_status(message)


@bot.message_handler(func=lambda m: m.text == "❌ Cancel")
def kb_cancel(message):
    cancel_flow(message)


@bot.message_handler(func=lambda m: m.text == "➕ Add Account")
def kb_add_account(message):
    add_account_start(message)


@bot.message_handler(func=lambda m: m.text == "❓ Help")
def kb_help(message):
    send_welcome(message)


@bot.message_handler(func=lambda m: m.text == "📈 Analytics")
def kb_analytics(message):
    if not is_authorized(message):
        return
    _send_analytics_picker(message.chat.id)


@bot.message_handler(func=lambda m: m.text == "📷 Quick Report")
def kb_quick_report(message):
    if not is_authorized(message):
        return
    _send_quick_report_picker(message.chat.id)


@bot.message_handler(func=lambda m: m.text == "🗑️ Delete Post")
def kb_delete_post(message):
    if not is_authorized(message):
        return
    markup = types.InlineKeyboardMarkup(row_width=1)
    any_account = False
    for i in range(1, ACCOUNT_COUNT + 1):
        if account_exists(i):
            any_account = True
            markup.add(types.InlineKeyboardButton(f"👤 Account {i}", callback_data=f"delpost_acc_{i}"))
    if not any_account:
        bot.send_message(
            message.chat.id,
            "No accounts have a saved session yet — use /addaccount or login.py first.",
        )
        return
    bot.send_message(message.chat.id, "🗑️ Which account?", reply_markup=markup)


def _shortcode_from_url(post_url):
    if not post_url:
        return None
    parts = [p for p in post_url.strip("/").split("/") if p]
    return parts[-1] if parts else None


@bot.callback_query_handler(func=lambda call: call.data.startswith("delpost_acc_"))
def delete_post_pick_account(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[-1])
    chat_id = call.message.chat.id

    recent = db.get_latest_metrics(account_num, limit=10)
    if not recent:
        bot.send_message(
            chat_id,
            f"No recent post data saved for Account {account_num} yet — run 📈 Analytics or "
            f"📷 Quick Report on it first so there's something to pick from here, or use "
            f"/deletepost {account_num} <shortcode> directly if you already know the shortcode.",
        )
        return

    markup = types.InlineKeyboardMarkup(row_width=1)
    any_valid = False
    for r in recent:
        shortcode = _shortcode_from_url(r.get("post_url"))
        if not shortcode:
            continue
        any_valid = True
        v = f"{r['views']:,} views" if r.get("views") is not None else "views unknown"
        markup.add(
            types.InlineKeyboardButton(f"👁 {v} — {shortcode}", callback_data=f"delpick_{account_num}_{shortcode}")
        )
    if not any_valid:
        bot.send_message(
            chat_id,
            f"Saved post data for Account {account_num} didn't include usable links — use "
            f"/deletepost {account_num} <shortcode> directly instead.",
        )
        return
    bot.send_message(
        chat_id,
        f"🗑️ Account {account_num} — pick a post to delete (from the last time Analytics/Quick "
        f"Report ran, may not be fully current):",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("delpick_"))
def delete_post_pick_post(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    _, account_str, shortcode = call.data.split("_", 2)
    account_num = int(account_str)

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(
            "⚠️ Yes, permanently delete it", callback_data=f"confirmdelete_{account_num}_{shortcode}"
        ),
        types.InlineKeyboardButton("Cancel", callback_data="canceldelete"),
    )
    bot.send_message(
        call.message.chat.id,
        f"⚠️ This will PERMANENTLY delete the post with shortcode `{shortcode}` from "
        f"Account {account_num}. This cannot be undone. Are you sure?",
        parse_mode="Markdown",
        reply_markup=markup,
    )


@bot.message_handler(commands=["deletepost"])
def cmd_delete_post(message):
    if not is_authorized(message):
        return
    parts = message.text.split()
    if len(parts) < 3 or not parts[1].isdigit():
        bot.reply_to(
            message,
            "Usage: /deletepost <account_number> <shortcode>\n\n"
            "The shortcode is the ID from the post's own URL — e.g. for "
            "instagram.com/reel/DExxxxxxxxx/, the shortcode is DExxxxxxxxx "
            "(just that code, not the full link).",
        )
        return
    account_num = int(parts[1])
    shortcode = parts[2].strip().strip("/")
    if not account_exists(account_num):
        bot.reply_to(message, f"❌ No saved session for Account {account_num}.")
        return

    # Destructive and irreversible — confirm before doing anything, same
    # spirit as the review_discard button elsewhere.
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(
            "⚠️ Yes, permanently delete it", callback_data=f"confirmdelete_{account_num}_{shortcode}"
        ),
        types.InlineKeyboardButton("Cancel", callback_data="canceldelete"),
    )
    bot.reply_to(
        message,
        f"⚠️ This will PERMANENTLY delete the post with shortcode `{shortcode}` from "
        f"Account {account_num}. This cannot be undone. Are you sure?",
        parse_mode="Markdown",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data == "canceldelete")
def cancel_delete(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    bot.send_message(call.message.chat.id, "❌ Cancelled — nothing was deleted.")


@bot.callback_query_handler(func=lambda call: call.data.startswith("confirmdelete_"))
def confirm_delete(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    _, account_str, shortcode = call.data.split("_", 2)
    account_num = int(account_str)
    chat_id = call.message.chat.id
    bot.send_message(chat_id, f"🗑️ Deleting post `{shortcode}` on Account {account_num}...", parse_mode="Markdown")

    def run():
        def status_cb(msg):
            try:
                bot.send_message(chat_id, f"Account {account_num}: {msg}")
            except Exception:
                pass

        def screenshot_cb(path, msg):
            try:
                with open(path, "rb") as f:
                    bot.send_photo(chat_id, f, caption=msg)
            except Exception as e:
                logger.warning(f"[delete] screenshot_cb failed: {e}")

        try:
            poster.delete_post(account_num, shortcode, status_cb=status_cb, screenshot_cb=screenshot_cb)
            bot.send_message(
                chat_id,
                f"✅ Delete attempted for `{shortcode}` — check the screenshot above to "
                f"confirm it actually went through.",
                parse_mode="Markdown",
            )
        except Exception as e:
            shot = getattr(e, "screenshot_path", None)
            dump = getattr(e, "elements_path", None)
            if shot and os.path.exists(shot):
                try:
                    with open(shot, "rb") as f:
                        bot.send_photo(chat_id, f, caption=f"Account {account_num} — delete failed here")
                except Exception:
                    pass
            if dump and os.path.exists(dump):
                try:
                    with open(dump, "rb") as f:
                        bot.send_document(chat_id, f, caption="Page elements at the point of failure")
                except Exception:
                    pass
            bot.send_message(chat_id, f"❌ Delete failed: {_short(str(e), 1500)}")

    threading.Thread(target=run, daemon=True).start()


@bot.callback_query_handler(func=lambda call: call.data.startswith("review_"))
def handle_review_action(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    _, action, job_id_str = call.data.split("_", 2)
    job_id = int(job_id_str)
    job = db.get_job(job_id)
    if not job or job["status"] != "needs_review":
        bot.send_message(call.message.chat.id, "That job is no longer awaiting review.")
        return

    if action == "discard":
        db.update_job(job_id, status="cancelled")
        if job.get("video_path") and os.path.exists(job["video_path"]):
            try:
                os.remove(job["video_path"])
            except OSError:
                pass
        bot.send_message(call.message.chat.id, f"🗑️ Job #{job_id} discarded.")

    elif action == "retry":
        if not job.get("video_path") or not os.path.exists(job["video_path"]):
            bot.send_message(
                call.message.chat.id,
                f"❌ Can't retry job #{job_id} — the original video file is no longer on disk. "
                f"Please resend the video from scratch.",
            )
            db.update_job(job_id, status="cancelled")
            return
        # Re-queue as a fresh 'pending' job — a human has explicitly
        # confirmed it's safe, so this is the ONE path where a
        # previously-uncertain job is allowed to run again.
        db.update_job(job_id, status="pending", attempts=0, error=None)
        bot.send_message(call.message.chat.id, f"🔁 Job #{job_id} re-queued for publishing.")


# ---------------- Video intake ----------------

# Standard cloud Telegram Bot API caps file downloads via getFile at 20MB,
# regardless of what limit we set in video_check.py. Going over this fails
# with an API error, not a clean "video too big" message, so check it
# up front using the size Telegram already reports on the message object.
TELEGRAM_CLOUD_API_DOWNLOAD_LIMIT_BYTES = 20 * 1024 * 1024


@bot.message_handler(content_types=["video"])
def handle_video(message):
    if not is_authorized(message):
        return

    existing = db.get_user_state(message.chat.id)
    if existing and existing.get("video_path"):
        # Any in-progress flow (choosing account, writing caption, confirming)
        # has a video_path set. Don't silently clobber it with a new upload.
        bot.reply_to(
            message,
            "⚠️ You already have an unfinished post in progress. Send /cancel first if you "
            "want to discard it and start over with this new video.",
        )
        return
    if existing and str(existing.get("stage", "")).startswith("add_account:"):
        bot.reply_to(
            message,
            "⚠️ You're in the middle of /addaccount. Send /cancel first if you want to "
            "abandon that and post a video instead.",
        )
        return

    if message.video.file_size and message.video.file_size > TELEGRAM_CLOUD_API_DOWNLOAD_LIMIT_BYTES:
        mb = message.video.file_size / (1024 * 1024)
        bot.reply_to(
            message,
            f"❌ This video is {mb:.1f}MB. The standard Telegram Bot API can only download "
            f"files up to 20MB — larger files need a self-hosted Local Bot API Server "
            f"(see SETUP.md) to lift that limit. Try a smaller/more compressed file for now.",
        )
        return

    bot.reply_to(message, "⏳ Downloading video...")

    try:
        file_info = bot.get_file(message.video.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
    except Exception as e:
        logger.warning(f"Video download failed for chat {message.chat.id}: {e}")
        bot.reply_to(
            message,
            "❌ Couldn't download that video from Telegram. It may be too large for the "
            "current setup, or Telegram had a transient error — try again or use a smaller file.",
        )
        return

    video_filename = f"reel_{int(time.time())}.mp4"
    local_video_path = os.path.join(DOWNLOAD_DIR, video_filename)
    with open(local_video_path, "wb") as f:
        f.write(downloaded_file)

    ok, reason = validate_video(local_video_path)
    if not ok:
        os.remove(local_video_path)
        bot.reply_to(message, f"❌ Video rejected: {reason}")
        return

    _intake_video(message.chat.id, local_video_path)


def _intake_video(chat_id, local_video_path):
    """Shared tail of both video-intake paths (Telegram upload, and a
    direct MP4 link). If VIDEO_ENHANCE is on, runs the (potentially
    slow, no-GPU) quality pass in a background thread first — never
    blocking the bot's own message loop for other chats/commands while
    that runs — then proceeds to the same checkbox/caption/confirm flow
    regardless of how the file arrived or whether it was enhanced."""
    if VIDEO_ENHANCE:
        bot.send_message(
            chat_id,
            "🎨 Enhancing video quality before posting — this can take a minute or two "
            "depending on length (VIDEO_ENHANCE is on in .env)...",
        )

        def run_enhance():
            enhanced_path = video_enhance.enhance_video(local_video_path)
            _finish_intake(chat_id, enhanced_path)

        threading.Thread(target=run_enhance, daemon=True).start()
    else:
        _finish_intake(chat_id, local_video_path)


def _finish_intake(chat_id, local_video_path):
    db.set_user_state(
        chat_id, video_path=local_video_path, account=None, caption=None,
        stage="choose_accounts", extra=json.dumps([]),
    )
    markup = _build_account_checkbox_markup([])
    bot.send_message(
        chat_id,
        "🎥 Video received. Tap accounts to select (multiple allowed), then Done:",
        reply_markup=markup,
    )


_MP4_URL_RE = re.compile(r"https?://\S+\.mp4(?:\?\S*)?", re.IGNORECASE)


@bot.message_handler(func=lambda m: m.text and _MP4_URL_RE.search(m.text))
def handle_video_url(message):
    """A direct .mp4 link, instead of a Telegram file upload — downloaded
    straight from wherever it's hosted, so this ALSO sidesteps the 20MB
    Telegram Bot API download cap entirely (only MAX_URL_VIDEO_MB applies
    here, which can be set much higher)."""
    if not is_authorized(message):
        return

    existing = db.get_user_state(message.chat.id)
    if existing and existing.get("video_path"):
        bot.reply_to(
            message,
            "⚠️ You already have an unfinished post in progress. Send /cancel first if you "
            "want to discard it and start over with this link.",
        )
        return
    if existing and str(existing.get("stage", "")).startswith("add_account:"):
        bot.reply_to(
            message,
            "⚠️ You're in the middle of /addaccount. Send /cancel first if you want to "
            "abandon that and post this link instead.",
        )
        return

    url = _MP4_URL_RE.search(message.text).group(0)
    bot.reply_to(message, f"⏳ Downloading video from the link (up to {MAX_URL_VIDEO_MB}MB)...")

    video_filename = f"reel_{int(time.time())}.mp4"
    local_video_path = os.path.join(DOWNLOAD_DIR, video_filename)
    max_bytes = MAX_URL_VIDEO_MB * 1024 * 1024

    try:
        with requests.get(url, stream=True, timeout=URL_DOWNLOAD_TIMEOUT_SECONDS) as resp:
            resp.raise_for_status()
            content_length = resp.headers.get("Content-Length")
            if content_length and int(content_length) > max_bytes:
                bot.reply_to(
                    message,
                    f"❌ That file is {int(content_length) / (1024*1024):.1f}MB, over the "
                    f"{MAX_URL_VIDEO_MB}MB limit (MAX_URL_VIDEO_MB in .env). Try a smaller file.",
                )
                return
            written = 0
            with open(local_video_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=1024 * 256):
                    written += len(chunk)
                    if written > max_bytes:
                        f.close()
                        os.remove(local_video_path)
                        bot.reply_to(
                            message,
                            f"❌ Stopped downloading — exceeded the {MAX_URL_VIDEO_MB}MB limit "
                            f"(MAX_URL_VIDEO_MB in .env) partway through.",
                        )
                        return
                    f.write(chunk)
    except Exception as e:
        logger.warning(f"URL video download failed for chat {message.chat.id} ({url}): {e}")
        if os.path.exists(local_video_path):
            os.remove(local_video_path)
        bot.reply_to(
            message,
            f"❌ Couldn't download that link: {str(e)[:300]}. Check the link is a direct, "
            f"publicly-accessible .mp4 file (not a page that just links to one).",
        )
        return

    ok, reason = validate_video(local_video_path)
    if not ok:
        os.remove(local_video_path)
        bot.reply_to(message, f"❌ Video rejected: {reason}")
        return

    _intake_video(message.chat.id, local_video_path)


def _build_account_checkbox_markup(selected):
    """selected: list of int account numbers currently checked."""
    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in range(1, ACCOUNT_COUNT + 1):
        mark = "☑️" if i in selected else "☐"
        markup.add(types.InlineKeyboardButton(f"{mark} Account {i}", callback_data=f"toggleacc_{i}"))
    done_label = f"✅ Done ({len(selected)} selected)" if selected else "✅ Done"
    markup.add(
        types.InlineKeyboardButton(done_label, callback_data="accounts_done"),
        types.InlineKeyboardButton("❌ Cancel", callback_data="accounts_cancel"),
    )
    return markup


@bot.callback_query_handler(func=lambda call: call.data.startswith("toggleacc_"))
def toggle_account_checkbox(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[1])
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "choose_accounts":
        return

    if not account_exists(account_num):
        bot.answer_callback_query(call.id, f"No saved session for Account {account_num}.", show_alert=True)
        return

    selected = json.loads(state.get("extra") or "[]")
    if account_num in selected:
        selected.remove(account_num)
    else:
        selected.append(account_num)
    db.set_user_state(call.message.chat.id, extra=json.dumps(selected))

    markup = _build_account_checkbox_markup(selected)
    try:
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=markup)
    except Exception:
        pass  # e.g. "message not modified" if double-tapped — harmless


@bot.callback_query_handler(func=lambda call: call.data == "accounts_cancel")
def cancel_account_selection(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if state and state.get("video_path") and os.path.exists(state["video_path"]):
        try:
            os.remove(state["video_path"])
        except OSError:
            pass
    db.clear_user_state(call.message.chat.id)
    bot.send_message(call.message.chat.id, "❌ Cancelled.")


@bot.callback_query_handler(func=lambda call: call.data == "accounts_done")
def confirm_accounts(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "choose_accounts":
        return

    selected = json.loads(state.get("extra") or "[]")
    if not selected:
        bot.answer_callback_query(call.id, "Select at least one account first.", show_alert=True)
        return

    # From here on, "extra" switches shape from a plain accounts list to a
    # dict that also carries the per-post hide-likes choice — starts off
    # matching the .env global default (HIDE_LIKE_COUNTS), tap the button
    # at confirm time to override it just for this post.
    db.set_user_state(
        call.message.chat.id, stage="await_caption",
        extra=json.dumps({"accounts": selected, "hide_likes": HIDE_LIKE_COUNTS}),
    )
    names = ", ".join(str(a) for a in sorted(selected))
    msg = bot.send_message(call.message.chat.id, f"✅ Account(s) {names} selected.\n\n✍️ Send the caption:")
    bot.register_next_step_handler(msg, handle_caption)


def _confirm_markup(hide_likes):
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("📤 Post Now", callback_data="mode_now"),
        types.InlineKeyboardButton("🕒 Schedule", callback_data="mode_schedule"),
    )
    hide_label = "🙈 Hide likes: ON" if hide_likes else "👁️ Hide likes: OFF"
    markup.add(types.InlineKeyboardButton(hide_label, callback_data="toggle_hide_likes"))
    markup.add(types.InlineKeyboardButton("❌ Cancel", callback_data="mode_cancel"))
    return markup


def handle_caption(message):
    if not is_authorized(message):
        return
    state = db.get_user_state(message.chat.id)
    if not state or not state.get("video_path"):
        bot.reply_to(message, "Session lost, please resend the video.")
        return

    caption = message.text
    # Caption is persisted in SQLite (not an in-memory dict) so it survives a
    # bot restart between "caption sent" and "confirm" — same reasoning as the
    # jobs table.
    extra = json.loads(state.get("extra") or "{}")
    extra["caption"] = caption  # stash here too so the toggle handler can rebuild the review text
    db.set_user_state(message.chat.id, caption=caption, stage="await_confirm", extra=json.dumps(extra))

    selected = extra.get("accounts", [])
    accounts_str = ", ".join(str(a) for a in sorted(selected))
    # Plain text, NOT parse_mode="Markdown" — the caption is arbitrary user
    # content and may contain _, *, `, [ etc. Telegram's legacy Markdown
    # parser throws a "can't parse entities" error on unbalanced markers,
    # which would silently break this step for any caption containing them.
    bot.send_message(
        message.chat.id,
        f"📋 Review\nAccount(s): {accounts_str}\nCaption: {caption}\n\nWhat would you like to do?",
        reply_markup=_confirm_markup(extra.get("hide_likes", False)),
    )


@bot.callback_query_handler(func=lambda call: call.data == "toggle_hide_likes")
def toggle_hide_likes_btn(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "await_confirm":
        return
    extra = json.loads(state.get("extra") or "{}")
    extra["hide_likes"] = not extra.get("hide_likes", False)
    db.set_user_state(call.message.chat.id, extra=json.dumps(extra))
    try:
        bot.edit_message_reply_markup(
            call.message.chat.id, call.message.message_id,
            reply_markup=_confirm_markup(extra["hide_likes"]),
        )
    except Exception:
        pass  # e.g. "message not modified" if double-tapped — harmless


@bot.callback_query_handler(func=lambda call: call.data.startswith("mode_"))
def handle_mode(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id
    state = db.get_user_state(chat_id)
    caption = state.get("caption") if state else None
    extra = json.loads(state.get("extra") or "{}") if state else {}
    selected = extra.get("accounts", [])
    hide_likes = extra.get("hide_likes", False)

    if call.data == "mode_cancel" or not state or caption is None or not selected:
        if state and state.get("video_path") and os.path.exists(state["video_path"]):
            os.remove(state["video_path"])
        db.clear_user_state(chat_id)
        bot.send_message(chat_id, "❌ Cancelled.")
        return

    if call.data == "mode_now":
        for acc in selected:
            db.create_job(chat_id, acc, state["video_path"], caption, scheduled_for=None, hide_likes=int(hide_likes))
        names = ", ".join(str(a) for a in sorted(selected))
        tag = " (likes hidden)" if hide_likes else ""
        bot.send_message(
            chat_id,
            f"🚀 Queued for immediate publishing to Account(s) {names}{tag}. I'll message you with updates.",
        )
        db.clear_user_state(chat_id)

    elif call.data == "mode_schedule":
        msg = bot.send_message(
            chat_id, "🕒 Send the date/time in format `YYYY-MM-DD HH:MM` (24h, server local time):",
            parse_mode="Markdown",
        )
        bot.register_next_step_handler(msg, handle_schedule_time)


def handle_schedule_time(message):
    if not is_authorized(message):
        return
    chat_id = message.chat.id
    state = db.get_user_state(chat_id)
    extra = json.loads(state.get("extra") or "{}") if state else {}
    selected = extra.get("accounts", [])
    hide_likes = extra.get("hide_likes", False)
    if not state or not state.get("video_path") or not state.get("caption") or not selected:
        bot.reply_to(message, "Session lost, please resend the video.")
        return

    try:
        dt = datetime.datetime.strptime(message.text.strip(), "%Y-%m-%d %H:%M")
        ts = dt.timestamp()
        if ts < time.time():
            bot.reply_to(message, "That time is in the past. Please /cancel and try again.")
            return
    except ValueError:
        bot.reply_to(message, "Invalid format. Please /cancel and try again with YYYY-MM-DD HH:MM.")
        return

    for acc in selected:
        db.create_job(chat_id, acc, state["video_path"], state["caption"], scheduled_for=ts, hide_likes=int(hide_likes))
    names = ", ".join(str(a) for a in sorted(selected))
    tag = " (likes hidden)" if hide_likes else ""
    bot.send_message(chat_id, f"✅ Scheduled for {dt.strftime('%Y-%m-%d %H:%M')} on Account(s) {names}{tag}.")
    db.clear_user_state(chat_id)


def _recover_after_restart():
    """Any job stuck in 'publishing' means the process died mid-attempt.
    Never assume it's safe to retry — mark it needs_review and tell the
    relevant chat, same policy as the live PublishUncertainError path."""
    recovered = db.recover_stuck_publishing_jobs()
    for job in recovered:
        logger.warning(f"Recovered stuck job {job['id']} (was 'publishing') as needs_review.")
        try:
            bot.send_message(
                job["chat_id"],
                f"⚠️ The bot restarted while job #{job['id']} (Account {job['account']}) was "
                f"publishing. Outcome unknown — please check the account manually before "
                f"resending, to avoid a duplicate post. Use /status to see it.",
            )
        except Exception as e:
            logger.warning(f"Could not notify chat {job['chat_id']} about recovered job: {e}")


# ---------------- Instagram URL intake (repost, with attribution) ----------------
# Downloads a public Instagram Reel via yt-dlp, keeps the ORIGINAL creator
# credited in the caption, then feeds it through the exact same
# checkbox-account-select -> scheduler -> poster.py pipeline as any other
# video — inherits all of that pipeline's existing retry/uncertain-outcome/
# safety behavior for free. Intended for content the operator owns or is
# authorized to repost (see INSTAGRAM_REPOST_TEST.md) — this tool doesn't
# and can't verify that on its own; it's on the operator to only use it for
# content they actually have the rights to.

_INSTAGRAM_REEL_RE = re.compile(
    r"https?://(?:www\.)?instagram\.com/(?:reel|reels)/[A-Za-z0-9_-]+(?:/\S*)?",
    re.IGNORECASE,
)


@bot.message_handler(func=lambda m: bool(m.text and _INSTAGRAM_REEL_RE.search(m.text)))
def handle_instagram_reel_url(message):
    """Download a public Instagram Reel, keep its description as the
    caption, then let the operator select one or
    more saved publishing accounts."""
    if not is_authorized(message):
        return

    existing = db.get_user_state(message.chat.id)
    if existing and existing.get("video_path"):
        bot.reply_to(message, "⚠️ Finish/cancel the current post first with /cancel.")
        return
    if existing and str(existing.get("stage", "")).startswith("add_account:"):
        bot.reply_to(message, "⚠️ You're in /addaccount. Send /cancel first.")
        return

    url = _INSTAGRAM_REEL_RE.search(message.text).group(0)
    status = bot.reply_to(message, "🔍 Instagram Reel detected.\n⏳ Downloading highest available single-file quality...")

    def run():
        try:
            result = instagram_source.download_reel(url, DOWNLOAD_DIR)
            caption = result["caption"] or result["title"] or ""

            # Persist source caption in extra so the existing publisher
            # can be used without asking the user to retype the caption.
            extra = {
                "mode": "instagram_repost",
                "accounts": [],
                "source_caption": caption,
                "source_url": url,
            }
            db.set_user_state(
                message.chat.id,
                video_path=result["path"],
                account=None,
                caption=caption,
                stage="ig_choose_accounts",
                extra=json.dumps(extra),
            )

            markup = types.InlineKeyboardMarkup(row_width=1)
            any_account = False
            for i in range(1, ACCOUNT_COUNT + 1):
                if account_exists(i):
                    any_account = True
                    markup.add(types.InlineKeyboardButton(
                        f"☐ Account {i}", callback_data=f"igrepost_toggle_{i}"
                    ))
            markup.add(
                types.InlineKeyboardButton("✨ AI Rewrite Caption", callback_data="igrepost_rewrite"),
            )
            markup.add(
                types.InlineKeyboardButton("🚀 Repost Now", callback_data="igrepost_done"),
                types.InlineKeyboardButton("❌ Cancel", callback_data="igrepost_cancel"),
            )

            if not any_account:
                if os.path.exists(result["path"]):
                    os.remove(result["path"])
                db.clear_user_state(message.chat.id)
                bot.edit_message_text(
                    "❌ No saved Instagram publishing account.\nUse /addaccount or login.py first.",
                    message.chat.id, status.message_id
                )
                return

            bot.edit_message_text(
                "✅ Reel downloaded.\n"
                f"📝 Caption copied: {'Yes' if caption else 'No'}\n\n"
                "Select target account(s), optionally tap ✨ AI Rewrite Caption, then Repost Now.",
                message.chat.id, status.message_id
            )
            bot.send_message(message.chat.id, f"📝 Caption:\n{caption or '(none)'}")
            bot.send_message(message.chat.id, "🎯 Select target account(s):", reply_markup=markup)

        except Exception as e:
            logger.warning(f"Instagram URL download failed for chat {message.chat.id}: {e}")
            db.clear_user_state(message.chat.id)
            bot.edit_message_text(
                "❌ Instagram download failed.\n\n" + str(e)[:700],
                message.chat.id, status.message_id
            )

    threading.Thread(target=run, daemon=True).start()


@bot.callback_query_handler(func=lambda call: call.data.startswith("igrepost_toggle_"))
def instagram_repost_toggle(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.rsplit("_", 1)[1])
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "ig_choose_accounts":
        return

    extra = json.loads(state.get("extra") or "{}")
    selected = extra.get("accounts", [])
    if not account_exists(account_num):
        bot.answer_callback_query(call.id, f"Account {account_num} has no saved session.", show_alert=True)
        return

    if account_num in selected:
        selected.remove(account_num)
    else:
        selected.append(account_num)
    extra["accounts"] = selected
    db.set_user_state(call.message.chat.id, extra=json.dumps(extra))

    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in range(1, ACCOUNT_COUNT + 1):
        if account_exists(i):
            mark = "☑️" if i in selected else "☐"
            markup.add(types.InlineKeyboardButton(
                f"{mark} Account {i}", callback_data=f"igrepost_toggle_{i}"
            ))
    label = f"🚀 Repost Now ({len(selected)} selected)" if selected else "🚀 Repost Now"
    markup.add(
        types.InlineKeyboardButton(label, callback_data="igrepost_done"),
        types.InlineKeyboardButton("❌ Cancel", callback_data="igrepost_cancel"),
    )
    try:
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=markup)
    except Exception:
        pass


@bot.callback_query_handler(func=lambda call: call.data == "igrepost_rewrite")
def instagram_repost_rewrite(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id, "Rewriting caption...")
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "ig_choose_accounts":
        return

    extra = json.loads(state.get("extra") or "{}")
    # Always rewrite from the ORIGINAL downloaded caption, not a previous
    # rewrite — repeated taps give fresh variations of the source material
    # rather than drifting further from it with each tap.
    source_caption = extra.get("source_caption") or state.get("caption") or ""
    rewritten = analytics.rewrite_caption_with_ai(source_caption)

    if not rewritten:
        bot.send_message(
            call.message.chat.id,
            "❌ Couldn't rewrite the caption (check OPENROUTER_API_KEY is set in .env) — "
            "keeping the original.",
        )
        return

    db.set_user_state(call.message.chat.id, caption=rewritten)
    bot.send_message(call.message.chat.id, f"✨ Rewritten caption:\n{rewritten}")


@bot.callback_query_handler(func=lambda call: call.data == "igrepost_cancel")
def instagram_repost_cancel(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if state and state.get("video_path") and os.path.exists(state["video_path"]):
        try:
            os.remove(state["video_path"])
        except OSError:
            pass
    db.clear_user_state(call.message.chat.id)
    bot.send_message(call.message.chat.id, "❌ Instagram repost cancelled.")


@bot.callback_query_handler(func=lambda call: call.data == "igrepost_done")
def instagram_repost_done(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "ig_choose_accounts":
        return

    extra = json.loads(state.get("extra") or "{}")
    selected = extra.get("accounts", [])
    caption = state.get("caption") or extra.get("source_caption") or ""

    if not selected:
        bot.answer_callback_query(call.id, "Select at least one account first.", show_alert=True)
        return
    if not state.get("video_path") or not os.path.exists(state["video_path"]):
        bot.send_message(call.message.chat.id, "❌ Downloaded video is no longer available.")
        db.clear_user_state(call.message.chat.id)
        return

    for acc in selected:
        db.create_job(
            call.message.chat.id,
            acc,
            state["video_path"],
            caption,
            scheduled_for=None,
            hide_likes=int(HIDE_LIKE_COUNTS),
        )

    names = ", ".join(str(a) for a in sorted(selected))
    bot.send_message(
        call.message.chat.id,
        f"🚀 Instagram Reel queued for Account(s) {names}.\n"
        f"📝 Original caption copied automatically.\n"
        f"🔗 Source: {extra.get('source_url', '')}"
    )
    db.clear_user_state(call.message.chat.id)


if __name__ == "__main__":
    logger.info("Bot starting...")
    _recover_after_restart()
    start_scheduler(bot)
    start_health_checker(bot)
    start_web_ui()
    print("🌐 Buzznity Web UI online.")
    print("🤖 Buzznity bot online.")
    bot.infinity_polling(timeout=60, long_polling_timeout=60)
