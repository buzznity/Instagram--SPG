"""
config.py — central configuration loader.
All secrets come from environment variables (.env file), never hardcoded.
"""
import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
ALLOWED_CHAT_ID_RAW = os.getenv("ALLOWED_CHAT_ID")

if not BOT_TOKEN or not ALLOWED_CHAT_ID_RAW:
    raise SystemExit(
        "[CRITICAL] Missing TELEGRAM_BOT_TOKEN or ALLOWED_CHAT_ID. "
        "Copy .env.example to .env and fill it in."
    )

ALLOWED_CHAT_ID = int(ALLOWED_CHAT_ID_RAW)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DOWNLOAD_DIR = os.path.join(BASE_DIR, "downloads")
SESSION_DIR = os.path.join(BASE_DIR, "sessions")
LOG_DIR = os.path.join(BASE_DIR, "logs")
DB_PATH = os.path.join(BASE_DIR, "buzznity.db")

for d in (DOWNLOAD_DIR, SESSION_DIR, LOG_DIR):
    os.makedirs(d, exist_ok=True)

# Session dir holds live Instagram browser cookies — restrict to owner-only.
try:
    os.chmod(SESSION_DIR, 0o700)
except OSError:
    pass

# Minimum minutes between two posts on the SAME account.
# Keeping this non-trivial reduces (does not eliminate) the chance of
# Instagram's automation detection flagging the account.
MIN_MINUTES_BETWEEN_POSTS = int(os.getenv("MIN_MINUTES_BETWEEN_POSTS", "20"))

# Different accounts CAN post at the same time (each has its own browser
# session), but each browser session is real CPU/RAM load on the VPS — too
# many at once can starve each other, causing exactly the kind of "home
# page never loaded (timeout)" failures a resource-constrained VPS would
# see under that load. Caps how many publish jobs run their browser
# session simultaneously, regardless of how many different accounts have
# jobs queued — extra jobs simply wait their turn instead of piling on.
MAX_CONCURRENT_PUBLISHES = int(os.getenv("MAX_CONCURRENT_PUBLISHES", "2"))

# How many accounts this deployment supports (numbered 1..N sessions)
ACCOUNT_COUNT = int(os.getenv("ACCOUNT_COUNT", "3"))

# Retry attempts for a single publish job before giving up
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "2"))
# Pause between retry attempts on a pre-Share failure — gives Instagram's
# side a moment to settle rather than hammering it with immediate
# back-to-back attempts. Not a detection-evasion measure, just reasonable
# client behavior.
RETRY_BACKOFF_SECONDS = int(os.getenv("RETRY_BACKOFF_SECONDS", "10"))
# After a post is confirmed shared, wait this long, then visit the
# account's own profile and screenshot it as final, independent proof the
# post is really there — much stronger than any toast/DOM heuristic during
# the compose flow, and guards against a false-positive "success" read.
PUBLISH_VERIFY_DELAY_SECONDS = int(os.getenv("PUBLISH_VERIFY_DELAY_SECONDS", "60"))
# If true, tries to turn on "Hide like and view counts" for every post
# before sharing it. Best-effort — skipped harmlessly if not found.
HIDE_LIKE_COUNTS = os.getenv("HIDE_LIKE_COUNTS", "false").lower() == "true"

# If set, tries to add this as the post's location before sharing (e.g.
# "USA", "New York", "London"). Best-effort — skipped harmlessly if the
# location search doesn't return a matching suggestion.
DEFAULT_POST_LOCATION = os.getenv("DEFAULT_POST_LOCATION", "").strip()

# If set, tries to add this Instagram username as a collaborator before
# sharing (they'd need to accept the invite for it to actually show as
# co-authored — this just sends the invite). Leave blank to skip.
DEFAULT_COLLABORATOR = os.getenv("DEFAULT_COLLABORATOR", "").strip()

# For posting a video by direct .mp4 link instead of a Telegram upload —
# this path downloads straight from the link's own host, so it isn't
# subject to Telegram's 20MB Bot API cap at all. Still needs SOME sane
# upper bound so a bad/huge link can't fill the VPS disk.
MAX_URL_VIDEO_MB = int(os.getenv("MAX_URL_VIDEO_MB", "500"))
URL_DOWNLOAD_TIMEOUT_SECONDS = int(os.getenv("URL_DOWNLOAD_TIMEOUT_SECONDS", "120"))

# For AI-generated analytics summaries (optional — /analytics falls back to
# raw numbers only if this isn't set). Get a key at https://openrouter.ai
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
# "openrouter/free" is OpenRouter's own auto-router — it picks a free
# model that fits what the request needs (including vision, when an
# image is attached), so this one setting covers both text summaries and
# the image-based view-count reading below without hardcoding a specific
# model that might get pulled from the free tier later.
OPENROUTER_MODEL = os.getenv("OPENROUTER_MODEL", "openrouter/free")
# /analytics defaults to checking ALL of an account's posts (not just a
# handful) — this is a hard safety cap regardless, so one run against a
# very large account can't turn into an unbounded scrape.
ANALYTICS_MAX_POSTS = int(os.getenv("ANALYTICS_MAX_POSTS", "150"))

# Optional ffmpeg-based quality pass run automatically right after a video
# is received, before it's posted. Off by default — it adds real
# processing time (no GPU on a typical VPS), trading against wanting
# posts to go out fast. See video_enhance.py for exactly what this does.
VIDEO_ENHANCE = os.getenv("VIDEO_ENHANCE", "false").lower() == "true"
VIDEO_ENHANCE_MIN_HEIGHT = int(os.getenv("VIDEO_ENHANCE_MIN_HEIGHT", "1920"))
VIDEO_ENHANCE_CRF = int(os.getenv("VIDEO_ENHANCE_CRF", "17"))
VIDEO_ENHANCE_TIMEOUT_SECONDS = int(os.getenv("VIDEO_ENHANCE_TIMEOUT_SECONDS", "300"))
VIDEO_ENHANCE_DENOISE = os.getenv("VIDEO_ENHANCE_DENOISE", "false").lower() == "true"
VIDEO_ENHANCE_COLOR = os.getenv("VIDEO_ENHANCE_COLOR", "true").lower() == "true"
# Safety default: only actually re-encode when the source is genuinely
# below the target resolution (or clearly low-bitrate) — re-encoding an
# already-good video is a pure quality DOWNGRADE (generation loss) for no
# benefit. Set false to always run the full pipeline regardless.
VIDEO_ENHANCE_ONLY_IF_NEEDED = os.getenv("VIDEO_ENHANCE_ONLY_IF_NEEDED", "true").lower() == "true"
# When true, saves a screenshot after every publish step (not just on
# failure) to logs/screenshots/ — useful while debugging Instagram UI
# changes. Off by default since it multiplies screenshot volume per post;
# turn on temporarily via DEBUG_SCREENSHOTS=true in .env, then back off.
DEBUG_SCREENSHOTS = os.getenv("DEBUG_SCREENSHOTS", "false").lower() == "true"

# How often (minutes) to check each account's session health in the background
HEALTH_CHECK_INTERVAL_MINUTES = int(os.getenv("HEALTH_CHECK_INTERVAL_MINUTES", "10"))

# If true, wait one full interval before the FIRST health check instead of
# checking immediately on startup.
HEALTH_CHECK_DELAY_FIRST_RUN = os.getenv("HEALTH_CHECK_DELAY_FIRST_RUN", "false").lower() == "true"

WEB_UI_HOST = os.getenv("WEB_UI_HOST", "127.0.0.1")
WEB_UI_PORT = int(os.getenv("WEB_UI_PORT", "8080"))
WEB_UI_TOKEN = os.getenv("WEB_UI_TOKEN", "")
