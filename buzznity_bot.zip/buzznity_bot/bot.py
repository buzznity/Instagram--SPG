# bot.py — Telegram control panel for the Instagram reel publisher.
import os
import time
import json
import datetime
import telebot
from telebot import types

from config import BOT_TOKEN, ALLOWED_CHAT_ID, DOWNLOAD_DIR, ACCOUNT_COUNT
from logger import logger
import database as db
import session_store
from scheduler import start_scheduler
from health_checker import start_health_checker
from video_check import validate_video

db.init_db()
bot = telebot.TeleBot(BOT_TOKEN)


def is_authorized(message_or_call):
    chat_id = message_or_call.chat.id if hasattr(message_or_call, "chat") else message_or_call.message.chat.id
    return chat_id == ALLOWED_CHAT_ID


def account_exists(account_num):
    return session_store.session_kind(account_num) is not None


def _try_delete(message):
    """Best-effort delete of a message that contained a live session cookie.
    Never raises — Telegram sometimes refuses deletion (message too old,
    bot lacks delete rights in some chat types), and that must not break
    the flow, just leave the message visible."""
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception as e:
        logger.info(f"Could not delete cookie-input message {message.message_id}: {e}")


# ---------------- Commands ----------------

@bot.message_handler(commands=["start", "help"])
def send_welcome(message):
    if not is_authorized(message):
        return
    bot.reply_to(
        message,
        "👋 *Instagram Reel Publisher*\n\n"
        "Send a reel video (MP4) to begin.\n\n"
        "Other commands:\n"
        "/status — see your pending/scheduled jobs and account health\n"
        "/addaccount — add an Instagram session by pasting cookies (alternative to login.py)\n"
        "/cancel — cancel your current in-progress flow\n",
        parse_mode="Markdown",
    )


@bot.message_handler(commands=["cancel"])
def cancel_flow(message):
    if not is_authorized(message):
        return
    state = db.get_user_state(message.chat.id)
    if state and state.get("video_path") and os.path.exists(state["video_path"]):
        try:
            os.remove(state["video_path"])
        except OSError:
            pass
    db.clear_user_state(message.chat.id)
    bot.reply_to(message, "❌ Current flow cancelled.")


# ---------------- Add account via pasted cookies ----------------
# Alternative to running login.py: paste the 4 core Instagram session
# cookies (from a browser's dev tools) instead. Each value is asked for
# separately and the message containing it is deleted immediately after
# being read, since these are live login credentials sitting in Telegram's
# chat history otherwise. Less robust than login.py's full browser profile
# (see session_store.py), but faster to set up.
_COOKIE_PROMPTS = {
    "sessionid": "🔑 Step 1/4 — paste the *sessionid* cookie value:",
    "csrftoken": "🔑 Step 2/4 — paste the *csrftoken* cookie value:",
    "ds_user_id": "🔑 Step 3/4 — paste the *ds_user_id* cookie value:",
    "mid": "🔑 Step 4/4 — paste the *mid* cookie value:",
}
_COOKIE_ORDER = list(_COOKIE_PROMPTS.keys())


@bot.message_handler(commands=["addaccount"])
def add_account_start(message):
    if not is_authorized(message):
        return
    existing = db.get_user_state(message.chat.id)
    if existing and existing.get("video_path"):
        bot.reply_to(message, "⚠️ You have an unfinished post in progress. Send /cancel first.")
        return

    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in range(1, ACCOUNT_COUNT + 1):
        tag = " (already has a session — this will overwrite it)" if account_exists(i) else ""
        markup.add(types.InlineKeyboardButton(f"👤 Account {i}{tag}", callback_data=f"addacc_{i}"))
    bot.reply_to(
        message,
        "Which account number is this session for?\n\n"
        "You'll be asked to paste 4 values from Instagram's cookies "
        "(sessionid, csrftoken, ds_user_id, mid — from your browser's dev tools, "
        "Application → Cookies → instagram.com).\n\n"
        "⚠️ Each message you send will be deleted right after I read it, since "
        "these are live login credentials.",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("addacc_"))
def add_account_choose(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[1])
    # The "caption" column is repurposed here purely as scratch storage for
    # the cookie values collected so far (JSON-encoded) — it has no
    # relation to a post caption during this flow.
    db.set_user_state(
        call.message.chat.id, video_path=None, account=account_num,
        caption=json.dumps({}), stage="add_account:sessionid",
    )
    msg = bot.send_message(
        call.message.chat.id, _COOKIE_PROMPTS["sessionid"], parse_mode="Markdown"
    )
    bot.register_next_step_handler(msg, _handle_cookie_step)


def _handle_cookie_step(message):
    if not is_authorized(message):
        return
    state = db.get_user_state(message.chat.id)
    if not state or not state.get("stage", "").startswith("add_account:"):
        _try_delete(message)
        bot.reply_to(message, "Session lost, please run /addaccount again.")
        return

    current_field = state["stage"].split(":", 1)[1]
    value = message.text.strip() if message.text else ""
    _try_delete(message)  # delete the credential immediately, success or not

    if not value:
        msg = bot.send_message(
            message.chat.id,
            f"That was empty — {_COOKIE_PROMPTS[current_field]}",
            parse_mode="Markdown",
        )
        bot.register_next_step_handler(msg, _handle_cookie_step)
        return

    collected = json.loads(state.get("caption") or "{}")
    collected[current_field] = value

    next_index = _COOKIE_ORDER.index(current_field) + 1
    if next_index < len(_COOKIE_ORDER):
        next_field = _COOKIE_ORDER[next_index]
        db.set_user_state(
            message.chat.id, caption=json.dumps(collected), stage=f"add_account:{next_field}"
        )
        msg = bot.send_message(message.chat.id, _COOKIE_PROMPTS[next_field], parse_mode="Markdown")
        bot.register_next_step_handler(msg, _handle_cookie_step)
        return

    # All 4 values collected — save and clean up.
    account_num = state["account"]
    try:
        session_store.save_cookie_session(account_num, collected)
    except ValueError as e:
        bot.send_message(message.chat.id, f"❌ Couldn't save session: {e}. Run /addaccount to try again.")
        db.clear_user_state(message.chat.id)
        return

    db.clear_user_state(message.chat.id)
    logger.info(f"Cookie-based session saved for account {account_num} via Telegram.")
    bot.send_message(
        message.chat.id,
        f"✅ Session saved for Account {account_num}. The credential messages above have been "
        f"deleted from this chat. Use /status to check it's recognized as logged in — the "
        f"next health check (or a manual test post) will confirm it's actually valid.",
    )


_STATUS_ICON = {
    "logged_in": "✅",
    "expired": "⚠️",
    "challenge": "🚫",
    "no_session": "➖",
    None: "❔",
}


@bot.message_handler(commands=["status"])
def show_status(message):
    if not is_authorized(message):
        return

    account_lines = []
    for acc in range(1, ACCOUNT_COUNT + 1):
        row = db.get_account_status(acc)
        status = row["status"] if row else None
        account_lines.append(f"{_STATUS_ICON.get(status, '❔')} Account {acc}: {status or 'not checked yet'}")

    jobs = db.get_pending_jobs_for_chat(message.chat.id)
    text = "👤 Account health:\n" + "\n".join(account_lines)

    if not jobs:
        text += "\n\nNo pending, scheduled, or review-needed jobs."
        bot.reply_to(message, text)
        return

    lines = []
    for j in jobs:
        when = "ASAP" if not j["scheduled_for"] else \
            datetime.datetime.fromtimestamp(j["scheduled_for"]).strftime("%Y-%m-%d %H:%M")
        lines.append(f"#{j['id']} · Account {j['account']} · {j['status']} · {when}")
    text += "\n\n📋 Your jobs:\n" + "\n".join(lines)
    bot.reply_to(message, text)

    # Offer explicit action buttons for anything needing manual review,
    # instead of requiring direct database/code intervention.
    review_jobs = [j for j in jobs if j["status"] == "needs_review"]
    for j in review_jobs:
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("✅ Checked — not posted, retry", callback_data=f"review_retry_{j['id']}"),
            types.InlineKeyboardButton("🗑️ Discard", callback_data=f"review_discard_{j['id']}"),
        )
        bot.send_message(
            message.chat.id,
            f"Job #{j['id']} (Account {j['account']}) needs review:\n{j.get('error') or 'Unknown outcome.'}",
            reply_markup=markup,
        )


@bot.callback_query_handler(func=lambda call: call.data.startswith("review_"))
def handle_review_action(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    _, action, job_id_str = call.data.split("_", 2)
    job_id = int(job_id_str)
    job = db.get_job(job_id)
    if not job or job["status"] != "needs_review":
        bot.send_message(call.message.chat.id, "That job is no longer awaiting review.")
        return

    if action == "discard":
        db.update_job(job_id, status="cancelled")
        if job.get("video_path") and os.path.exists(job["video_path"]):
            try:
                os.remove(job["video_path"])
            except OSError:
                pass
        bot.send_message(call.message.chat.id, f"🗑️ Job #{job_id} discarded.")

    elif action == "retry":
        if not job.get("video_path") or not os.path.exists(job["video_path"]):
            bot.send_message(
                call.message.chat.id,
                f"❌ Can't retry job #{job_id} — the original video file is no longer on disk. "
                f"Please resend the video from scratch.",
            )
            db.update_job(job_id, status="cancelled")
            return
        # Re-queue as a fresh 'pending' job — a human has explicitly
        # confirmed it's safe, so this is the ONE path where a
        # previously-uncertain job is allowed to run again.
        db.update_job(job_id, status="pending", attempts=0, error=None)
        bot.send_message(call.message.chat.id, f"🔁 Job #{job_id} re-queued for publishing.")


# ---------------- Video intake ----------------

# Standard cloud Telegram Bot API caps file downloads via getFile at 20MB,
# regardless of what limit we set in video_check.py. Going over this fails
# with an API error, not a clean "video too big" message, so check it
# up front using the size Telegram already reports on the message object.
TELEGRAM_CLOUD_API_DOWNLOAD_LIMIT_BYTES = 20 * 1024 * 1024


@bot.message_handler(content_types=["video"])
def handle_video(message):
    if not is_authorized(message):
        return

    existing = db.get_user_state(message.chat.id)
    if existing and existing.get("video_path"):
        # Any in-progress flow (choosing account, writing caption, confirming)
        # has a video_path set. Don't silently clobber it with a new upload.
        bot.reply_to(
            message,
            "⚠️ You already have an unfinished post in progress. Send /cancel first if you "
            "want to discard it and start over with this new video.",
        )
        return
    if existing and str(existing.get("stage", "")).startswith("add_account:"):
        bot.reply_to(
            message,
            "⚠️ You're in the middle of /addaccount. Send /cancel first if you want to "
            "abandon that and post a video instead.",
        )
        return

    if message.video.file_size and message.video.file_size > TELEGRAM_CLOUD_API_DOWNLOAD_LIMIT_BYTES:
        mb = message.video.file_size / (1024 * 1024)
        bot.reply_to(
            message,
            f"❌ This video is {mb:.1f}MB. The standard Telegram Bot API can only download "
            f"files up to 20MB — larger files need a self-hosted Local Bot API Server "
            f"(see SETUP.md) to lift that limit. Try a smaller/more compressed file for now.",
        )
        return

    bot.reply_to(message, "⏳ Downloading video...")

    try:
        file_info = bot.get_file(message.video.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
    except Exception as e:
        logger.warning(f"Video download failed for chat {message.chat.id}: {e}")
        bot.reply_to(
            message,
            "❌ Couldn't download that video from Telegram. It may be too large for the "
            "current setup, or Telegram had a transient error — try again or use a smaller file.",
        )
        return

    video_filename = f"reel_{int(time.time())}.mp4"
    local_video_path = os.path.join(DOWNLOAD_DIR, video_filename)
    with open(local_video_path, "wb") as f:
        f.write(downloaded_file)

    ok, reason = validate_video(local_video_path)
    if not ok:
        os.remove(local_video_path)
        bot.reply_to(message, f"❌ Video rejected: {reason}")
        return

    db.set_user_state(
        message.chat.id, video_path=local_video_path, account=None, caption=None, stage="choose_account"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in range(1, ACCOUNT_COUNT + 1):
        markup.add(types.InlineKeyboardButton(f"👤 Account {i}", callback_data=f"acc_{i}"))

    bot.send_message(message.chat.id, "🎥 Video received. Choose an account:", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("acc_"))
def handle_account_selection(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[1])

    if not account_exists(account_num):
        bot.send_message(
            call.message.chat.id,
            f"❌ No saved session for Account {account_num}. Run login.py for it first.",
        )
        return

    db.set_user_state(call.message.chat.id, account=account_num, stage="await_caption")
    msg = bot.send_message(call.message.chat.id, f"✅ Account {account_num} selected.\n\n✍️ Send the caption:")
    bot.register_next_step_handler(msg, handle_caption)


def handle_caption(message):
    if not is_authorized(message):
        return
    state = db.get_user_state(message.chat.id)
    if not state or not state.get("video_path"):
        bot.reply_to(message, "Session lost, please resend the video.")
        return

    caption = message.text
    # Caption is persisted in SQLite (not an in-memory dict) so it survives a
    # bot restart between "caption sent" and "confirm" — same reasoning as the
    # jobs table.
    db.set_user_state(message.chat.id, caption=caption, stage="await_confirm")

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("📤 Post Now", callback_data="mode_now"),
        types.InlineKeyboardButton("🕒 Schedule", callback_data="mode_schedule"),
    )
    markup.add(types.InlineKeyboardButton("❌ Cancel", callback_data="mode_cancel"))
    # Plain text, NOT parse_mode="Markdown" — the caption is arbitrary user
    # content and may contain _, *, `, [ etc. Telegram's legacy Markdown
    # parser throws a "can't parse entities" error on unbalanced markers,
    # which would silently break this step for any caption containing them.
    bot.send_message(
        message.chat.id,
        f"📋 Review\nAccount: {state['account']}\nCaption: {caption}\n\nWhat would you like to do?",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("mode_"))
def handle_mode(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id
    state = db.get_user_state(chat_id)
    caption = state.get("caption") if state else None

    if call.data == "mode_cancel" or not state or caption is None:
        if state and state.get("video_path") and os.path.exists(state["video_path"]):
            os.remove(state["video_path"])
        db.clear_user_state(chat_id)
        bot.send_message(chat_id, "❌ Cancelled.")
        return

    if call.data == "mode_now":
        db.create_job(chat_id, state["account"], state["video_path"], caption, scheduled_for=None)
        bot.send_message(chat_id, "🚀 Queued for immediate publishing. I'll message you with updates.")
        db.clear_user_state(chat_id)

    elif call.data == "mode_schedule":
        msg = bot.send_message(
            chat_id, "🕒 Send the date/time in format `YYYY-MM-DD HH:MM` (24h, server local time):",
            parse_mode="Markdown",
        )
        bot.register_next_step_handler(msg, handle_schedule_time)


def handle_schedule_time(message):
    if not is_authorized(message):
        return
    chat_id = message.chat.id
    state = db.get_user_state(chat_id)
    if not state or not state.get("video_path") or not state.get("caption"):
        bot.reply_to(message, "Session lost, please resend the video.")
        return

    try:
        dt = datetime.datetime.strptime(message.text.strip(), "%Y-%m-%d %H:%M")
        ts = dt.timestamp()
        if ts < time.time():
            bot.reply_to(message, "That time is in the past. Please /cancel and try again.")
            return
    except ValueError:
        bot.reply_to(message, "Invalid format. Please /cancel and try again with YYYY-MM-DD HH:MM.")
        return

    db.create_job(chat_id, state["account"], state["video_path"], state["caption"], scheduled_for=ts)
    bot.send_message(chat_id, f"✅ Scheduled for {dt.strftime('%Y-%m-%d %H:%M')}.")
    db.clear_user_state(chat_id)


def _recover_after_restart():
    """Any job stuck in 'publishing' means the process died mid-attempt.
    Never assume it's safe to retry — mark it needs_review and tell the
    relevant chat, same policy as the live PublishUncertainError path."""
    recovered = db.recover_stuck_publishing_jobs()
    for job in recovered:
        logger.warning(f"Recovered stuck job {job['id']} (was 'publishing') as needs_review.")
        try:
            bot.send_message(
                job["chat_id"],
                f"⚠️ The bot restarted while job #{job['id']} (Account {job['account']}) was "
                f"publishing. Outcome unknown — please check the account manually before "
                f"resending, to avoid a duplicate post. Use /status to see it.",
            )
        except Exception as e:
            logger.warning(f"Could not notify chat {job['chat_id']} about recovered job: {e}")


if __name__ == "__main__":
    logger.info("Bot starting...")
    _recover_after_restart()
    start_scheduler(bot)
    start_health_checker(bot)
    print("🤖 Buzznity bot online.")
    bot.infinity_polling(timeout=60, long_polling_timeout=60)
