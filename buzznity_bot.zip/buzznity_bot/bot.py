# bot.py — Telegram control panel for the Instagram reel publisher.
import os
import re
import time
import json
import base64
import datetime
import threading
import requests
import telebot
from telebot import types, apihelper

from config import (
    BOT_TOKEN, ALLOWED_CHAT_ID, DOWNLOAD_DIR, ACCOUNT_COUNT, HIDE_LIKE_COUNTS,
    MAX_URL_VIDEO_MB, URL_DOWNLOAD_TIMEOUT_SECONDS, VIDEO_ENHANCE, BASE_DIR,
    PAYMENT_INSTRUCTIONS, SUPER_ADMIN_CONTACT, BILLING_API_KEY, SUPER_ADMIN_GROUP_ID,
    AUTO_REWRITE_REPOST_CAPTION,
)
from logger import logger
import database as db
import session_store
import analytics
import poster
import video_enhance
import instagram_source
import subscriptions
import billing_api
from scheduler import start_scheduler, _short
from health_checker import start_health_checker
from payment_poller import start_payment_poller
from auto_analytics import start_auto_analytics
from disk_cleanup import start_disk_cleanup
from video_check import validate_video

# Without an explicit timeout, a stalled network call (e.g. sending a large
# screenshot over a slow VPS connection) can hang the underlying HTTP
# request indefinitely — and since publishing runs sequentially in the
# scheduler thread, that hang blocks EVERY future job too, not just the
# current one, with no error and no log line to explain why. Seen directly
# in production: "Publish confirmed" logged, then nothing for 12+ minutes
# until the process was killed. These caps turn a silent infinite hang into
# a normal, catchable timeout error instead.
apihelper.READ_TIMEOUT = 30
apihelper.CONNECT_TIMEOUT = 15

db.init_db()
subscriptions.init_subscription_tables()
bot = telebot.TeleBot(BOT_TOKEN)


def _get_chat_id(message_or_call):
    return message_or_call.chat.id if hasattr(message_or_call, "chat") else message_or_call.message.chat.id


def is_owner(message_or_call):
    """The single .env-configured ALLOWED_CHAT_ID — the only one who can
    add/remove other admins, so an added admin can never chain-add others
    on their own."""
    return _get_chat_id(message_or_call) == ALLOWED_CHAT_ID


def is_authorized(message_or_call):
    """Owner, or anyone the owner has explicitly added via /addadmin."""
    chat_id = _get_chat_id(message_or_call)
    return chat_id == ALLOWED_CHAT_ID or db.is_admin(chat_id)


def account_exists(account_num):
    return session_store.session_kind(account_num) is not None


def _try_delete(message):
    """Best-effort delete of a message that contained a live session cookie.
    Never raises — Telegram sometimes refuses deletion (message too old,
    bot lacks delete rights in some chat types), and that must not break
    the flow, just leave the message visible."""
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception as e:
        logger.info(f"Could not delete cookie-input message {message.message_id}: {e}")


# ---------------- Commands ----------------

def _main_keyboard(show_owner_row=False):
    """Persistent bottom keyboard — stays visible across the conversation
    so the common commands are one tap away instead of typed."""
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    kb.add(
        types.KeyboardButton("📊 Status"),
        types.KeyboardButton("📈 Analytics"),
    )
    kb.add(
        types.KeyboardButton("📷 Quick Report"),
        types.KeyboardButton("➕ Add Account"),
    )
    kb.add(
        types.KeyboardButton("🗑️ Delete Post"),
        types.KeyboardButton("❌ Cancel"),
    )
    if show_owner_row:
        kb.add(types.KeyboardButton("🔑 Set OpenRouter Key"))
    kb.add(types.KeyboardButton("❓ Help"))
    return kb


def _customer_keyboard():
    """Persistent bottom keyboard for CUSTOMERS specifically — confirmed
    requirement: a proper reply keyboard (buttons fixed below the message
    box, the way owner/admin already has one), not inline buttons
    attached to one particular message that scroll away and can go
    stale. Kept deliberately smaller than the owner's — only what a
    subscribed customer actually has access to."""
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    kb.add(
        types.KeyboardButton("📱 My Accounts"),
        types.KeyboardButton("➕ Add Account"),
    )
    kb.add(
        types.KeyboardButton("📊 Status"),
        types.KeyboardButton("📈 Analytics"),
    )
    kb.add(
        types.KeyboardButton("💳 My Subscription"),
        types.KeyboardButton("❌ Cancel"),
    )
    kb.add(types.KeyboardButton("🆘 Support"))
    return kb


@bot.message_handler(commands=["groupid"])
def cmd_groupid(message):
    """Works in any chat (private, group, or supergroup) the bot is in —
    always visible regardless of a group's privacy-mode setting, since
    Telegram delivers commands to bots unconditionally. Used to find the
    chat_id for SUPER_ADMIN_GROUP_ID: add the bot to a group, send this
    command there, put the number it replies with into .env."""
    bot.reply_to(
        message,
        f"Chat ID: `{message.chat.id}`\nType: {message.chat.type}",
        parse_mode="Markdown",
    )


@bot.message_handler(commands=["start", "help"])
def send_welcome(message):
    if not is_authorized(message):
        # Not an existing owner/admin — treat this as a potential
        # subscription customer (Phase 1 of subscriptions.py) rather than
        # silently ignoring them, which is what happened before this
        # system existed.
        handle_customer_start(message)
        return
    bot.reply_to(
        message,
        "👋 *Instagram Reel Publisher*\n\n"
        "Send a reel video (MP4) — uploaded directly, as a direct *.mp4 link* "
        "(bypasses Telegram's 20MB upload cap), or an *Instagram Reel link* "
        "(downloads it with the original caption, for content you own or "
        "are authorized to repost) — to begin.\n\n"
        "Or use the buttons below — they cover the same commands "
        "(/status, /analytics, /addaccount, /cancel, /deletepost) without typing."
        + ("\n\nAs the owner, you can also:\n"
           "/addadmin <user_id> — let someone else use this bot too\n"
           "/removeadmin <user_id> — revoke their access\n"
           "/listadmins — see who currently has access\n"
           "/pendingpayments — review new customer payment submissions\n"
           "/admin — Super Admin panel (users, extend subscriptions)" if is_owner(message) else ""),
        parse_mode="Markdown",
        reply_markup=_main_keyboard(show_owner_row=is_owner(message)),
    )


def _write_openrouter_key(new_key):
    """Shared by both /setopenrouterkey and the button-driven flow. Writes
    (or replaces) OPENROUTER_API_KEY in .env. Raises on failure."""
    _write_env_var("OPENROUTER_API_KEY", new_key)


def _write_env_var(var_name, new_value):
    """General-purpose .env writer — replaces an existing VAR=... line if
    present, else appends a new one. Used for OPENROUTER_API_KEY,
    BILLING_API_KEY, and BILLING_API_BASE_URL. Raises on failure (e.g.
    .env not readable/writable) — callers should catch and report that
    clearly rather than silently losing the update."""
    env_path = os.path.join(BASE_DIR, ".env")
    with open(env_path, "r") as f:
        lines = f.readlines()
    found = False
    for i, line in enumerate(lines):
        if line.startswith(f"{var_name}="):
            lines[i] = f"{var_name}={new_value}\n"
            found = True
            break
    if not found:
        lines.append(f"{var_name}={new_value}\n")
    with open(env_path, "w") as f:
        f.writelines(lines)


@bot.message_handler(commands=["setopenrouterkey"])
def cmd_set_openrouter_key(message):
    # Owner-only — this is a billed credential, same sensitivity level as
    # the bot token itself.
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can change this.")
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2 or not parts[1].strip():
        bot.reply_to(
            message,
            "Usage: /setopenrouterkey <your_key>\n\nGet a key at https://openrouter.ai/keys — "
            "paste it here and I'll delete this message right after reading it, same as the "
            "/addaccount cookie flow.",
        )
        return
    new_key = parts[1].strip()

    try:
        _write_openrouter_key(new_key)
    except Exception as e:
        bot.reply_to(message, f"❌ Couldn't update .env: {_short(str(e), 500)}")
        return

    # Delete the message containing the live key immediately — same
    # safety practice as /addaccount's cookie values.
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception as e:
        logger.info(f"Could not delete OpenRouter key message: {e}")

    bot.send_message(
        message.chat.id,
        "✅ OpenRouter API key updated in .env (and the message with the key was deleted).\n\n"
        "⚠️ Restart for it to take effect: `sudo systemctl restart buzznity-bot`",
        parse_mode="Markdown",
    )


@bot.message_handler(func=lambda m: m.text == "🔑 Set OpenRouter Key")
def kb_set_openrouter_key(message):
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can change this.")
        return
    msg = bot.reply_to(
        message,
        "🔑 Paste your OpenRouter API key (from https://openrouter.ai/keys). "
        "I'll delete your message right after reading it, since it's a live credential.",
    )
    bot.register_next_step_handler(msg, _handle_openrouter_key_step)


def _handle_openrouter_key_step(message):
    if not is_owner(message):
        return
    new_key = (message.text or "").strip()
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception as e:
        logger.info(f"Could not delete OpenRouter key message: {e}")

    if not new_key:
        bot.send_message(message.chat.id, "That was empty — nothing changed. Try 🔑 Set OpenRouter Key again.")
        return
    try:
        _write_openrouter_key(new_key)
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Couldn't update .env: {_short(str(e), 500)}")
        return

    bot.send_message(
        message.chat.id,
        "✅ OpenRouter API key updated in .env (your message with the key was deleted).\n\n"
        "⚠️ Restart for it to take effect: `sudo systemctl restart buzznity-bot`",
        parse_mode="Markdown",
    )


@bot.message_handler(commands=["addadmin"])
def cmd_add_admin(message):
    # Owner-only — an added admin can use the bot but can never add/remove
    # other admins themselves, so access can't silently chain-expand.
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can add admins.")
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].lstrip("-").isdigit():
        bot.reply_to(
            message,
            "Usage: /addadmin <user_id> [label]\n\n"
            "The person can get their own numeric user ID by messaging "
            "@userinfobot on Telegram.",
        )
        return
    new_chat_id = int(parts[1])
    label = " ".join(parts[2:]) if len(parts) > 2 else None
    db.add_admin(new_chat_id, added_by=message.chat.id, label=label)
    bot.reply_to(message, f"✅ Added {new_chat_id}{f' ({label})' if label else ''} as an admin.")
    try:
        bot.send_message(
            new_chat_id,
            "👋 You've been added as an admin on the Instagram Reel Publisher bot. "
            "Send /start to see what you can do.",
        )
    except Exception as e:
        logger.info(f"Could not DM new admin {new_chat_id} (they may not have started the bot yet): {e}")


@bot.message_handler(commands=["removeadmin"])
def cmd_remove_admin(message):
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can remove admins.")
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].lstrip("-").isdigit():
        bot.reply_to(message, "Usage: /removeadmin <user_id>")
        return
    target = int(parts[1])
    if db.remove_admin(target):
        bot.reply_to(message, f"✅ Removed {target} as an admin.")
    else:
        bot.reply_to(message, f"{target} wasn't an admin.")


@bot.message_handler(commands=["listadmins"])
def cmd_list_admins(message):
    if not is_authorized(message):
        return
    lines = [f"👑 Owner: {ALLOWED_CHAT_ID}"]
    for a in db.list_admins():
        tag = f" ({a['label']})" if a.get("label") else ""
        lines.append(f"👤 {a['chat_id']}{tag}")
    bot.reply_to(message, "\n".join(lines))


def _send_analytics_picker(chat_id, is_customer):
    available = _available_accounts(chat_id, is_customer)
    if not available:
        bot.send_message(
            chat_id,
            "You don't have any Instagram accounts connected yet — use ➕ Add Instagram "
            "Account from /start first." if is_customer else
            "No accounts have a saved session yet — use /addaccount or login.py first.",
        )
        return
    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in available:
        if account_exists(i):
            markup.add(types.InlineKeyboardButton(f"👤 Account {i}", callback_data=f"analytics_acc_{i}"))
    bot.send_message(chat_id, "📊 Which account?", reply_markup=markup)


def _send_quick_report_picker(chat_id, is_customer):
    available = _available_accounts(chat_id, is_customer)
    if not available:
        bot.send_message(
            chat_id,
            "You don't have any Instagram accounts connected yet — use ➕ Add Instagram "
            "Account from /start first." if is_customer else
            "No accounts have a saved session yet — use /addaccount or login.py first.",
        )
        return
    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in available:
        if account_exists(i):
            markup.add(types.InlineKeyboardButton(f"👤 Account {i}", callback_data=f"quickreport_acc_{i}"))
    bot.send_message(chat_id, "📷 Which account?", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("quickreport_acc_"))
def quick_report_pick(call):
    chat_id, is_customer = _resolve_caller(call)
    if chat_id is None:
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[-1])
    if is_customer and not subscriptions.is_account_owned_by(account_num, chat_id):
        bot.answer_callback_query(call.id, "That account isn't yours.", show_alert=True)
        return
    if not account_exists(account_num):
        bot.send_message(call.message.chat.id, f"❌ No saved session for Account {account_num}.")
        return

    bot.send_message(chat_id, f"📷 Getting Account {account_num}'s current snapshot...")

    def run():
        def screenshot_cb(path, msg):
            try:
                with open(path, "rb") as f:
                    bot.send_photo(chat_id, f, caption=msg)
            except Exception as e:
                logger.warning(f"[quick_report] screenshot_cb failed: {e}")

        try:
            stats = analytics.quick_profile_report(account_num, screenshot_cb=screenshot_cb)
        except Exception as e:
            if is_customer:
                bot.send_message(chat_id, "❌ Something went wrong. Our team has been notified. Please try again later.")
                try:
                    bot.send_message(
                        SUPER_ADMIN_GROUP_ID or ALLOWED_CHAT_ID,
                        f"🚨 Quick Report failed for customer chat_id {chat_id}, Account "
                        f"{account_num}: {_short(str(e), 1000)}",
                    )
                except Exception:
                    pass
            else:
                bot.send_message(chat_id, f"❌ Couldn't get a snapshot for Account {account_num}: {_short(str(e), 1000)}")
            return

        username = stats.get("username")
        lines = [f"📷 Account {account_num}" + (f" (@{username})" if username else "")]
        if stats.get("followers") is not None:
            lines.append(f"👥 {stats['followers']:,} followers")
        if stats.get("following") is not None:
            lines.append(f"➡️ {stats['following']:,} following")
        if stats.get("posts") is not None:
            lines.append(f"🎞️ {stats['posts']:,} total posts")
        bot.send_message(chat_id, "\n".join(lines))

    threading.Thread(target=run, daemon=True).start()


@bot.callback_query_handler(func=lambda call: call.data == "analytics_menu")
def analytics_menu(call):
    chat_id, is_customer = _resolve_caller(call)
    if chat_id is None:
        return
    bot.answer_callback_query(call.id)
    _send_analytics_picker(chat_id, is_customer)


@bot.message_handler(commands=["cancel"])
def cancel_flow(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return
    state = db.get_user_state(message.chat.id)
    if state and state.get("video_path") and os.path.exists(state["video_path"]):
        try:
            os.remove(state["video_path"])
        except OSError:
            pass
    db.clear_user_state(message.chat.id)
    _advance_intake_queue(chat_id, is_customer)
    bot.reply_to(message, "❌ Current flow cancelled.")


# ---------------- Add account via pasted cookies ----------------
# Alternative to running login.py: paste the 4 core Instagram session
# cookies (from a browser's dev tools) instead. Each value is asked for
# separately and the message containing it is deleted immediately after
# being read, since these are live login credentials sitting in Telegram's
# chat history otherwise. Less robust than login.py's full browser profile
# (see session_store.py), but faster to set up.
_COOKIE_PROMPTS = {
    "sessionid": "🔑 Step 1/4 — paste the *sessionid* cookie value:",
    "csrftoken": "🔑 Step 2/4 — paste the *csrftoken* cookie value:",
    "ds_user_id": "🔑 Step 3/4 — paste the *ds_user_id* cookie value:",
    "mid": "🔑 Step 4/4 — paste the *mid* cookie value:",
}
_COOKIE_ORDER = list(_COOKIE_PROMPTS.keys())


@bot.message_handler(commands=["addaccount"])
def add_account_start(message):
    if not is_authorized(message):
        return
    existing = db.get_user_state(message.chat.id)
    if existing and existing.get("video_path"):
        bot.reply_to(message, "⚠️ You have an unfinished post in progress. Send /cancel first.")
        return

    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in range(1, ACCOUNT_COUNT + 1):
        tag = " (already has a session — this will overwrite it)" if account_exists(i) else ""
        markup.add(types.InlineKeyboardButton(f"👤 Account {i}{tag}", callback_data=f"addacc_{i}"))

    note = ""
    if all(account_exists(i) for i in range(1, ACCOUNT_COUNT + 1)):
        note = (
            f"\n\nℹ️ All {ACCOUNT_COUNT} configured account slot(s) already have a session. "
            f"To add a genuinely NEW account (not overwrite one of these), first increase "
            f"ACCOUNT_COUNT in .env on the VPS (e.g. `nano .env`, set it one higher, then "
            f"`sudo systemctl restart buzznity-bot`) — then run /addaccount again and the "
            f"new number will show up here."
        )
    bot.reply_to(
        message,
        "Which account number is this session for?\n\n"
        "You'll be asked to paste 4 values from Instagram's cookies "
        "(sessionid, csrftoken, ds_user_id, mid — from your browser's dev tools, "
        "Application → Cookies → instagram.com).\n\n"
        "⚠️ Each message you send will be deleted right after I read it, since "
        "these are live login credentials." + note,
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("addacc_"))
def add_account_choose(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[1])
    # The "caption" column is repurposed here purely as scratch storage for
    # the cookie values collected so far (JSON-encoded) — it has no
    # relation to a post caption during this flow.
    db.set_user_state(
        call.message.chat.id, video_path=None, account=account_num,
        caption=json.dumps({}), stage="add_account:sessionid",
    )
    msg = bot.send_message(
        call.message.chat.id, _COOKIE_PROMPTS["sessionid"], parse_mode="Markdown"
    )
    bot.register_next_step_handler(msg, _handle_cookie_step)


def _handle_cookie_step(message):
    if not is_authorized(message):
        return
    state = db.get_user_state(message.chat.id)
    if not state or not state.get("stage", "").startswith("add_account:"):
        _try_delete(message)
        bot.reply_to(message, "Session lost, please run /addaccount again.")
        return

    current_field = state["stage"].split(":", 1)[1]
    value = message.text.strip() if message.text else ""
    _try_delete(message)  # delete the credential immediately, success or not

    if not value:
        msg = bot.send_message(
            message.chat.id,
            f"That was empty — {_COOKIE_PROMPTS[current_field]}",
            parse_mode="Markdown",
        )
        bot.register_next_step_handler(msg, _handle_cookie_step)
        return

    collected = json.loads(state.get("caption") or "{}")
    collected[current_field] = value

    next_index = _COOKIE_ORDER.index(current_field) + 1
    if next_index < len(_COOKIE_ORDER):
        next_field = _COOKIE_ORDER[next_index]
        db.set_user_state(
            message.chat.id, caption=json.dumps(collected), stage=f"add_account:{next_field}"
        )
        msg = bot.send_message(message.chat.id, _COOKIE_PROMPTS[next_field], parse_mode="Markdown")
        bot.register_next_step_handler(msg, _handle_cookie_step)
        return

    # All 4 values collected — save and clean up.
    account_num = state["account"]
    try:
        session_store.save_cookie_session(account_num, collected)
    except ValueError as e:
        bot.send_message(message.chat.id, f"❌ Couldn't save session: {e}. Run /addaccount to try again.")
        db.clear_user_state(message.chat.id)
        return

    db.clear_user_state(message.chat.id)
    logger.info(f"Cookie-based session saved for account {account_num} via Telegram.")
    bot.send_message(
        message.chat.id,
        f"✅ Session saved for Account {account_num}. The credential messages above have been "
        f"deleted from this chat. Use /status to check it's recognized as logged in — the "
        f"next health check (or a manual test post) will confirm it's actually valid.",
    )


@bot.callback_query_handler(func=lambda call: call.data == "custaddacc")
def customer_add_account_start(call):
    bot.answer_callback_query(call.id)
    _start_customer_add_account(call.message.chat.id)


def _start_customer_add_account(chat_id):
    """Customer equivalent of add_account_choose — checked against their
    subscription's account_limit (see subscriptions.can_add_account)
    instead of the operator's fixed ACCOUNT_COUNT, and creates a brand
    new owned account row rather than picking an existing global slot
    number from a button. Shared by the custaddacc callback (dashboard
    button) and kb_add_account (persistent keyboard button) — confirmed
    bug: the keyboard button used to call the OWNER's add_account_start
    instead, which is is_authorized()-gated and silently did nothing at
    all for a customer."""
    allowed, reason, current, limit = subscriptions.can_add_account(chat_id)
    if not allowed:
        bot.send_message(chat_id, f"❌ {reason}")
        return

    account_num = subscriptions.create_instagram_account(chat_id)
    db.set_user_state(
        chat_id, video_path=None, account=account_num,
        caption=json.dumps({}), stage="cust_add_account:sessionid",
    )
    msg = bot.send_message(
        chat_id,
        f"Adding account {current + 1}/{limit}.\n\n" + _COOKIE_PROMPTS["sessionid"],
        parse_mode="Markdown",
    )
    bot.register_next_step_handler(msg, _handle_customer_cookie_step)


def _handle_customer_cookie_step(message):
    """Same mechanics as _handle_cookie_step (shared _COOKIE_PROMPTS/
    _COOKIE_ORDER, same session_store.save_cookie_session call at the
    end) but gated on subscription/ownership instead of is_authorized(),
    and updates the instagram_accounts row instead of nothing. Kept as a
    SEPARATE function rather than modifying the original — the owner/
    admin flow is already tested and shouldn't risk behavior changes for
    an unrelated audience."""
    chat_id = message.chat.id
    state = db.get_user_state(chat_id)
    if not state or not state.get("stage", "").startswith("cust_add_account:"):
        _try_delete(message)
        bot.reply_to(message, "Session lost, please tap ➕ Add Instagram Account again via /start.")
        return

    account_num = state["account"]
    if not subscriptions.is_account_owned_by(account_num, chat_id):
        # Should be unreachable in normal use (this state is only ever set
        # by customer_add_account_start for THIS chat_id) — defensive
        # check anyway, since trusting conversation state alone for a
        # security-relevant action is exactly the mistake to avoid.
        _try_delete(message)
        db.clear_user_state(chat_id)
        bot.reply_to(message, "❌ Ownership check failed — please start again via /start.")
        return

    current_field = state["stage"].split(":", 1)[1]
    value = message.text.strip() if message.text else ""
    _try_delete(message)  # delete the credential immediately, success or not

    if not value:
        msg = bot.send_message(
            message.chat.id,
            f"That was empty — {_COOKIE_PROMPTS[current_field]}",
            parse_mode="Markdown",
        )
        bot.register_next_step_handler(msg, _handle_customer_cookie_step)
        return

    collected = json.loads(state.get("caption") or "{}")
    collected[current_field] = value

    next_index = _COOKIE_ORDER.index(current_field) + 1
    if next_index < len(_COOKIE_ORDER):
        next_field = _COOKIE_ORDER[next_index]
        db.set_user_state(
            chat_id, caption=json.dumps(collected), stage=f"cust_add_account:{next_field}"
        )
        msg = bot.send_message(message.chat.id, _COOKIE_PROMPTS[next_field], parse_mode="Markdown")
        bot.register_next_step_handler(msg, _handle_customer_cookie_step)
        return

    try:
        session_store.save_cookie_session(account_num, collected)
    except ValueError as e:
        bot.send_message(message.chat.id, f"❌ Couldn't save session: {e}. Tap ➕ Add Instagram Account to try again.")
        db.clear_user_state(chat_id)
        return

    subscriptions.set_instagram_account_status(account_num, "active")
    db.clear_user_state(chat_id)
    logger.info(f"Cookie-based session saved for CUSTOMER account {account_num} (chat_id {chat_id}).")
    bot.send_message(
        message.chat.id,
        f"✅ Instagram account connected. The credential messages above have been deleted "
        f"from this chat. Send /start to see your account list.",
    )
    try:
        who = f"@{message.from_user.username}" if message.from_user.username else f"chat_id {chat_id}"
        bot.send_message(
            SUPER_ADMIN_GROUP_ID or ALLOWED_CHAT_ID,
            f"📱 New Instagram account connected\nCustomer: {who}\nAccount #{account_num}",
        )
    except Exception as e:
        logger.warning(f"Could not notify admin of new customer account {account_num}: {e}")


@bot.message_handler(commands=["analytics"])
def cmd_analytics(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].isdigit():
        bot.reply_to(message, "Usage: /analytics <account_number>, e.g. /analytics 1")
        return
    account_num = int(parts[1])
    if is_customer and not subscriptions.is_account_owned_by(account_num, chat_id):
        bot.reply_to(message, "❌ That account isn't yours.")
        return
    if not account_exists(account_num):
        bot.reply_to(message, f"❌ No saved session for Account {account_num}.")
        return
    _run_analytics(chat_id, account_num, is_customer)


@bot.callback_query_handler(func=lambda call: call.data.startswith("analytics_acc_"))
def analytics_button_pick(call):
    chat_id, is_customer = _resolve_caller(call)
    if chat_id is None:
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[-1])
    if is_customer and not subscriptions.is_account_owned_by(account_num, chat_id):
        bot.answer_callback_query(call.id, "That account isn't yours.", show_alert=True)
        return
    if not account_exists(account_num):
        bot.send_message(call.message.chat.id, f"❌ No saved session for Account {account_num}.")
        return
    _run_analytics(chat_id, account_num, is_customer)


def _run_analytics(chat_id, account_num, is_customer=False):
    """Shared by both the /analytics command and the 📊 Analytics button —
    keeps the two entry points from drifting out of sync. Purely
    additive/read-only: does not touch anything in the posting flow
    (bot.py's video/caption/account-checkbox handlers, poster.py,
    scheduler.py) — a completely separate feature living alongside it."""
    progress_msg = bot.send_message(
        chat_id,
        f"📊 Checking Account {account_num}'s recent posts — this opens a real browser "
        f"session and opens each post individually to read its view count, so it can take "
        f"a few minutes for an account with many posts...",
    )

    def run():
        def status_cb(msg):
            try:
                bot.edit_message_text(f"📊 Account {account_num}: {msg}", chat_id, progress_msg.message_id)
            except Exception:
                pass  # e.g. identical text, or message too old — harmless, just skip this update

        def screenshot_cb(path, msg):
            if is_customer:
                return  # debug screenshots are internal detail only
            try:
                with open(path, "rb") as f:
                    bot.send_photo(chat_id, f, caption=msg)
            except Exception as e:
                logger.warning(f"[analytics] screenshot_cb failed: {e}")

        def document_cb(path, msg):
            if is_customer:
                return
            try:
                with open(path, "rb") as f:
                    bot.send_document(chat_id, f, caption=msg)
            except Exception as e:
                logger.warning(f"[analytics] document_cb failed: {e}")

        try:
            profile_stats, entries = analytics.scrape_recent_posts(
                account_num, status_cb=status_cb, screenshot_cb=screenshot_cb, document_cb=document_cb
            )
        except Exception as e:
            if is_customer:
                bot.send_message(chat_id, "❌ Something went wrong. Our team has been notified. Please try again later.")
                try:
                    bot.send_message(
                        SUPER_ADMIN_GROUP_ID or ALLOWED_CHAT_ID,
                        f"🚨 Analytics failed for customer chat_id {chat_id}, Account "
                        f"{account_num}: {_short(str(e), 1500)}",
                    )
                except Exception:
                    pass
            else:
                bot.send_message(
                    chat_id,
                    f"❌ Couldn't fetch analytics for Account {account_num}: {_short(str(e), 1500)}",
                )
            return

        if not entries:
            bot.send_message(chat_id, f"No posts found for Account {account_num}.")
            return

        db.save_post_metrics(account_num, entries)

        username = profile_stats.get("username")
        header = f"📊 Account {account_num}" + (f" (@{username})" if username else " — ⚠️ username not detected")
        lines = [header]
        followers = profile_stats.get("followers")
        posts_total = profile_stats.get("posts")
        if followers is not None or posts_total is not None:
            stat_bits = []
            if followers is not None:
                stat_bits.append(f"{followers:,} followers")
            if posts_total is not None:
                stat_bits.append(f"{posts_total:,} total posts")
            lines.append(" · ".join(stat_bits))
        lines.append(f"\nAll {len(entries)} post(s) checked:")
        if posts_total is not None and len(entries) < posts_total:
            lines.append(
                f"⚠️ Profile shows {posts_total} total posts, but only {len(entries)} loaded "
                f"after scrolling — the rest may need a retry."
            )
        for i, e in enumerate(entries, 1):
            v = f"{e['views']:,}" if e.get("views") is not None else "?"
            tag = " 🔥 likely viral" if e.get("is_likely_viral") else ""
            lines.append(f"{i}. 👁️ {v} views{tag}")
        bot.send_message(chat_id, _short("\n".join(lines)))

        summary = analytics.summarize_with_ai(account_num, profile_stats, entries)
        if summary:
            bot.send_message(chat_id, f"🤖 AI insight:\n\n{_short(summary, 3500)}")
        else:
            bot.send_message(
                chat_id,
                "(Set OPENROUTER_API_KEY in .env to also get an AI-generated summary of "
                "these numbers — see .env.example.)",
            )

    # Scraping opens a real browser and can take a while — run it off the
    # main bot thread so /status, /addaccount etc. stay responsive
    # meanwhile, same reasoning as the scheduler running in its own thread.
    threading.Thread(target=run, daemon=True).start()


_STATUS_ICON = {
    "logged_in": "✅",
    "expired": "⚠️",
    "challenge": "🚫",
    "no_session": "➖",
    None: "❔",
}


@bot.message_handler(commands=["status"])
def show_status(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return

    account_lines = []
    accounts_to_show = _available_accounts(chat_id, is_customer)
    for acc in accounts_to_show:
        row = db.get_account_status(acc)
        status = row["status"] if row else None
        username = row.get("username") if row else None
        label = f"Account {acc}" + (f" (@{username})" if username else "")
        account_lines.append(f"{_STATUS_ICON.get(status, '❔')} {label}: {status or 'not checked yet'}")
    if not account_lines:
        account_lines.append("(none yet — use ➕ Add Instagram Account from /start)" if is_customer else "(none configured)")

    jobs = db.get_pending_jobs_for_chat(message.chat.id)
    text = "👤 Account health:\n" + "\n".join(account_lines)

    if not jobs:
        text += "\n\nNo pending, scheduled, or review-needed jobs."
        bot.reply_to(message, text)
        return

    lines = []
    for j in jobs:
        if j["status"] == "needs_review":
            # "ASAP" here would wrongly imply this is about to be
            # processed automatically — needs_review jobs are DELIBERATELY
            # never auto-processed (duplicate-post safety), so make that
            # explicit instead of reusing the "immediate" wording.
            when = "awaiting your review — use the buttons above, or /status again for them"
        elif not j["scheduled_for"]:
            when = "ASAP"
        else:
            when = datetime.datetime.fromtimestamp(j["scheduled_for"]).strftime("%Y-%m-%d %H:%M")
        lines.append(f"#{j['id']} · Account {j['account']} · {j['status']} · {when}")
    text += "\n\n📋 Your jobs:\n" + "\n".join(lines)
    bot.reply_to(message, text)

    # Offer explicit action buttons for anything needing manual review,
    # instead of requiring direct database/code intervention.
    review_jobs = [j for j in jobs if j["status"] == "needs_review"]
    for j in review_jobs:
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("✅ Checked — not posted, retry", callback_data=f"review_retry_{j['id']}"),
            types.InlineKeyboardButton("🗑️ Discard", callback_data=f"review_discard_{j['id']}"),
        )
        bot.send_message(
            message.chat.id,
            f"Job #{j['id']} (Account {j['account']}) needs review:\n{j.get('error') or 'Unknown outcome.'}",
            reply_markup=markup,
        )


@bot.callback_query_handler(func=lambda call: call.data.startswith("review_retry_"))
def review_retry(call):
    chat_id, is_customer = _resolve_caller(call)
    if chat_id is None:
        return
    bot.answer_callback_query(call.id)
    job_id = int(call.data.split("_")[-1])
    job = db.get_job(job_id)
    if not job:
        bot.send_message(call.message.chat.id, f"Job #{job_id} not found — may already be handled.")
        return
    if is_customer and job["chat_id"] != chat_id:
        bot.answer_callback_query(call.id, "Not your job.", show_alert=True)
        return
    if job["status"] != "needs_review":
        bot.send_message(
            call.message.chat.id,
            f"Job #{job_id} is no longer awaiting review (status: {job['status']}).",
        )
        return
    if not job.get("video_path") or not os.path.exists(job["video_path"]):
        bot.send_message(
            call.message.chat.id,
            f"❌ Job #{job_id}'s video file is no longer on the VPS — can't retry. "
            f"Please resend the video fresh instead.",
        )
        return
    # Back to pending (or scheduled, if it had a future time) so the
    # scheduler's normal loop picks it up again on its next pass — reset
    # attempts too, since this is a fresh confirmed-safe start, not a
    # continuation of the earlier ambiguous attempt.
    new_status = "scheduled" if job.get("scheduled_for") else "pending"
    db.update_job(job_id, status=new_status, error=None, attempts=0)
    bot.send_message(call.message.chat.id, f"🔁 Job #{job_id} confirmed safe and requeued for publishing.")


@bot.callback_query_handler(func=lambda call: call.data.startswith("review_discard_"))
def review_discard(call):
    chat_id, is_customer = _resolve_caller(call)
    if chat_id is None:
        return
    bot.answer_callback_query(call.id)
    job_id = int(call.data.split("_")[-1])
    job = db.get_job(job_id)
    if not job:
        bot.send_message(call.message.chat.id, f"Job #{job_id} not found — may already be handled.")
        return
    if is_customer and job["chat_id"] != chat_id:
        bot.answer_callback_query(call.id, "Not your job.", show_alert=True)
        return
    if job["status"] != "needs_review":
        bot.send_message(
            call.message.chat.id,
            f"Job #{job_id} is no longer awaiting review (status: {job['status']}).",
        )
        return
    if job.get("video_path") and os.path.exists(job["video_path"]):
        try:
            os.remove(job["video_path"])
        except OSError as e:
            logger.warning(f"Could not remove discarded job {job_id}'s video file: {e}")
    db.update_job(job_id, status="failed", error="Discarded after manual review.")
    bot.send_message(call.message.chat.id, f"🗑️ Job #{job_id} discarded.")


# ---------------- Persistent keyboard button routing ----------------
# The buttons on _main_keyboard() aren't inline callbacks — Telegram just
# sends their label back as a plain text message, so route those exact
# strings to the same handlers the equivalent /command already uses.

@bot.message_handler(func=lambda m: m.text == "📊 Status")
def kb_status(message):
    show_status(message)


@bot.message_handler(func=lambda m: m.text == "❌ Cancel")
def kb_cancel(message):
    cancel_flow(message)


@bot.message_handler(func=lambda m: m.text == "➕ Add Account")
def kb_add_account(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return
    if is_customer:
        _start_customer_add_account(chat_id)
    else:
        add_account_start(message)


@bot.message_handler(func=lambda m: m.text == "📱 My Accounts")
def kb_my_accounts(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None or not is_customer:
        return
    handle_customer_start(message)


@bot.message_handler(func=lambda m: m.text == "💳 My Subscription")
def kb_my_subscription(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None or not is_customer:
        return
    handle_customer_start(message)


@bot.message_handler(func=lambda m: m.text == "🆘 Support")
def kb_support(message):
    if is_owner(message):
        return
    msg = bot.reply_to(message, "🆘 What do you need help with? Send your message and the team will reply here.")
    bot.register_next_step_handler(msg, _handle_support_message)


@bot.message_handler(func=lambda m: m.text == "❓ Help")
def kb_help(message):
    send_welcome(message)


@bot.message_handler(func=lambda m: m.text == "📈 Analytics")
def kb_analytics(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return
    _send_analytics_picker(chat_id, is_customer)


@bot.message_handler(func=lambda m: m.text == "📷 Quick Report")
def kb_quick_report(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return
    _send_quick_report_picker(chat_id, is_customer)


@bot.message_handler(func=lambda m: m.text == "🗑️ Delete Post")
def kb_delete_post(message):
    if not is_authorized(message):
        return
    markup = types.InlineKeyboardMarkup(row_width=1)
    any_account = False
    for i in range(1, ACCOUNT_COUNT + 1):
        if account_exists(i):
            any_account = True
            markup.add(types.InlineKeyboardButton(f"👤 Account {i}", callback_data=f"delpost_acc_{i}"))
    if not any_account:
        bot.send_message(
            message.chat.id,
            "No accounts have a saved session yet — use /addaccount or login.py first.",
        )
        return
    bot.send_message(message.chat.id, "🗑️ Which account?", reply_markup=markup)


def _shortcode_from_url(post_url):
    if not post_url:
        return None
    parts = [p for p in post_url.strip("/").split("/") if p]
    return parts[-1] if parts else None


@bot.callback_query_handler(func=lambda call: call.data.startswith("delpost_acc_"))
def delete_post_pick_account(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[-1])
    chat_id = call.message.chat.id

    manual_btn = types.InlineKeyboardButton(
        "✍️ Enter Shortcode Manually", callback_data=f"delmanual_{account_num}"
    )

    recent = db.get_latest_metrics(account_num, limit=10)
    if not recent:
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(manual_btn)
        bot.send_message(
            chat_id,
            f"No recent post data saved for Account {account_num} yet — run 📈 Analytics or "
            f"📷 Quick Report on it first so there's something to pick from here, or enter a "
            f"shortcode directly below.",
            reply_markup=markup,
        )
        return

    markup = types.InlineKeyboardMarkup(row_width=1)
    any_valid = False
    for r in recent:
        shortcode = _shortcode_from_url(r.get("post_url"))
        if not shortcode:
            continue
        any_valid = True
        v = f"{r['views']:,} views" if r.get("views") is not None else "views unknown"
        markup.add(
            types.InlineKeyboardButton(f"👁 {v} — {shortcode}", callback_data=f"delpick_{account_num}_{shortcode}")
        )
    markup.add(manual_btn)
    if not any_valid:
        bot.send_message(
            chat_id,
            f"Saved post data for Account {account_num} didn't include usable links — enter a "
            f"shortcode directly below instead.",
            reply_markup=markup,
        )
        return
    bot.send_message(
        chat_id,
        f"🗑️ Account {account_num} — pick a post to delete (from the last time Analytics/Quick "
        f"Report ran, may not be fully current — use ✍️ Enter Shortcode Manually if the post "
        f"you want isn't listed):",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("delmanual_"))
def delete_post_manual_entry(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[-1])
    msg = bot.send_message(
        call.message.chat.id,
        f"✍️ Send the shortcode for Account {account_num}'s post — the ID from its URL "
        f"(e.g. for instagram.com/reel/DExxxxxxxxx/, just DExxxxxxxxx, not the full link):",
    )
    bot.register_next_step_handler(msg, _handle_delete_manual_shortcode, account_num)


def _handle_delete_manual_shortcode(message, account_num):
    if not is_authorized(message):
        return
    shortcode = (message.text or "").strip().strip("/")
    if not shortcode or "/" in shortcode or " " in shortcode:
        bot.reply_to(
            message,
            "That doesn't look like a single shortcode — just the ID part, no slashes or "
            "spaces. Try 🗑️ Delete Post again.",
        )
        return

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(
            "⚠️ Yes, permanently delete it", callback_data=f"confirmdelete_{account_num}_{shortcode}"
        ),
        types.InlineKeyboardButton("Cancel", callback_data="canceldelete"),
    )
    bot.send_message(
        message.chat.id,
        f"⚠️ This will PERMANENTLY delete the post with shortcode `{shortcode}` from "
        f"Account {account_num}. This cannot be undone. Are you sure?",
        parse_mode="Markdown",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("delpick_"))
def delete_post_pick_post(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    _, account_str, shortcode = call.data.split("_", 2)
    account_num = int(account_str)

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(
            "⚠️ Yes, permanently delete it", callback_data=f"confirmdelete_{account_num}_{shortcode}"
        ),
        types.InlineKeyboardButton("Cancel", callback_data="canceldelete"),
    )
    bot.send_message(
        call.message.chat.id,
        f"⚠️ This will PERMANENTLY delete the post with shortcode `{shortcode}` from "
        f"Account {account_num}. This cannot be undone. Are you sure?",
        parse_mode="Markdown",
        reply_markup=markup,
    )


@bot.message_handler(commands=["deletepost"])
def cmd_delete_post(message):
    if not is_authorized(message):
        return
    parts = message.text.split()
    if len(parts) < 3 or not parts[1].isdigit():
        bot.reply_to(
            message,
            "Usage: /deletepost <account_number> <shortcode>\n\n"
            "The shortcode is the ID from the post's own URL — e.g. for "
            "instagram.com/reel/DExxxxxxxxx/, the shortcode is DExxxxxxxxx "
            "(just that code, not the full link).",
        )
        return
    account_num = int(parts[1])
    shortcode = parts[2].strip().strip("/")
    if not account_exists(account_num):
        bot.reply_to(message, f"❌ No saved session for Account {account_num}.")
        return

    # Destructive and irreversible — confirm before doing anything, same
    # spirit as the review_discard button elsewhere.
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(
            "⚠️ Yes, permanently delete it", callback_data=f"confirmdelete_{account_num}_{shortcode}"
        ),
        types.InlineKeyboardButton("Cancel", callback_data="canceldelete"),
    )
    bot.reply_to(
        message,
        f"⚠️ This will PERMANENTLY delete the post with shortcode `{shortcode}` from "
        f"Account {account_num}. This cannot be undone. Are you sure?",
        parse_mode="Markdown",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data == "canceldelete")
def cancel_delete(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    bot.send_message(call.message.chat.id, "❌ Cancelled — nothing was deleted.")


@bot.callback_query_handler(func=lambda call: call.data.startswith("confirmdelete_"))
def confirm_delete(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    _, account_str, shortcode = call.data.split("_", 2)
    account_num = int(account_str)
    chat_id = call.message.chat.id
    bot.send_message(chat_id, f"🗑️ Deleting post `{shortcode}` on Account {account_num}...", parse_mode="Markdown")

    def run():
        def status_cb(msg):
            try:
                bot.send_message(chat_id, f"Account {account_num}: {msg}")
            except Exception:
                pass

        def screenshot_cb(path, msg):
            try:
                with open(path, "rb") as f:
                    bot.send_photo(chat_id, f, caption=msg)
            except Exception as e:
                logger.warning(f"[delete] screenshot_cb failed: {e}")

        try:
            poster.delete_post(account_num, shortcode, status_cb=status_cb, screenshot_cb=screenshot_cb)
            bot.send_message(
                chat_id,
                f"✅ Delete attempted for `{shortcode}` — check the screenshot above to "
                f"confirm it actually went through.",
                parse_mode="Markdown",
            )
        except Exception as e:
            shot = getattr(e, "screenshot_path", None)
            dump = getattr(e, "elements_path", None)
            if shot and os.path.exists(shot):
                try:
                    with open(shot, "rb") as f:
                        bot.send_photo(chat_id, f, caption=f"Account {account_num} — delete failed here")
                except Exception:
                    pass
            if dump and os.path.exists(dump):
                try:
                    with open(dump, "rb") as f:
                        bot.send_document(chat_id, f, caption="Page elements at the point of failure")
                except Exception:
                    pass
            bot.send_message(chat_id, f"❌ Delete failed: {_short(str(e), 1500)}")

    threading.Thread(target=run, daemon=True).start()


@bot.callback_query_handler(func=lambda call: call.data.startswith("review_"))
def handle_review_action(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    _, action, job_id_str = call.data.split("_", 2)
    job_id = int(job_id_str)
    job = db.get_job(job_id)
    if not job or job["status"] != "needs_review":
        bot.send_message(call.message.chat.id, "That job is no longer awaiting review.")
        return

    if action == "discard":
        db.update_job(job_id, status="cancelled")
        if job.get("video_path") and os.path.exists(job["video_path"]):
            try:
                os.remove(job["video_path"])
            except OSError:
                pass
        bot.send_message(call.message.chat.id, f"🗑️ Job #{job_id} discarded.")

    elif action == "retry":
        if not job.get("video_path") or not os.path.exists(job["video_path"]):
            bot.send_message(
                call.message.chat.id,
                f"❌ Can't retry job #{job_id} — the original video file is no longer on disk. "
                f"Please resend the video from scratch.",
            )
            db.update_job(job_id, status="cancelled")
            return
        # Re-queue as a fresh 'pending' job — a human has explicitly
        # confirmed it's safe, so this is the ONE path where a
        # previously-uncertain job is allowed to run again.
        db.update_job(job_id, status="pending", attempts=0, error=None)
        bot.send_message(call.message.chat.id, f"🔁 Job #{job_id} re-queued for publishing.")


# ---------------- Video intake ----------------

# Standard cloud Telegram Bot API caps file downloads via getFile at 20MB,
# regardless of what limit we set in video_check.py. Going over this fails
# with an API error, not a clean "video too big" message, so check it
# up front using the size Telegram already reports on the message object.
TELEGRAM_CLOUD_API_DOWNLOAD_LIMIT_BYTES = 20 * 1024 * 1024


@bot.message_handler(content_types=["video"])
def handle_video(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return

    existing = db.get_user_state(message.chat.id)
    # NOTE: an "unfinished post in progress" is deliberately NOT blocked
    # here anymore — see _finish_intake, which queues this submission
    # instead of rejecting it, so several videos/links sent back-to-back
    # each get their own turn automatically. The /addaccount cookie flow
    # below is a different matter (collecting live credentials step by
    # step) and still needs to be finished/cancelled explicitly first.
    if existing and str(existing.get("stage", "")).startswith("add_account:"):
        bot.reply_to(
            message,
            "⚠️ You're in the middle of /addaccount. Send /cancel first if you want to "
            "abandon that and post a video instead.",
        )
        return

    if message.video.file_size and message.video.file_size > TELEGRAM_CLOUD_API_DOWNLOAD_LIMIT_BYTES:
        mb = message.video.file_size / (1024 * 1024)
        bot.reply_to(
            message,
            f"❌ This video is {mb:.1f}MB. The standard Telegram Bot API can only download "
            f"files up to 20MB — larger files need a self-hosted Local Bot API Server "
            f"(see SETUP.md) to lift that limit. Try a smaller/more compressed file for now.",
        )
        return

    bot.reply_to(message, "⏳ Downloading video...")

    try:
        file_info = bot.get_file(message.video.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
    except Exception as e:
        logger.warning(f"Video download failed for chat {message.chat.id}: {e}")
        bot.reply_to(
            message,
            "❌ Couldn't download that video from Telegram. It may be too large for the "
            "current setup, or Telegram had a transient error — try again or use a smaller file.",
        )
        return

    video_filename = f"reel_{int(time.time())}.mp4"
    local_video_path = os.path.join(DOWNLOAD_DIR, video_filename)
    with open(local_video_path, "wb") as f:
        f.write(downloaded_file)

    ok, reason = validate_video(local_video_path)
    if not ok:
        os.remove(local_video_path)
        bot.reply_to(message, f"❌ Video rejected: {reason}")
        return

    _intake_video(message.chat.id, local_video_path, is_customer)


def _intake_video(chat_id, local_video_path, is_customer, preset_caption=None):
    """Shared tail of ALL THREE video-intake paths (Telegram upload,
    direct MP4 link, Instagram-repost link). If VIDEO_ENHANCE is on, runs
    the (potentially slow, no-GPU) quality pass in a background thread
    first — never blocking the bot's own message loop for other chats/
    commands while that runs — then proceeds to the same checkbox/
    caption/confirm flow regardless of how the file arrived or whether
    it was enhanced. preset_caption (Instagram-repost only) skips the
    "send a caption" step, going straight to the review screen with the
    source caption already filled in."""
    if VIDEO_ENHANCE:
        bot.send_message(
            chat_id,
            "🎨 Enhancing video quality before posting — this can take a minute or two "
            "depending on length (VIDEO_ENHANCE is on in .env)...",
        )

        def run_enhance():
            enhanced_path = video_enhance.enhance_video(local_video_path)
            _finish_intake(chat_id, enhanced_path, is_customer, preset_caption)

        threading.Thread(target=run_enhance, daemon=True).start()
    else:
        _finish_intake(chat_id, local_video_path, is_customer, preset_caption)


def _finish_intake(chat_id, local_video_path, is_customer, preset_caption=None):
    # Confirmed requirement: sending several videos/links back-to-back
    # must never reject/block on "finish your current post first" — if a
    # flow is ALREADY pending for this chat, queue this one instead. It
    # gets its own account-picker turn automatically the moment the
    # current one is confirmed (posted/scheduled) or cancelled — see
    # _advance_intake_queue, called from every one of those completion
    # points.
    existing = db.get_user_state(chat_id)
    if existing and existing.get("video_path"):
        db.enqueue_intake(chat_id, local_video_path, preset_caption, None, is_customer)
        position = db.count_queued_intake(chat_id)
        bot.send_message(
            chat_id,
            f"📥 Downloaded and queued (#{position} in line) — I'll ask you to pick "
            f"accounts for this one right after your current selection is done.",
        )
        return

    available = _available_accounts(chat_id, is_customer)
    if not available:
        os.remove(local_video_path)
        bot.send_message(
            chat_id,
            "❌ You don't have any Instagram accounts connected yet. Use ➕ Add Instagram "
            "Account from /start first." if is_customer else
            "❌ No accounts configured (ACCOUNT_COUNT). Check .env.",
        )
        return
    db.set_user_state(
        chat_id, video_path=local_video_path, account=None, caption=preset_caption,
        stage="choose_accounts", extra=json.dumps([]),
    )
    markup = _build_account_checkbox_markup([], available)
    label = "🎥 Reel downloaded." if preset_caption is not None else "🎥 Video received."
    bot.send_message(
        chat_id,
        f"{label} Tap accounts to select (multiple allowed), then Done:",
        reply_markup=markup,
    )


def _advance_intake_queue(chat_id, is_customer):
    """Called right after a flow finishes (posted/scheduled) or is
    cancelled — pops the next queued item, if any, and shows ITS
    account-picker automatically. This is what makes several back-to-back
    submissions each get their turn without needing to be resent."""
    item = db.pop_next_intake(chat_id)
    if item:
        _finish_intake(
            chat_id, item["video_path"], bool(item["is_customer"]),
            preset_caption=item.get("caption"),
        )


_MP4_URL_RE = re.compile(r"https?://\S+\.mp4(?:\?\S*)?", re.IGNORECASE)


@bot.message_handler(func=lambda m: m.text and _MP4_URL_RE.search(m.text))
def handle_video_url(message):
    """A direct .mp4 link, instead of a Telegram file upload — downloaded
    straight from wherever it's hosted, so this ALSO sidesteps the 20MB
    Telegram Bot API download cap entirely (only MAX_URL_VIDEO_MB applies
    here, which can be set much higher)."""
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return

    existing = db.get_user_state(message.chat.id)
    # See handle_video's matching comment — an in-progress post no longer
    # blocks a new submission, it queues instead (via _finish_intake).
    if existing and str(existing.get("stage", "")).startswith("add_account:"):
        bot.reply_to(
            message,
            "⚠️ You're in the middle of /addaccount. Send /cancel first if you want to "
            "abandon that and post this link instead.",
        )
        return

    url = _MP4_URL_RE.search(message.text).group(0)
    bot.reply_to(message, f"⏳ Downloading video from the link (up to {MAX_URL_VIDEO_MB}MB)...")

    video_filename = f"reel_{int(time.time())}.mp4"
    local_video_path = os.path.join(DOWNLOAD_DIR, video_filename)
    max_bytes = MAX_URL_VIDEO_MB * 1024 * 1024

    try:
        with requests.get(url, stream=True, timeout=URL_DOWNLOAD_TIMEOUT_SECONDS) as resp:
            resp.raise_for_status()
            content_length = resp.headers.get("Content-Length")
            if content_length and int(content_length) > max_bytes:
                bot.reply_to(
                    message,
                    f"❌ That file is {int(content_length) / (1024*1024):.1f}MB, over the "
                    f"{MAX_URL_VIDEO_MB}MB limit (MAX_URL_VIDEO_MB in .env). Try a smaller file.",
                )
                return
            written = 0
            with open(local_video_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=1024 * 256):
                    written += len(chunk)
                    if written > max_bytes:
                        f.close()
                        os.remove(local_video_path)
                        bot.reply_to(
                            message,
                            f"❌ Stopped downloading — exceeded the {MAX_URL_VIDEO_MB}MB limit "
                            f"(MAX_URL_VIDEO_MB in .env) partway through.",
                        )
                        return
                    f.write(chunk)
    except Exception as e:
        logger.warning(f"URL video download failed for chat {message.chat.id} ({url}): {e}")
        if os.path.exists(local_video_path):
            os.remove(local_video_path)
        bot.reply_to(
            message,
            f"❌ Couldn't download that link: {str(e)[:300]}. Check the link is a direct, "
            f"publicly-accessible .mp4 file (not a page that just links to one).",
        )
        return

    ok, reason = validate_video(local_video_path)
    if not ok:
        os.remove(local_video_path)
        bot.reply_to(message, f"❌ Video rejected: {reason}")
        return

    _intake_video(message.chat.id, local_video_path, is_customer)


def _resolve_caller(message_or_call):
    """Returns (chat_id, is_customer: bool) if this caller may use the
    posting flow — either an owner/admin (is_customer=False, uses the
    operator's own ACCOUNT_COUNT-based accounts) or a customer with an
    ACTIVE subscription (is_customer=True, uses ONLY their owned
    accounts). Returns (None, None) if neither, so callers can just
    `if chat_id is None: return`.

    Deliberately re-checks subscriptions.get_active_subscription() fresh
    on every call rather than caching an "is_customer" flag in
    conversation state — a subscription that lapses mid-flow should stop
    granting access on the very next step, not just at the start."""
    chat_id = _get_chat_id(message_or_call)
    if is_authorized(message_or_call):
        return chat_id, False
    if subscriptions.get_active_subscription(chat_id):
        return chat_id, True
    return None, None


def _available_accounts(chat_id, is_customer):
    if is_customer:
        return [a["account_number"] for a in subscriptions.get_owned_accounts(chat_id)]
    return list(range(1, ACCOUNT_COUNT + 1))


def _build_account_checkbox_markup(selected, available_accounts):
    """selected: list of int account numbers currently checked.
    available_accounts: the accounts THIS caller may choose from — the
    operator's 1..ACCOUNT_COUNT range, or a customer's owned accounts
    only (see _available_accounts) — never assume the full global range."""
    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in available_accounts:
        mark = "☑️" if i in selected else "☐"
        markup.add(types.InlineKeyboardButton(f"{mark} Account {i}", callback_data=f"toggleacc_{i}"))
    done_label = f"✅ Done ({len(selected)} selected)" if selected else "✅ Done"
    markup.add(
        types.InlineKeyboardButton(done_label, callback_data="accounts_done"),
        types.InlineKeyboardButton("❌ Cancel", callback_data="accounts_cancel"),
    )
    return markup


@bot.callback_query_handler(func=lambda call: call.data.startswith("toggleacc_"))
def toggle_account_checkbox(call):
    chat_id, is_customer = _resolve_caller(call)
    if chat_id is None:
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[1])
    if is_customer and not subscriptions.is_account_owned_by(account_num, chat_id):
        # Never trust callback_data alone for a security-relevant check —
        # even though the button list itself only shows owned accounts,
        # a tampered callback could claim any number.
        bot.answer_callback_query(call.id, "That account isn't yours.", show_alert=True)
        return
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "choose_accounts":
        return

    if not account_exists(account_num):
        bot.answer_callback_query(call.id, f"No saved session for Account {account_num}.", show_alert=True)
        return

    selected = json.loads(state.get("extra") or "[]")
    if account_num in selected:
        selected.remove(account_num)
    else:
        selected.append(account_num)
    db.set_user_state(call.message.chat.id, extra=json.dumps(selected))

    markup = _build_account_checkbox_markup(selected, _available_accounts(chat_id, is_customer))
    try:
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=markup)
    except Exception:
        pass  # e.g. "message not modified" if double-tapped — harmless


@bot.callback_query_handler(func=lambda call: call.data == "accounts_cancel")
def cancel_account_selection(call):
    chat_id, is_customer = _resolve_caller(call)
    if chat_id is None:
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if state and state.get("video_path") and os.path.exists(state["video_path"]):
        try:
            os.remove(state["video_path"])
        except OSError:
            pass
    db.clear_user_state(call.message.chat.id)
    bot.send_message(call.message.chat.id, "❌ Cancelled.")
    _advance_intake_queue(chat_id, is_customer)


@bot.callback_query_handler(func=lambda call: call.data == "accounts_done")
def confirm_accounts(call):
    chat_id, is_customer = _resolve_caller(call)
    if chat_id is None:
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "choose_accounts":
        return

    selected = json.loads(state.get("extra") or "[]")
    if is_customer:
        # Final ownership re-check across the whole selection before it's
        # locked in — the per-toggle check already covers this in
        # practice, but a confirm-time re-validation costs nothing and
        # means this function never has to trust accumulated state alone.
        selected = [a for a in selected if subscriptions.is_account_owned_by(a, chat_id)]
    if not selected:
        bot.answer_callback_query(call.id, "Select at least one account first.", show_alert=True)
        return

    # From here on, "extra" switches shape from a plain accounts list to a
    # dict that also carries the per-post hide-likes choice — starts off
    # matching the .env global default (HIDE_LIKE_COUNTS), tap the button
    # at confirm time to override it just for this post.
    names = ", ".join(str(a) for a in sorted(selected))

    # Instagram-repost jobs arrive with a caption already (the source
    # post's own caption) — skip asking for one, go straight to review.
    preset_caption = state.get("caption")
    if preset_caption:
        db.set_user_state(
            call.message.chat.id, stage="await_confirm",
            extra=json.dumps({"accounts": selected, "hide_likes": HIDE_LIKE_COUNTS}),
        )
        bot.send_message(
            call.message.chat.id,
            f"📋 Review\nAccount(s): {names}\nCaption: {preset_caption}\n\nWhat would you like to do?",
            reply_markup=_confirm_markup(HIDE_LIKE_COUNTS),
        )
        return

    db.set_user_state(
        call.message.chat.id, stage="await_caption",
        extra=json.dumps({"accounts": selected, "hide_likes": HIDE_LIKE_COUNTS}),
    )
    msg = bot.send_message(call.message.chat.id, f"✅ Account(s) {names} selected.\n\n✍️ Send the caption:")
    bot.register_next_step_handler(msg, handle_caption)


def _confirm_markup(hide_likes):
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("📤 Post Now", callback_data="mode_now"),
        types.InlineKeyboardButton("🕒 Schedule", callback_data="mode_schedule"),
    )
    hide_label = "🙈 Hide likes: ON" if hide_likes else "👁️ Hide likes: OFF"
    markup.add(types.InlineKeyboardButton(hide_label, callback_data="toggle_hide_likes"))
    markup.add(types.InlineKeyboardButton("❌ Cancel", callback_data="mode_cancel"))
    return markup


def handle_caption(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return
    state = db.get_user_state(message.chat.id)
    if not state or not state.get("video_path"):
        bot.reply_to(message, "Session lost, please resend the video.")
        return

    caption = message.text
    # Caption is persisted in SQLite (not an in-memory dict) so it survives a
    # bot restart between "caption sent" and "confirm" — same reasoning as the
    # jobs table.
    extra = json.loads(state.get("extra") or "{}")
    extra["caption"] = caption  # stash here too so the toggle handler can rebuild the review text
    db.set_user_state(message.chat.id, caption=caption, stage="await_confirm", extra=json.dumps(extra))

    selected = extra.get("accounts", [])
    accounts_str = ", ".join(str(a) for a in sorted(selected))
    # Plain text, NOT parse_mode="Markdown" — the caption is arbitrary user
    # content and may contain _, *, `, [ etc. Telegram's legacy Markdown
    # parser throws a "can't parse entities" error on unbalanced markers,
    # which would silently break this step for any caption containing them.
    bot.send_message(
        message.chat.id,
        f"📋 Review\nAccount(s): {accounts_str}\nCaption: {caption}\n\nWhat would you like to do?",
        reply_markup=_confirm_markup(extra.get("hide_likes", False)),
    )


@bot.callback_query_handler(func=lambda call: call.data == "toggle_hide_likes")
def toggle_hide_likes_btn(call):
    chat_id, is_customer = _resolve_caller(call)
    if chat_id is None:
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "await_confirm":
        return
    extra = json.loads(state.get("extra") or "{}")
    extra["hide_likes"] = not extra.get("hide_likes", False)
    db.set_user_state(call.message.chat.id, extra=json.dumps(extra))
    try:
        bot.edit_message_reply_markup(
            call.message.chat.id, call.message.message_id,
            reply_markup=_confirm_markup(extra["hide_likes"]),
        )
    except Exception:
        pass  # e.g. "message not modified" if double-tapped — harmless


@bot.callback_query_handler(func=lambda call: call.data.startswith("mode_"))
def handle_mode(call):
    chat_id, is_customer = _resolve_caller(call)
    if chat_id is None:
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(chat_id)
    caption = state.get("caption") if state else None
    extra = json.loads(state.get("extra") or "{}") if state else {}
    selected = extra.get("accounts", [])
    hide_likes = extra.get("hide_likes", False)

    if call.data == "mode_cancel" or not state or caption is None or not selected:
        if state and state.get("video_path") and os.path.exists(state["video_path"]):
            os.remove(state["video_path"])
        db.clear_user_state(chat_id)
        bot.send_message(chat_id, "❌ Cancelled.")
        _advance_intake_queue(chat_id, is_customer)
        return

    if is_customer:
        # Last-line ownership re-check, right before jobs actually get
        # created — the highest-value place for this, since it's the
        # point of no return for the automation actually running.
        selected = [a for a in selected if subscriptions.is_account_owned_by(a, chat_id)]
        if not selected:
            bot.send_message(chat_id, "❌ None of the selected accounts are yours anymore. Cancelled.")
            db.clear_user_state(chat_id)
            _advance_intake_queue(chat_id, is_customer)
            return

    if call.data == "mode_now":
        for acc in selected:
            db.create_job(chat_id, acc, state["video_path"], caption, scheduled_for=None, hide_likes=int(hide_likes))
        names = ", ".join(str(a) for a in sorted(selected))
        tag = " (likes hidden)" if hide_likes else ""
        bot.send_message(
            chat_id,
            f"🚀 Queued for immediate publishing to Account(s) {names}{tag}. I'll message you with updates.",
        )
        db.clear_user_state(chat_id)
        _advance_intake_queue(chat_id, is_customer)

    elif call.data == "mode_schedule":
        msg = bot.send_message(
            chat_id, "🕒 Send the date/time in format `YYYY-MM-DD HH:MM` (24h, server local time):",
            parse_mode="Markdown",
        )
        bot.register_next_step_handler(msg, handle_schedule_time)


def handle_schedule_time(message):
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return
    state = db.get_user_state(chat_id)
    extra = json.loads(state.get("extra") or "{}") if state else {}
    selected = extra.get("accounts", [])
    hide_likes = extra.get("hide_likes", False)
    if not state or not state.get("video_path") or not state.get("caption") or not selected:
        bot.reply_to(message, "Session lost, please resend the video.")
        return

    try:
        dt = datetime.datetime.strptime(message.text.strip(), "%Y-%m-%d %H:%M")
        ts = dt.timestamp()
        if ts < time.time():
            bot.reply_to(message, "That time is in the past. Please /cancel and try again.")
            return
    except ValueError:
        bot.reply_to(message, "Invalid format. Please /cancel and try again with YYYY-MM-DD HH:MM.")
        return

    if is_customer:
        selected = [a for a in selected if subscriptions.is_account_owned_by(a, chat_id)]
        if not selected:
            bot.reply_to(message, "❌ None of the selected accounts are yours anymore. Cancelled.")
            db.clear_user_state(chat_id)
            _advance_intake_queue(chat_id, is_customer)
            return

    for acc in selected:
        db.create_job(chat_id, acc, state["video_path"], state["caption"], scheduled_for=ts, hide_likes=int(hide_likes))
    names = ", ".join(str(a) for a in sorted(selected))
    tag = " (likes hidden)" if hide_likes else ""
    bot.send_message(chat_id, f"✅ Scheduled for {dt.strftime('%Y-%m-%d %H:%M')} on Account(s) {names}{tag}.")
    db.clear_user_state(chat_id)
    _advance_intake_queue(chat_id, is_customer)


def _recover_after_restart():
    """Any job stuck in 'publishing' means the process died mid-attempt.
    Never assume it's safe to retry — mark it needs_review and tell the
    relevant chat, same policy as the live PublishUncertainError path."""
    recovered = db.recover_stuck_publishing_jobs()
    for job in recovered:
        logger.warning(f"Recovered stuck job {job['id']} (was 'publishing') as needs_review.")
        try:
            bot.send_message(
                job["chat_id"],
                f"⚠️ The bot restarted while job #{job['id']} (Account {job['account']}) was "
                f"publishing. Outcome unknown — please check the account manually before "
                f"resending, to avoid a duplicate post. Use /status to see it.",
            )
        except Exception as e:
            logger.warning(f"Could not notify chat {job['chat_id']} about recovered job: {e}")


# ---------------- Instagram URL intake (repost, with attribution) ----------------
# Downloads a public Instagram Reel via yt-dlp, keeps the ORIGINAL creator
# credited in the caption, then feeds it through the exact same
# checkbox-account-select -> scheduler -> poster.py pipeline as any other
# video — inherits all of that pipeline's existing retry/uncertain-outcome/
# safety behavior for free. Intended for content the operator owns or is
# authorized to repost (see INSTAGRAM_REPOST_TEST.md) — this tool doesn't
# and can't verify that on its own; it's on the operator to only use it for
# content they actually have the rights to.

_INSTAGRAM_REEL_RE = re.compile(
    r"https?://(?:www\.)?instagram\.com/(?:reel|reels)/[A-Za-z0-9_-]+(?:/\S*)?",
    re.IGNORECASE,
)


@bot.message_handler(func=lambda m: bool(m.text and _INSTAGRAM_REEL_RE.search(m.text)))
def handle_instagram_reel_url(message):
    """Download a public Instagram Reel, then feed it through the exact
    same account-picker/confirm pipeline as any other video (_intake_video)
    — with its own caption pre-filled from the source, so no need to
    retype it. Sending several reel links back-to-back never blocks: each
    one either gets its own picker immediately, or queues (see
    _finish_intake) for its turn right after the current selection is
    done — nothing is silently dropped or forced to wait indefinitely."""
    chat_id, is_customer = _resolve_caller(message)
    if chat_id is None:
        return

    if str((db.get_user_state(message.chat.id) or {}).get("stage", "")).startswith("add_account:"):
        bot.reply_to(message, "⚠️ You're in /addaccount. Send /cancel first.")
        return

    url = _INSTAGRAM_REEL_RE.search(message.text).group(0)
    status = bot.reply_to(message, "🔍 Instagram Reel detected.\n⏳ Downloading...")

    def run():
        try:
            result = instagram_source.download_reel(url, DOWNLOAD_DIR)
            caption = result["caption"] or result["title"] or ""
            if AUTO_REWRITE_REPOST_CAPTION:
                rewritten = analytics.rewrite_caption_with_ai(caption)
                if rewritten:
                    caption = rewritten

            try:
                bot.delete_message(message.chat.id, status.message_id)
            except Exception:
                pass
            _intake_video(message.chat.id, result["path"], is_customer, preset_caption=caption)

        except Exception as e:
            logger.warning(f"Instagram URL download failed for chat {message.chat.id}: {e}")
            if is_customer:
                bot.edit_message_text(
                    "❌ Couldn't download that video. Please check the link and try again.",
                    message.chat.id, status.message_id
                )
                try:
                    bot.send_message(
                        SUPER_ADMIN_GROUP_ID or ALLOWED_CHAT_ID,
                        f"🚨 Instagram download failed for customer chat_id {message.chat.id}\n"
                        f"URL: {url}\nError: {_short(str(e), 1000)}",
                    )
                except Exception:
                    pass
            else:
                bot.edit_message_text(
                    "❌ Instagram download failed.\n\n" + str(e)[:700],
                    message.chat.id, status.message_id
                )

    threading.Thread(target=run, daemon=True).start()




# ---------------- Subscriptions — Phase 1 ----------------
# Customer registration, plan selection, manual payment submission, and
# admin approve/reject. NOT wired into account-limit enforcement on the
# existing posting flow yet, and NOT an automated payment gateway — the
# customer sends proof (screenshot or a reference text), the admin
# reviews it manually via the buttons below. See subscriptions.py's
# module docstring for what later phases would add.

def _plan_picker_markup():
    markup = types.InlineKeyboardMarkup(row_width=1)
    # Active-only here specifically — this is what a NEW customer picks
    # from, so a retired/deactivated plan must never be offered. (Admin's
    # "Grant Subscription" picker, elsewhere, deliberately includes
    # inactive plans too — an admin might legitimately want to grant an
    # old plan; a new customer should never land there on their own.)
    tier_icons = ["🟢", "🔵", "🟣", "🟠"]  # cycles if more than 4 plans exist
    for i, (key, plan) in enumerate(subscriptions.get_plans(include_inactive=False).items()):
        icon = tier_icons[i % len(tier_icons)]
        markup.add(types.InlineKeyboardButton(
            f"{icon} {plan['name'].upper()} — ${plan['price_usd']}/mo — {plan['account_limit']} accounts",
            callback_data=f"subplan_{key}",
        ))
    return markup


_DIVIDER = "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"

BUZZNITY_FEATURES_TEXT = (
    "🚀 *BUZZNITY*\n"
    "_Instagram automation, powered by Telegram_\n"
    f"{_DIVIDER}\n\n"
    "✨ *What you get:*\n\n"
    "📱 Manage multiple Instagram accounts\n"
    "🎬 Automated reel & post publishing\n"
    "📅 Scheduled posting\n"
    "📝 Smart caption handling\n"
    "📊 Analytics & account health\n"
    "🔁 Repost from any Instagram link\n"
    "🆘 Live support, whenever you need it\n\n"
    f"{_DIVIDER}\n"
    "_No apps. No dashboards. Just Telegram._"
)


def handle_customer_start(message):
    chat_id = message.chat.id
    customer = subscriptions.get_or_create_customer(
        chat_id,
        username=getattr(message.from_user, "username", None),
        full_name=getattr(message.from_user, "full_name", None),
    )
    active = subscriptions.get_active_subscription(chat_id)

    if active:
        plan = subscriptions.get_plans(include_inactive=True).get(active["plan_key"], {})
        expires = datetime.datetime.fromtimestamp(active["expires_at"]).strftime("%Y-%m-%d")
        owned = subscriptions.get_owned_accounts(chat_id)
        # Confirmed requirement: a proper persistent reply keyboard (fixed
        # buttons below the message box) rather than inline buttons stuck
        # to this one message — those scroll away and go stale (e.g. a
        # customer could tap an old "Add Account" button from a message
        # sent days ago). _customer_keyboard() stays visible in every
        # message going forward, the same way the owner's does.
        account_status_icon = {
            "active": "✅", "expired_session": "⚠️", "pending_login": "⏳", "removed": "➖",
        }
        lines = [
            "🤖 *BUZZNITY*",
            f"{_DIVIDER}\n",
            f"🎫 Plan: *{plan.get('name', active['plan_key'])}*",
            f"📱 Accounts: *{len(owned)}/{active['account_limit']}*",
            f"📅 Renews: *{expires}*",
        ]
        if owned:
            lines.append(f"\n{_DIVIDER}")
            lines.append("*Your Instagram Accounts*\n")
            for a in owned:
                tag = f" — @{a['instagram_username']}" if a.get("instagram_username") else ""
                icon = account_status_icon.get(a["status"], "❔")
                lines.append(f"{icon} #{a['account_number']}{tag}")
            lines.append(f"\n{_DIVIDER}")
            lines.append(
                "📤 *To post:* send a video, an Instagram Reel link, or a direct .mp4 "
                "link — any time."
            )
        bot.send_message(chat_id, "\n".join(lines), parse_mode="Markdown", reply_markup=_customer_keyboard())
        return

    # Not yet onboarded (never gave a name/purpose) — show the welcome +
    # feature list first, with a single "Activate My Account" button,
    # rather than jumping straight to the plan picker.
    if not customer.get("onboarded_name"):
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(types.InlineKeyboardButton("🚀 Activate My Account", callback_data="cust_activate"))
        markup.add(types.InlineKeyboardButton("🆘 Contact Support", callback_data="cust_support"))
        bot.send_message(chat_id, BUZZNITY_FEATURES_TEXT, parse_mode="Markdown", reply_markup=markup)
        return

    status_note = ""
    if customer["status"] == "pending_payment":
        status_note = "\n\nℹ️ You have a payment submission awaiting admin review."
    elif customer["status"] in ("expired", "suspended"):
        status_note = f"\n\nℹ️ Your previous subscription is {customer['status']} — pick a plan below to renew."

    bot.send_message(
        message.chat.id,
        "🤖 *Buzznity — Instagram Automation*\n\n"
        "Choose a plan to get started:" + status_note,
        parse_mode="Markdown",
        reply_markup=_plan_picker_markup(),
    )


@bot.callback_query_handler(func=lambda call: call.data == "cust_activate")
def customer_activate_start(call):
    bot.answer_callback_query(call.id)
    msg = bot.send_message(call.message.chat.id, "👤 What is your name?")
    bot.register_next_step_handler(msg, _handle_onboarding_name)


def _handle_onboarding_name(message):
    name = (message.text or "").strip()
    if not name:
        msg = bot.reply_to(message, "Please send your name as text.")
        bot.register_next_step_handler(msg, _handle_onboarding_name)
        return
    db.set_user_state(message.chat.id, stage=f"onboarding_purpose:{name[:100]}")
    markup = types.InlineKeyboardMarkup(row_width=2)
    for label in ("Personal", "Business", "Agency", "Creator", "Other"):
        markup.add(types.InlineKeyboardButton(label, callback_data=f"custpurpose_{label}"))
    bot.send_message(message.chat.id, "🎯 What will you use Buzznity for?", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("custpurpose_"))
def customer_pick_purpose(call):
    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id
    state = db.get_user_state(chat_id)
    if not state or not str(state.get("stage", "")).startswith("onboarding_purpose:"):
        return
    name = state["stage"].split(":", 1)[1]
    purpose = call.data.split("_", 1)[1]
    subscriptions.save_onboarding_info(chat_id, name, purpose)
    db.clear_user_state(chat_id)
    bot.send_message(
        chat_id,
        f"👤 Name: {name}\n🎯 Purpose: {purpose}\n\n✅ Account activated! Choose a plan to continue:",
        reply_markup=_plan_picker_markup(),
    )


@bot.message_handler(commands=["support"])
def cmd_support(message):
    if is_owner(message):
        return  # the owner has no "support" to contact — it's them
    msg = bot.reply_to(message, "🆘 What do you need help with? Send your message and the team will reply here.")
    bot.register_next_step_handler(msg, _handle_support_message)


@bot.callback_query_handler(func=lambda call: call.data == "cust_support")
def customer_support_start(call):
    bot.answer_callback_query(call.id)
    msg = bot.send_message(
        call.message.chat.id,
        "🆘 What do you need help with? Send your message and the team will reply here.",
    )
    bot.register_next_step_handler(msg, _handle_support_message)


def _handle_support_message(message):
    customer_chat_id = message.chat.id
    customer = subscriptions.get_customer(customer_chat_id)
    who = f"@{message.from_user.username}" if message.from_user.username else f"chat_id {customer_chat_id}"
    name = (customer.get("onboarded_name") if customer else None) or who
    admin_chat_id = SUPER_ADMIN_GROUP_ID or ALLOWED_CHAT_ID

    try:
        forwarded = bot.send_message(
            admin_chat_id,
            f"🆘 *Support request*\nFrom: {name} ({who})\nchat_id: `{customer_chat_id}`\n\n"
            f"{message.text}\n\n_Reply to THIS message to respond — it'll be relayed automatically._",
            parse_mode="Markdown",
        )
        subscriptions.record_support_forward(forwarded.message_id, admin_chat_id, customer_chat_id)
        bot.reply_to(message, "✅ Sent to the team — they'll reply here as soon as they can.")
    except Exception as e:
        logger.warning(f"Could not forward support message from {customer_chat_id}: {e}")
        bot.reply_to(message, "❌ Couldn't send that right now — please try again in a moment.")


@bot.message_handler(func=lambda m: is_owner(m) and m.reply_to_message is not None)
def admin_support_reply(message):
    """Any message the owner sends AS A REPLY to a forwarded support
    message gets relayed back to that original customer — no special
    command needed, just Telegram's native reply feature. Silently does
    nothing if the replied-to message isn't a tracked support forward
    (e.g. the owner replying to something else entirely), so this never
    interferes with normal owner usage of the bot."""
    customer_chat_id = subscriptions.get_support_customer(message.reply_to_message.message_id)
    if not customer_chat_id:
        return
    try:
        bot.send_message(customer_chat_id, f"🆘 *Support:*\n{message.text}", parse_mode="Markdown")
        bot.reply_to(message, "✅ Relayed to the customer.")
    except Exception as e:
        logger.warning(f"Could not relay support reply to {customer_chat_id}: {e}")
        bot.reply_to(message, f"❌ Couldn't relay that: {_short(str(e), 300)}")


@bot.callback_query_handler(func=lambda call: call.data.startswith("subplan_"))
def customer_pick_plan(call):
    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id
    # Confirmed bug: tapping a STALE plan button (e.g. an old message from
    # before they subscribed, still sitting in chat history) skipped
    # straight to payment selection even for an ALREADY-active customer —
    # this callback never re-checked subscription status the way
    # handle_customer_start does. Guard against that here specifically.
    if subscriptions.get_active_subscription(chat_id):
        bot.send_message(
            chat_id,
            "✅ You already have an active subscription — no need to pay again. "
            "Send /start to see your dashboard.",
        )
        return
    plan_key = call.data.split("_", 1)[1]
    plan = subscriptions.get_plans(include_inactive=True).get(plan_key)
    if not plan:
        return
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🇮🇳 UPI (automatic)", callback_data=f"paymethod_upi_{plan_key}"),
        types.InlineKeyboardButton("₿ USDT", callback_data=f"paymethod_usdt_{plan_key}"),
        types.InlineKeyboardButton("💙 PayPal", callback_data=f"paymethod_paypal_{plan_key}"),
    )
    bot.send_message(
        call.message.chat.id,
        f"💳 *{plan['name']}* — ${plan['price_usd']}/month, {plan['account_limit']} accounts\n\n"
        f"Choose how you want to pay:",
        parse_mode="Markdown",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("paymethod_usdt_") or call.data.startswith("paymethod_paypal_"))
def customer_pick_manual_method(call):
    """USDT and PayPal aren't wired to an automatic gateway — both route
    to the same manual admin-contact screen, matching the spec exactly
    (only UPI is automatic)."""
    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id
    if subscriptions.get_active_subscription(chat_id):
        bot.send_message(chat_id, "✅ You already have an active subscription — no need to pay again.")
        return
    method = "USDT" if call.data.startswith("paymethod_usdt_") else "PayPal"
    plan_key = call.data.rsplit("_", 1)[1]
    icon = "₿" if method == "USDT" else "💙"
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("👨‍💼 Contact Admin", url=f"https://t.me/{SUPER_ADMIN_CONTACT.lstrip('@')}"),
    )
    # Lets them go straight to the proof-submission flow too, in case
    # they've already paid and just want to send proof now rather than
    # opening a separate chat with the admin first. Confirmed bug: this
    # button used to be added to `markup` AFTER send_message() already
    # used it — meaning it silently never actually appeared.
    markup.add(types.InlineKeyboardButton("📤 I've Paid — Submit Proof", callback_data=f"manualpay_{plan_key}"))
    markup.add(types.InlineKeyboardButton("🔙 Back", callback_data=f"subplan_{plan_key}"))
    bot.send_message(
        call.message.chat.id,
        f"{icon} *{method}*\n\n{method} payment is handled manually.\n\n"
        f"Please contact Buzznity Admin to activate your subscription, or if you've "
        f"already paid, tap 📤 below to submit proof directly.",
        parse_mode="Markdown",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("paymethod_upi_"))
def customer_pick_upi(call):
    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id
    if subscriptions.get_active_subscription(chat_id):
        bot.send_message(chat_id, "✅ You already have an active subscription — no need to pay again.")
        return
    plan_key = call.data.rsplit("_", 1)[1]
    plan = subscriptions.get_plans(include_inactive=True).get(plan_key)
    if not plan:
        return

    # Try the automatic billing API first — falls back to the manual
    # proof-submission flow if it's not configured or the call fails, so
    # a billing API outage never leaves a customer with no way to pay at
    # all. See billing_api.py's module docstring for the parts of this
    # integration that still need live verification.
    if BILLING_API_KEY:
        try:
            payment = subscriptions.submit_auto_payment_request(chat_id, plan_key)
            markup = types.InlineKeyboardMarkup(row_width=1)
            markup.add(types.InlineKeyboardButton("💳 Pay Now", url=payment["payment_link"]))
            markup.add(types.InlineKeyboardButton("🔄 Check Payment", callback_data=f"checkpay_{payment['id']}"))
            markup.add(types.InlineKeyboardButton(
                "👨‍💼 Pay Manually Instead", callback_data=f"manualpay_{plan_key}"
            ))
            if payment.get("reused"):
                # Confirmed bug fix: re-tapping the same plan used to
                # always create a brand-new payment request, which could
                # leave several valid-looking links open for the same
                # person at once — confusing, and a real risk of paying
                # twice. This is their EXISTING still-valid request.
                caption = (
                    f"💳 *UPI Payment* — pending\n{_DIVIDER}\n\n"
                    f"You already have an active payment request for *{plan['name']}* — "
                    f"here it is again.\n\n"
                    # ₹ specifically here (not $) — confirmed: the billing
                    # API charges the plan's number as INR for UPI (a real
                    # test payment of "1" was confirmed on their page as
                    # "INR 1.00"), so showing "$" for UPI was misleading.
                    f"🎫 Plan: *{plan['name']}*\n📱 Accounts: *{plan['account_limit']}*\n💰 Amount: *₹{plan['price_usd']}*\n\n"
                    f"Already paid? Tap 🔄 Check Payment.\nOtherwise, tap 💳 Pay Now."
                )
            else:
                caption = (
                    f"💳 *UPI Payment*\n{_DIVIDER}\n\n"
                    f"🎫 Plan: *{plan['name']}*\n📱 Accounts: *{plan['account_limit']}*\n💰 Amount: *₹{plan['price_usd']}*\n\n"
                    f"Tap *Pay Now*, complete the payment, then tap 🔄 *Check Payment*."
                )
            qr_data_uri = payment.get("qr_code_url")
            if qr_data_uri and qr_data_uri.startswith("data:image"):
                try:
                    b64_part = qr_data_uri.split(",", 1)[1]
                    qr_bytes = base64.b64decode(b64_part)
                    bot.send_photo(chat_id, qr_bytes, caption=caption, parse_mode="Markdown", reply_markup=markup)
                    return
                except Exception as e:
                    logger.warning(f"Could not decode/send QR code for payment {payment['id']}: {e}")
            bot.send_message(chat_id, caption, parse_mode="Markdown", reply_markup=markup)
            return
        except billing_api.BillingAPIError as e:
            logger.warning(f"Auto-payment request failed for chat {chat_id}, falling back to manual: {e}")

    _start_manual_payment(chat_id, plan_key)


@bot.callback_query_handler(func=lambda call: call.data.startswith("manualpay_"))
def customer_pick_manual_payment(call):
    bot.answer_callback_query(call.id)
    plan_key = call.data.split("_", 1)[1]
    _start_manual_payment(call.message.chat.id, plan_key)


def _start_manual_payment(chat_id, plan_key):
    plan = subscriptions.get_plans(include_inactive=True)[plan_key]
    db.set_user_state(chat_id, stage=f"awaiting_payment_proof:{plan_key}")
    msg = bot.send_message(
        chat_id,
        f"💳 *{plan['name']}* — ${plan['price_usd']}/month, {plan['account_limit']} accounts\n\n"
        f"{PAYMENT_INSTRUCTIONS}\n\n"
        f"Once paid, send a screenshot of the payment (or type the transaction "
        f"reference) here and the admin will verify it.",
        parse_mode="Markdown",
    )
    bot.register_next_step_handler(msg, _handle_payment_proof, plan_key)


@bot.callback_query_handler(func=lambda call: call.data.startswith("checkpay_"))
def customer_check_payment(call):
    bot.answer_callback_query(call.id, "Checking...")
    chat_id = call.message.chat.id
    payment_id = int(call.data.split("_", 1)[1])
    try:
        result, sub = subscriptions.check_and_activate_auto_payment(payment_id)
    except billing_api.BillingAPIError as e:
        logger.warning(f"Payment status check failed for payment {payment_id}: {e}")
        bot.send_message(chat_id, "❌ Couldn't check payment status right now — try again in a moment.")
        return

    if result == "paid":
        plan = subscriptions.get_plans(include_inactive=True)[sub["plan_key"]]
        expires = datetime.datetime.fromtimestamp(sub["expires_at"]).strftime("%Y-%m-%d")
        bot.send_message(
            chat_id,
            f"🎉 *Payment Confirmed!*\n{_DIVIDER}\n\n"
            f"🎫 Plan: *{plan['name']}*\n📱 Accounts: *{plan['account_limit']}*\n📅 Active until: *{expires}*\n\n"
            f"Send /start to add your Instagram accounts.",
            parse_mode="Markdown",
        )
    elif result == "expired":
        bot.send_message(
            chat_id,
            "⌛ That payment link expired (valid for 10 minutes). Please send /start and "
            "pick your plan again for a fresh one.",
        )
    elif result == "failed":
        bot.send_message(
            chat_id,
            "❌ That payment didn't go through. Please try again via /start, or use "
            "👨‍💼 Pay Manually Instead.",
        )
    else:
        bot.send_message(chat_id, "⏳ Not confirmed yet — try 🔄 Check Payment again in a minute.")


def _handle_payment_proof(message, plan_key):
    chat_id = message.chat.id
    proof_file_id = None
    proof_note = None
    if message.content_type == "photo":
        proof_file_id = message.photo[-1].file_id
        proof_note = message.caption
    elif message.content_type == "document":
        proof_file_id = message.document.file_id
        proof_note = message.caption
    elif message.content_type == "text":
        proof_note = message.text
    else:
        bot.reply_to(message, "Please send a screenshot (photo) or a text reference of your payment.")
        return

    payment_id = subscriptions.submit_payment(chat_id, plan_key, proof_file_id, proof_note)
    db.clear_user_state(chat_id)
    plan = subscriptions.get_plans(include_inactive=True)[plan_key]
    bot.reply_to(
        message,
        "✅ Payment submitted for admin review. You'll be notified once it's verified "
        "(usually within a day).",
    )

    # Notify the owner with approve/reject buttons — this is the manual
    # verification step this phase relies on instead of an automated
    # payment gateway.
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("✅ Approve", callback_data=f"subpay_approve_{payment_id}"),
        types.InlineKeyboardButton("❌ Reject", callback_data=f"subpay_reject_{payment_id}"),
    )
    who = f"@{message.from_user.username}" if message.from_user.username else f"chat_id {chat_id}"
    caption = (
        f"💳 New payment submission #{payment_id}\n"
        f"From: {who}\n"
        f"Plan: {plan['name']} (${plan['price_usd']}/mo, {plan['account_limit']} accounts)\n"
        + (f"Note: {proof_note}" if proof_note and not proof_file_id else "")
    )
    try:
        if proof_file_id and message.content_type == "photo":
            bot.send_photo(ALLOWED_CHAT_ID, proof_file_id, caption=caption, reply_markup=markup)
        elif proof_file_id:
            bot.send_document(ALLOWED_CHAT_ID, proof_file_id, caption=caption, reply_markup=markup)
        else:
            bot.send_message(ALLOWED_CHAT_ID, caption, reply_markup=markup)
    except Exception as e:
        logger.warning(f"Could not notify admin of new payment #{payment_id}: {e}")


@bot.callback_query_handler(func=lambda call: call.data.startswith("subpay_approve_"))
def admin_approve_payment(call):
    if not is_owner(call):
        bot.answer_callback_query(call.id, "Owner only.", show_alert=True)
        return
    bot.answer_callback_query(call.id)
    payment_id = int(call.data.rsplit("_", 1)[1])
    sub = subscriptions.approve_payment(payment_id, reviewed_by=call.message.chat.id)
    if not sub:
        bot.send_message(call.message.chat.id, f"Payment #{payment_id} already handled or not found.")
        return
    plan = subscriptions.get_plans(include_inactive=True)[sub["plan_key"]]
    expires = datetime.datetime.fromtimestamp(sub["expires_at"]).strftime("%Y-%m-%d")
    bot.send_message(call.message.chat.id, f"✅ Payment #{payment_id} approved — {plan['name']} until {expires}.")
    try:
        bot.send_message(
            sub["chat_id"],
            f"🎉 Your payment is verified! You're now on the *{plan['name']}* plan "
            f"({plan['account_limit']} accounts), active until {expires}.\n\n"
            f"Contact {SUPER_ADMIN_CONTACT} to get your Instagram accounts connected.",
            parse_mode="Markdown",
        )
    except Exception as e:
        logger.warning(f"Could not notify customer {sub['chat_id']} of approval: {e}")


@bot.callback_query_handler(func=lambda call: call.data.startswith("subpay_reject_"))
def admin_reject_payment(call):
    if not is_owner(call):
        bot.answer_callback_query(call.id, "Owner only.", show_alert=True)
        return
    bot.answer_callback_query(call.id)
    payment_id = int(call.data.rsplit("_", 1)[1])
    payment = subscriptions.get_payment(payment_id)
    if not payment or payment["status"] != "pending":
        bot.send_message(call.message.chat.id, f"Payment #{payment_id} already handled or not found.")
        return
    subscriptions.reject_payment(payment_id, reviewed_by=call.message.chat.id)
    bot.send_message(call.message.chat.id, f"❌ Payment #{payment_id} rejected.")
    try:
        bot.send_message(
            payment["chat_id"],
            "❌ Your payment submission couldn't be verified. Please double-check and "
            f"resubmit, or contact {SUPER_ADMIN_CONTACT} for help.",
        )
    except Exception as e:
        logger.warning(f"Could not notify customer {payment['chat_id']} of rejection: {e}")


@bot.message_handler(commands=["admin"])
def cmd_admin_panel(message):
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can access the admin panel.")
        return
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton("👥 Users", callback_data="admin_users"))
    markup.add(types.InlineKeyboardButton("⚙️ Plans", callback_data="admin_plans"))
    markup.add(types.InlineKeyboardButton("🔐 Billing Settings", callback_data="admin_billing"))
    markup.add(types.InlineKeyboardButton("📢 Send Notice", callback_data="admin_notice"))
    bot.reply_to(
        message,
        "👑 *SUPER ADMIN PANEL*\n\n"
        "(Users → View Details also has Payment History / Invoices — "
        "use /pendingpayments for reviewing NEW payment submissions.)",
        parse_mode="Markdown",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data == "admin_notice")
def admin_notice_start(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    msg = bot.send_message(call.message.chat.id, "📢 Type the notice message to send:")
    bot.register_next_step_handler(msg, _handle_notice_text)


def _handle_notice_text(message):
    if not is_owner(message):
        return
    text = (message.text or "").strip()
    if not text:
        bot.reply_to(message, "Empty message — try 📢 Send Notice again.")
        return
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("📣 All Users", callback_data="noticeaud_all"),
        types.InlineKeyboardButton("✅ Active Only", callback_data="noticeaud_active"),
        types.InlineKeyboardButton("⌛ Expired Only", callback_data="noticeaud_expired"),
        types.InlineKeyboardButton("👤 Specific User", callback_data="noticeaud_specific"),
    )
    _pending_notices[message.chat.id] = text
    bot.reply_to(message, f"Preview:\n\n{text}\n\nSend to:", reply_markup=markup)


# Small in-memory holding spot for "the notice text just typed, audience
# not chosen yet" — deliberately NOT db.user_state (shared with the
# owner's own posting flow, see the invoice functions' comment above for
# why that's risky). A lost notice-in-progress on a bot restart is a
# minor inconvenience (just retype it), not a correctness problem, so
# this doesn't need to be persistent.
_pending_notices = {}


@bot.callback_query_handler(func=lambda call: call.data.startswith("noticeaud_"))
def admin_notice_send(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id
    text = _pending_notices.get(chat_id)
    if not text:
        bot.send_message(chat_id, "Notice text expired — use 📢 Send Notice again.")
        return
    audience = call.data.split("_", 1)[1]

    if audience == "specific":
        msg = bot.send_message(chat_id, "Send the target user's chat_id (a number):")
        bot.register_next_step_handler(msg, _handle_notice_specific_target, text)
        return

    if audience == "all":
        targets = subscriptions.list_customers()
    elif audience == "active":
        targets = subscriptions.list_customers(status="active")
    elif audience == "expired":
        targets = subscriptions.list_customers(status="expired")
    else:
        return

    _pending_notices.pop(chat_id, None)
    sent, failed = 0, 0
    for c in targets:
        try:
            bot.send_message(c["chat_id"], f"📢 *Notice from Buzznity*\n\n{text}", parse_mode="Markdown")
            sent += 1
        except Exception as e:
            logger.warning(f"Could not send notice to {c['chat_id']}: {e}")
            failed += 1
    bot.send_message(chat_id, f"✅ Sent to {sent} user(s)." + (f" ({failed} failed)" if failed else ""))


def _handle_notice_specific_target(message, text):
    if not is_owner(message):
        return
    target_text = (message.text or "").strip()
    if not target_text.isdigit() and not (target_text.startswith("-") and target_text[1:].isdigit()):
        bot.reply_to(message, "That doesn't look like a chat_id — try 📢 Send Notice again.")
        return
    target_chat_id = int(target_text)
    _pending_notices.pop(message.chat.id, None)
    try:
        bot.send_message(target_chat_id, f"📢 *Notice from Buzznity*\n\n{text}", parse_mode="Markdown")
        bot.reply_to(message, "✅ Sent.")
    except Exception as e:
        bot.reply_to(message, f"❌ Couldn't send: {_short(str(e), 300)}")


@bot.callback_query_handler(func=lambda call: call.data == "admin_plans")
def admin_plans_list(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    plans = subscriptions.get_plans(include_inactive=True)
    for key, plan in plans.items():
        status = "" if plan.get("active", 1) else " (inactive)"
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("💲 Edit Price", callback_data=f"adminplan_price_{key}"),
            types.InlineKeyboardButton("🔢 Edit Account Limit", callback_data=f"adminplan_limit_{key}"),
            types.InlineKeyboardButton("📅 Edit Duration (days)", callback_data=f"adminplan_duration_{key}"),
        )
        bot.send_message(
            call.message.chat.id,
            f"⚙️ {plan['name']}{status}\n"
            f"Price: ${plan['price_usd']}/mo\n"
            f"Account limit: {plan['account_limit']}\n"
            f"Duration: {plan['duration_days']} days\n\n"
            f"(Editing this does NOT change any customer's already-active subscription — "
            f"only new subscriptions/renewals going forward.)",
            reply_markup=markup,
        )


@bot.callback_query_handler(func=lambda call: call.data.startswith("adminplan_"))
def admin_plan_edit_prompt(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    _, field, plan_key = call.data.split("_", 2)
    field_label = {"price": "price in USD", "limit": "account limit", "duration": "duration in days"}[field]
    msg = bot.send_message(call.message.chat.id, f"Send the new {field_label} for '{plan_key}' (a number):")
    bot.register_next_step_handler(msg, _handle_plan_edit_value, plan_key, field)


def _handle_plan_edit_value(message, plan_key, field):
    if not is_owner(message):
        return
    text = (message.text or "").strip()
    try:
        value = float(text) if field == "price" else int(text)
        if value <= 0:
            raise ValueError
    except ValueError:
        bot.reply_to(message, "Please send a positive number.")
        return
    column = {"price": "price_usd", "limit": "account_limit", "duration": "duration_days"}[field]
    subscriptions.update_plan(plan_key, **{column: value})
    bot.reply_to(message, f"✅ Updated '{plan_key}'.{column} = {value}")


@bot.callback_query_handler(func=lambda call: call.data == "admin_billing")
def admin_billing_settings(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    masked_key = f"{'•' * 12}{BILLING_API_KEY[-4:]}" if BILLING_API_KEY else "(not set)"
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🔑 Update API Key", callback_data="adminbilling_key"),
        types.InlineKeyboardButton("🌐 Update API Base URL", callback_data="adminbilling_url"),
    )
    bot.send_message(
        call.message.chat.id,
        f"🔐 *Billing Settings*\n\n"
        f"Provider: Buzznity Billing\nAPI Base: {BILLING_API_BASE_URL}\nAPI Key: {masked_key}",
        parse_mode="Markdown",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data == "adminbilling_key")
def admin_billing_key_prompt(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    msg = bot.send_message(
        call.message.chat.id,
        "🔑 Paste the new Billing API key. I'll delete your message right after reading it, "
        "same as the /addaccount cookie flow.",
    )
    bot.register_next_step_handler(msg, _handle_billing_key_step)


def _handle_billing_key_step(message):
    if not is_owner(message):
        return
    new_key = (message.text or "").strip()
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception as e:
        logger.info(f"Could not delete billing key message: {e}")
    if not new_key:
        bot.send_message(message.chat.id, "That was empty — nothing changed.")
        return
    try:
        _write_env_var("BILLING_API_KEY", new_key)
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Couldn't update .env: {_short(str(e), 500)}")
        return
    bot.send_message(
        message.chat.id,
        "✅ Billing API key updated in .env (your message was deleted).\n\n"
        "⚠️ Restart for it to take effect: `sudo systemctl restart buzznity-bot`",
        parse_mode="Markdown",
    )


@bot.callback_query_handler(func=lambda call: call.data == "adminbilling_url")
def admin_billing_url_prompt(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    msg = bot.send_message(call.message.chat.id, f"Current: {BILLING_API_BASE_URL}\n\nSend the new API base URL:")
    bot.register_next_step_handler(msg, _handle_billing_url_step)


def _handle_billing_url_step(message):
    if not is_owner(message):
        return
    new_url = (message.text or "").strip()
    if not new_url.startswith("http"):
        bot.reply_to(message, "That doesn't look like a URL — try again.")
        return
    try:
        _write_env_var("BILLING_API_BASE_URL", new_url)
    except Exception as e:
        bot.reply_to(message, f"❌ Couldn't update .env: {_short(str(e), 500)}")
        return
    bot.reply_to(
        message,
        "✅ Billing API base URL updated in .env.\n\n"
        "⚠️ Restart for it to take effect: `sudo systemctl restart buzznity-bot`",
        parse_mode="Markdown",
    )


@bot.callback_query_handler(func=lambda call: call.data == "admin_users")
def admin_users_list(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    customers = subscriptions.list_customers()
    if not customers:
        bot.send_message(call.message.chat.id, "No users yet.")
        return
    # One message per user rather than a giant combined list — each one
    # carries its own View Details button. Capped at 30 per call; proper
    # pagination/search is a later improvement once the user base is
    # large enough to need it.
    for c in customers[:30]:
        sub = subscriptions.get_active_subscription(c["chat_id"])
        plan_label = subscriptions.get_plans(include_inactive=True).get(sub["plan_key"], {}).get("name", sub["plan_key"]) if sub else "—"
        owned = subscriptions.count_owned_accounts(c["chat_id"])
        limit = sub["account_limit"] if sub else 0
        who = f"@{c['username']}" if c.get("username") else f"chat_id {c['chat_id']}"
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("View Details", callback_data=f"admin_userview_{c['chat_id']}"))
        bot.send_message(
            call.message.chat.id,
            f"👤 {who}\nPlan: {plan_label}\nAccounts: {owned}/{limit}\nStatus: {c['status'].upper()}",
            reply_markup=markup,
        )


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_userview_"))
def admin_user_details(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    target_chat_id = int(call.data.rsplit("_", 1)[1])
    c = subscriptions.get_customer(target_chat_id)
    if not c:
        bot.send_message(call.message.chat.id, "User not found.")
        return
    sub = subscriptions.get_active_subscription(target_chat_id)
    owned = subscriptions.get_owned_accounts(target_chat_id)
    lines = [
        "👤 *Client Details*\n",
        f"Name: {c.get('onboarded_name') or c.get('full_name') or '—'}",
        f"Telegram Username: @{c['username']}" if c.get("username") else "Telegram Username: —",
        f"Telegram ID: {c['chat_id']}",
        f"Purpose: {c.get('purpose') or '—'}",
        "",
    ]
    if sub:
        plan = subscriptions.get_plans(include_inactive=True).get(sub["plan_key"], {})
        started = datetime.datetime.fromtimestamp(sub["started_at"]).strftime("%Y-%m-%d") if sub.get("started_at") else "—"
        expires = datetime.datetime.fromtimestamp(sub["expires_at"]).strftime("%Y-%m-%d") if sub.get("expires_at") else "—"
        lines += [
            f"Plan: {plan.get('name', sub['plan_key'])}",
            f"Subscription Status: {sub['status'].upper()}",
            f"Start Date: {started}",
            f"Expiry Date: {expires}",
            f"Account Limit: {sub['account_limit']}",
        ]
    else:
        lines.append("Plan: (none active)")
    lines.append(f"Used Accounts: {len(owned)}")
    if owned:
        lines.append("Instagram Accounts:")
        for a in owned:
            tag = f" (@{a['instagram_username']})" if a.get("instagram_username") else ""
            lines.append(f"  • #{a['account_number']}{tag} — {a['status']}")

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton("➕ Extend Subscription", callback_data=f"admin_extend_{target_chat_id}"))
    markup.add(types.InlineKeyboardButton("🎁 Grant Subscription (no payment)", callback_data=f"admin_grant_{target_chat_id}"))
    markup.add(types.InlineKeyboardButton("🔢 Change Account Limit", callback_data=f"admin_limit_{target_chat_id}"))
    markup.add(types.InlineKeyboardButton("🧾 Payment History / Invoices", callback_data=f"admin_payhist_{target_chat_id}"))
    bot.send_message(call.message.chat.id, "\n".join(lines), parse_mode="Markdown", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_extend_"))
def admin_extend_pick_days(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    target_chat_id = int(call.data.rsplit("_", 1)[1])
    markup = types.InlineKeyboardMarkup(row_width=3)
    for days in (7, 15, 30, 60, 90):
        markup.add(types.InlineKeyboardButton(
            f"{days} Days", callback_data=f"admin_extendby_{target_chat_id}_{days}"
        ))
    bot.send_message(call.message.chat.id, "Extend by:", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_extendby_"))
def admin_extend_apply(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    _, _, target_chat_id_str, days_str = call.data.split("_", 3)
    target_chat_id = int(target_chat_id_str)
    days = int(days_str)
    sub = subscriptions.extend_subscription(target_chat_id, days, extended_by=call.message.chat.id)
    if not sub:
        bot.send_message(
            call.message.chat.id,
            "This user has no subscription history to extend — they need to subscribe first.",
        )
        return
    expires = datetime.datetime.fromtimestamp(sub["expires_at"]).strftime("%Y-%m-%d")
    bot.send_message(call.message.chat.id, f"✅ Extended by {days} days — new expiry {expires}.")
    try:
        bot.send_message(
            target_chat_id,
            f"🎉 Your subscription has been extended by {days} days! New expiry: {expires}.",
        )
    except Exception as e:
        logger.warning(f"Could not notify customer {target_chat_id} of extension: {e}")


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_grant_"))
def admin_grant_pick_plan(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    target_chat_id = int(call.data.rsplit("_", 1)[1])
    markup = types.InlineKeyboardMarkup(row_width=1)
    for key, plan in subscriptions.get_plans(include_inactive=True).items():
        markup.add(types.InlineKeyboardButton(
            f"{plan['name']} ({plan['account_limit']} accounts)",
            callback_data=f"admin_grantplan_{target_chat_id}_{key}",
        ))
    bot.send_message(call.message.chat.id, "Grant which plan? (no payment record created)", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_grantplan_"))
def admin_grant_pick_days(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    _, _, target_chat_id_str, plan_key = call.data.split("_", 3)
    target_chat_id = int(target_chat_id_str)
    markup = types.InlineKeyboardMarkup(row_width=3)
    for days in (7, 15, 30, 60, 90):
        markup.add(types.InlineKeyboardButton(
            f"{days} Days", callback_data=f"admin_grantdays_{target_chat_id}_{plan_key}_{days}"
        ))
    bot.send_message(call.message.chat.id, "Grant for how many days?", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_grantdays_"))
def admin_grant_apply(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    _, _, target_chat_id_str, plan_key, days_str = call.data.split("_", 4)
    target_chat_id = int(target_chat_id_str)
    days = int(days_str)
    sub = subscriptions.grant_subscription(target_chat_id, plan_key, days, granted_by=call.message.chat.id)
    plan = subscriptions.get_plans(include_inactive=True)[plan_key]
    expires = datetime.datetime.fromtimestamp(sub["expires_at"]).strftime("%Y-%m-%d")
    bot.send_message(
        call.message.chat.id,
        f"✅ Granted {plan['name']} to chat_id {target_chat_id} for {days} days — expires {expires}.",
    )
    try:
        bot.send_message(
            target_chat_id,
            f"🎉 You've been granted the *{plan['name']}* plan ({plan['account_limit']} accounts), "
            f"active until {expires}.\n\nSend /start to add your Instagram accounts.",
            parse_mode="Markdown",
        )
    except Exception as e:
        logger.warning(f"Could not notify customer {target_chat_id} of granted subscription: {e}")


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_limit_"))
def admin_change_limit_prompt(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    target_chat_id = int(call.data.rsplit("_", 1)[1])
    sub = subscriptions.get_active_subscription(target_chat_id)
    if not sub:
        bot.send_message(call.message.chat.id, "This user has no active subscription to modify.")
        return
    msg = bot.send_message(
        call.message.chat.id,
        f"Current account limit: {sub['account_limit']}\n\nSend the new limit (a number):",
    )
    bot.register_next_step_handler(msg, _handle_change_limit_value, target_chat_id)


def _handle_change_limit_value(message, target_chat_id):
    if not is_owner(message):
        return
    text = (message.text or "").strip()
    if not text.isdigit() or int(text) < 1:
        bot.reply_to(message, "Please send a positive whole number.")
        return
    new_limit = int(text)
    sub = subscriptions.change_account_limit(target_chat_id, new_limit, changed_by=message.chat.id)
    if not sub:
        bot.reply_to(message, "This user no longer has an active subscription.")
        return
    bot.reply_to(message, f"✅ Account limit for chat_id {target_chat_id} is now {new_limit}.")
    try:
        bot.send_message(target_chat_id, f"ℹ️ Your account limit has been updated to {new_limit}.")
    except Exception as e:
        logger.warning(f"Could not notify customer {target_chat_id} of limit change: {e}")


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_payhist_"))
def admin_payment_history(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    target_chat_id = int(call.data.rsplit("_", 1)[1])
    payments = subscriptions.list_payments_for_customer(target_chat_id)
    if not payments:
        bot.send_message(call.message.chat.id, "No payment history for this user.")
        return
    for p in payments:
        plan = subscriptions.get_plans(include_inactive=True).get(p["plan_key"], {})
        submitted = datetime.datetime.fromtimestamp(p["submitted_at"]).strftime("%Y-%m-%d %H:%M")
        markup = types.InlineKeyboardMarkup(row_width=1)
        if p["status"] == "verified":
            markup.add(types.InlineKeyboardButton("📄 Generate & Send Invoice", callback_data=f"admin_invoice_{p['id']}"))
        bot.send_message(
            call.message.chat.id,
            f"💳 Payment #{p['id']} — {plan.get('name', p['plan_key'])} (${p['amount_usd']})\n"
            f"Method: {p['provider']}\nStatus: {p['status'].upper()}\nSubmitted: {submitted}",
            reply_markup=markup,
        )


def _build_invoice_text(payment):
    customer = subscriptions.get_customer(payment["chat_id"])
    plan = subscriptions.get_plans(include_inactive=True).get(payment["plan_key"], {})
    submitted = datetime.datetime.fromtimestamp(payment["submitted_at"]).strftime("%Y-%m-%d")
    who = (customer.get("onboarded_name") if customer else None) or (
        f"@{customer['username']}" if customer and customer.get("username") else f"chat_id {payment['chat_id']}"
    )
    return (
        f"🧾 *INVOICE*\n"
        f"Buzznity Instagram Automation\n"
        f"{'─' * 24}\n"
        f"Invoice #: BZ-{payment['id']:06d}\n"
        f"Date: {submitted}\n\n"
        f"Client: {who}\n"
        f"Plan: {plan.get('name', payment['plan_key'])}\n"
        f"Accounts: {plan.get('account_limit', '—')}\n"
        f"Duration: {plan.get('duration_days', '—')} days\n\n"
        f"Amount Paid: ${payment['amount_usd']}\n"
        f"Payment Method: {payment['provider'].upper()}\n"
        + (f"Transaction ID: {payment['transaction_id']}\n" if payment.get("transaction_id") else "")
        + f"{'─' * 24}\n"
        f"Thank you for choosing Buzznity!"
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_invoice_"))
def admin_generate_invoice(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    payment_id = int(call.data.rsplit("_", 1)[1])
    payment = subscriptions.get_payment(payment_id)
    if not payment or payment["status"] != "verified":
        bot.send_message(call.message.chat.id, "Only a verified payment can be invoiced.")
        return

    # Regenerated from the payment record every time (here, and again at
    # send-time below) rather than cached in db.user_state — that table
    # is shared with the owner's OWN posting flow (video/caption/stage),
    # and the owner is also a regular bot user who posts videos
    # themselves; caching invoice text there risked silently clobbering
    # an in-progress post if both happened at once.
    invoice_text = _build_invoice_text(payment)
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton("📤 Send to Client", callback_data=f"admin_sendinvoice_{payment_id}"))
    bot.send_message(call.message.chat.id, invoice_text, parse_mode="Markdown", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_sendinvoice_"))
def admin_send_invoice(call):
    if not is_owner(call):
        return
    bot.answer_callback_query(call.id)
    payment_id = int(call.data.rsplit("_", 1)[1])
    payment = subscriptions.get_payment(payment_id)
    if not payment:
        bot.send_message(call.message.chat.id, "Payment not found.")
        return
    invoice_text = _build_invoice_text(payment)
    try:
        bot.send_message(payment["chat_id"], invoice_text, parse_mode="Markdown")
        bot.send_message(call.message.chat.id, "✅ Invoice sent to the client.")
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Couldn't send: {_short(str(e), 300)}")


@bot.message_handler(commands=["pendingpayments"])
def cmd_pending_payments(message):
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can review payments.")
        return
    pending = subscriptions.list_pending_payments()
    if not pending:
        bot.reply_to(message, "No pending payments.")
        return
    for p in pending:
        plan = subscriptions.get_plans(include_inactive=True).get(p["plan_key"], {})
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("✅ Approve", callback_data=f"subpay_approve_{p['id']}"),
            types.InlineKeyboardButton("❌ Reject", callback_data=f"subpay_reject_{p['id']}"),
        )
        submitted = datetime.datetime.fromtimestamp(p["submitted_at"]).strftime("%Y-%m-%d %H:%M")
        text = (
            f"💳 Payment #{p['id']} — chat_id {p['chat_id']}\n"
            f"Plan: {plan.get('name', p['plan_key'])} (${p['amount_usd']})\n"
            f"Submitted: {submitted}\n"
            + (f"Note: {p['proof_note']}" if p.get("proof_note") else "")
        )
        if p.get("proof_file_id"):
            try:
                bot.send_photo(message.chat.id, p["proof_file_id"], caption=text, reply_markup=markup)
                continue
            except Exception:
                pass  # fall through to plain text if it wasn't actually a photo
        bot.send_message(message.chat.id, text, reply_markup=markup)


if __name__ == "__main__":
    logger.info("Bot starting...")
    _recover_after_restart()
    start_scheduler(bot)
    start_health_checker(bot)
    start_payment_poller(bot)
    start_auto_analytics(bot)
    start_disk_cleanup()
    print("🤖 Buzznity bot online.")
    bot.infinity_polling(timeout=60, long_polling_timeout=60)
