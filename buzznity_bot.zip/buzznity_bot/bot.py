# bot.py — Telegram control panel for the Instagram reel publisher.
import os
import time
import json
import datetime
import threading
import telebot
from telebot import types, apihelper

from config import BOT_TOKEN, ALLOWED_CHAT_ID, DOWNLOAD_DIR, ACCOUNT_COUNT, HIDE_LIKE_COUNTS
from logger import logger
import database as db
import session_store
import analytics
from scheduler import start_scheduler, _short
from health_checker import start_health_checker
from video_check import validate_video

# Without an explicit timeout, a stalled network call (e.g. sending a large
# screenshot over a slow VPS connection) can hang the underlying HTTP
# request indefinitely — and since publishing runs sequentially in the
# scheduler thread, that hang blocks EVERY future job too, not just the
# current one, with no error and no log line to explain why. Seen directly
# in production: "Publish confirmed" logged, then nothing for 12+ minutes
# until the process was killed. These caps turn a silent infinite hang into
# a normal, catchable timeout error instead.
apihelper.READ_TIMEOUT = 30
apihelper.CONNECT_TIMEOUT = 15

db.init_db()
bot = telebot.TeleBot(BOT_TOKEN)


def _get_chat_id(message_or_call):
    return message_or_call.chat.id if hasattr(message_or_call, "chat") else message_or_call.message.chat.id


def is_owner(message_or_call):
    """The single .env-configured ALLOWED_CHAT_ID — the only one who can
    add/remove other admins, so an added admin can never chain-add others
    on their own."""
    return _get_chat_id(message_or_call) == ALLOWED_CHAT_ID


def is_authorized(message_or_call):
    """Owner, or anyone the owner has explicitly added via /addadmin."""
    chat_id = _get_chat_id(message_or_call)
    return chat_id == ALLOWED_CHAT_ID or db.is_admin(chat_id)


def account_exists(account_num):
    return session_store.session_kind(account_num) is not None


def _try_delete(message):
    """Best-effort delete of a message that contained a live session cookie.
    Never raises — Telegram sometimes refuses deletion (message too old,
    bot lacks delete rights in some chat types), and that must not break
    the flow, just leave the message visible."""
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception as e:
        logger.info(f"Could not delete cookie-input message {message.message_id}: {e}")


# ---------------- Commands ----------------

def _main_keyboard():
    """Persistent bottom keyboard — stays visible across the conversation
    so the common commands are one tap away instead of typed."""
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    kb.add(
        types.KeyboardButton("📊 Status"),
        types.KeyboardButton("📈 Analytics"),
    )
    kb.add(
        types.KeyboardButton("➕ Add Account"),
        types.KeyboardButton("❌ Cancel"),
    )
    kb.add(types.KeyboardButton("❓ Help"))
    return kb


@bot.message_handler(commands=["start", "help"])
def send_welcome(message):
    if not is_authorized(message):
        return
    bot.reply_to(
        message,
        "👋 *Instagram Reel Publisher*\n\n"
        "Send a reel video (MP4) to begin.\n\n"
        "Or use the buttons below — they cover the same commands "
        "(/status, /analytics, /addaccount, /cancel) without typing."
        + ("\n\nAs the owner, you can also:\n"
           "/addadmin <user_id> — let someone else use this bot too\n"
           "/removeadmin <user_id> — revoke their access\n"
           "/listadmins — see who currently has access" if is_owner(message) else ""),
        parse_mode="Markdown",
        reply_markup=_main_keyboard(),
    )


@bot.message_handler(commands=["addadmin"])
def cmd_add_admin(message):
    # Owner-only — an added admin can use the bot but can never add/remove
    # other admins themselves, so access can't silently chain-expand.
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can add admins.")
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].lstrip("-").isdigit():
        bot.reply_to(
            message,
            "Usage: /addadmin <user_id> [label]\n\n"
            "The person can get their own numeric user ID by messaging "
            "@userinfobot on Telegram.",
        )
        return
    new_chat_id = int(parts[1])
    label = " ".join(parts[2:]) if len(parts) > 2 else None
    db.add_admin(new_chat_id, added_by=message.chat.id, label=label)
    bot.reply_to(message, f"✅ Added {new_chat_id}{f' ({label})' if label else ''} as an admin.")
    try:
        bot.send_message(
            new_chat_id,
            "👋 You've been added as an admin on the Instagram Reel Publisher bot. "
            "Send /start to see what you can do.",
        )
    except Exception as e:
        logger.info(f"Could not DM new admin {new_chat_id} (they may not have started the bot yet): {e}")


@bot.message_handler(commands=["removeadmin"])
def cmd_remove_admin(message):
    if not is_owner(message):
        if is_authorized(message):
            bot.reply_to(message, "Only the primary owner can remove admins.")
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].lstrip("-").isdigit():
        bot.reply_to(message, "Usage: /removeadmin <user_id>")
        return
    target = int(parts[1])
    if db.remove_admin(target):
        bot.reply_to(message, f"✅ Removed {target} as an admin.")
    else:
        bot.reply_to(message, f"{target} wasn't an admin.")


@bot.message_handler(commands=["listadmins"])
def cmd_list_admins(message):
    if not is_authorized(message):
        return
    lines = [f"👑 Owner: {ALLOWED_CHAT_ID}"]
    for a in db.list_admins():
        tag = f" ({a['label']})" if a.get("label") else ""
        lines.append(f"👤 {a['chat_id']}{tag}")
    bot.reply_to(message, "\n".join(lines))


def _send_analytics_picker(chat_id):
    markup = types.InlineKeyboardMarkup(row_width=1)
    any_account = False
    for i in range(1, ACCOUNT_COUNT + 1):
        if account_exists(i):
            any_account = True
            markup.add(types.InlineKeyboardButton(f"👤 Account {i}", callback_data=f"analytics_acc_{i}"))
    if not any_account:
        bot.send_message(
            chat_id,
            "No accounts have a saved session yet — use /addaccount or login.py first.",
        )
        return
    bot.send_message(chat_id, "📊 Which account?", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data == "analytics_menu")
def analytics_menu(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    _send_analytics_picker(call.message.chat.id)


@bot.message_handler(commands=["cancel"])
def cancel_flow(message):
    if not is_authorized(message):
        return
    state = db.get_user_state(message.chat.id)
    if state and state.get("video_path") and os.path.exists(state["video_path"]):
        try:
            os.remove(state["video_path"])
        except OSError:
            pass
    db.clear_user_state(message.chat.id)
    bot.reply_to(message, "❌ Current flow cancelled.")


# ---------------- Add account via pasted cookies ----------------
# Alternative to running login.py: paste the 4 core Instagram session
# cookies (from a browser's dev tools) instead. Each value is asked for
# separately and the message containing it is deleted immediately after
# being read, since these are live login credentials sitting in Telegram's
# chat history otherwise. Less robust than login.py's full browser profile
# (see session_store.py), but faster to set up.
_COOKIE_PROMPTS = {
    "sessionid": "🔑 Step 1/4 — paste the *sessionid* cookie value:",
    "csrftoken": "🔑 Step 2/4 — paste the *csrftoken* cookie value:",
    "ds_user_id": "🔑 Step 3/4 — paste the *ds_user_id* cookie value:",
    "mid": "🔑 Step 4/4 — paste the *mid* cookie value:",
}
_COOKIE_ORDER = list(_COOKIE_PROMPTS.keys())


@bot.message_handler(commands=["addaccount"])
def add_account_start(message):
    if not is_authorized(message):
        return
    existing = db.get_user_state(message.chat.id)
    if existing and existing.get("video_path"):
        bot.reply_to(message, "⚠️ You have an unfinished post in progress. Send /cancel first.")
        return

    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in range(1, ACCOUNT_COUNT + 1):
        tag = " (already has a session — this will overwrite it)" if account_exists(i) else ""
        markup.add(types.InlineKeyboardButton(f"👤 Account {i}{tag}", callback_data=f"addacc_{i}"))
    bot.reply_to(
        message,
        "Which account number is this session for?\n\n"
        "You'll be asked to paste 4 values from Instagram's cookies "
        "(sessionid, csrftoken, ds_user_id, mid — from your browser's dev tools, "
        "Application → Cookies → instagram.com).\n\n"
        "⚠️ Each message you send will be deleted right after I read it, since "
        "these are live login credentials.",
        reply_markup=markup,
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith("addacc_"))
def add_account_choose(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[1])
    # The "caption" column is repurposed here purely as scratch storage for
    # the cookie values collected so far (JSON-encoded) — it has no
    # relation to a post caption during this flow.
    db.set_user_state(
        call.message.chat.id, video_path=None, account=account_num,
        caption=json.dumps({}), stage="add_account:sessionid",
    )
    msg = bot.send_message(
        call.message.chat.id, _COOKIE_PROMPTS["sessionid"], parse_mode="Markdown"
    )
    bot.register_next_step_handler(msg, _handle_cookie_step)


def _handle_cookie_step(message):
    if not is_authorized(message):
        return
    state = db.get_user_state(message.chat.id)
    if not state or not state.get("stage", "").startswith("add_account:"):
        _try_delete(message)
        bot.reply_to(message, "Session lost, please run /addaccount again.")
        return

    current_field = state["stage"].split(":", 1)[1]
    value = message.text.strip() if message.text else ""
    _try_delete(message)  # delete the credential immediately, success or not

    if not value:
        msg = bot.send_message(
            message.chat.id,
            f"That was empty — {_COOKIE_PROMPTS[current_field]}",
            parse_mode="Markdown",
        )
        bot.register_next_step_handler(msg, _handle_cookie_step)
        return

    collected = json.loads(state.get("caption") or "{}")
    collected[current_field] = value

    next_index = _COOKIE_ORDER.index(current_field) + 1
    if next_index < len(_COOKIE_ORDER):
        next_field = _COOKIE_ORDER[next_index]
        db.set_user_state(
            message.chat.id, caption=json.dumps(collected), stage=f"add_account:{next_field}"
        )
        msg = bot.send_message(message.chat.id, _COOKIE_PROMPTS[next_field], parse_mode="Markdown")
        bot.register_next_step_handler(msg, _handle_cookie_step)
        return

    # All 4 values collected — save and clean up.
    account_num = state["account"]
    try:
        session_store.save_cookie_session(account_num, collected)
    except ValueError as e:
        bot.send_message(message.chat.id, f"❌ Couldn't save session: {e}. Run /addaccount to try again.")
        db.clear_user_state(message.chat.id)
        return

    db.clear_user_state(message.chat.id)
    logger.info(f"Cookie-based session saved for account {account_num} via Telegram.")
    bot.send_message(
        message.chat.id,
        f"✅ Session saved for Account {account_num}. The credential messages above have been "
        f"deleted from this chat. Use /status to check it's recognized as logged in — the "
        f"next health check (or a manual test post) will confirm it's actually valid.",
    )


@bot.message_handler(commands=["analytics"])
def cmd_analytics(message):
    if not is_authorized(message):
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].isdigit():
        bot.reply_to(message, "Usage: /analytics <account_number>, e.g. /analytics 1")
        return
    account_num = int(parts[1])
    if not account_exists(account_num):
        bot.reply_to(message, f"❌ No saved session for Account {account_num}.")
        return
    _run_analytics(message.chat.id, account_num)


@bot.callback_query_handler(func=lambda call: call.data.startswith("analytics_acc_"))
def analytics_button_pick(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[-1])
    if not account_exists(account_num):
        bot.send_message(call.message.chat.id, f"❌ No saved session for Account {account_num}.")
        return
    _run_analytics(call.message.chat.id, account_num)


def _run_analytics(chat_id, account_num):
    """Shared by both the /analytics command and the 📊 Analytics button —
    keeps the two entry points from drifting out of sync. Purely
    additive/read-only: does not touch anything in the posting flow
    (bot.py's video/caption/account-checkbox handlers, poster.py,
    scheduler.py) — a completely separate feature living alongside it."""
    bot.send_message(
        chat_id,
        f"📊 Checking Account {account_num}'s recent posts — this opens a real browser "
        f"session and can take up to a minute...",
    )

    def run():
        def screenshot_cb(path, msg):
            try:
                with open(path, "rb") as f:
                    bot.send_photo(chat_id, f, caption=msg)
            except Exception as e:
                logger.warning(f"[analytics] screenshot_cb failed: {e}")

        def document_cb(path, msg):
            try:
                with open(path, "rb") as f:
                    bot.send_document(chat_id, f, caption=msg)
            except Exception as e:
                logger.warning(f"[analytics] document_cb failed: {e}")

        try:
            profile_stats, entries = analytics.scrape_recent_posts(
                account_num, screenshot_cb=screenshot_cb, document_cb=document_cb
            )
        except Exception as e:
            bot.send_message(
                chat_id,
                f"❌ Couldn't fetch analytics for Account {account_num}: {_short(str(e), 1500)}",
            )
            return

        if not entries:
            bot.send_message(chat_id, f"No posts found for Account {account_num}.")
            return

        db.save_post_metrics(account_num, entries)

        lines = [f"📊 Account {account_num}"]
        followers = profile_stats.get("followers")
        posts_total = profile_stats.get("posts")
        if followers is not None or posts_total is not None:
            stat_bits = []
            if followers is not None:
                stat_bits.append(f"{followers:,} followers")
            if posts_total is not None:
                stat_bits.append(f"{posts_total:,} total posts")
            lines.append(" · ".join(stat_bits))
        lines.append(f"\nLast {len(entries)} posts checked:")
        for i, e in enumerate(entries, 1):
            v = f"{e['views']:,}" if e.get("views") is not None else "?"
            tag = " 🔥 likely viral" if e.get("is_likely_viral") else ""
            lines.append(f"{i}. 👁️ {v} views{tag}")
        bot.send_message(chat_id, "\n".join(lines))

        summary = analytics.summarize_with_ai(account_num, profile_stats, entries)
        if summary:
            bot.send_message(chat_id, f"🤖 AI insight:\n\n{_short(summary, 3500)}")
        else:
            bot.send_message(
                chat_id,
                "(Set OPENROUTER_API_KEY in .env to also get an AI-generated summary of "
                "these numbers — see .env.example.)",
            )

    # Scraping opens a real browser and can take a while — run it off the
    # main bot thread so /status, /addaccount etc. stay responsive
    # meanwhile, same reasoning as the scheduler running in its own thread.
    threading.Thread(target=run, daemon=True).start()


_STATUS_ICON = {
    "logged_in": "✅",
    "expired": "⚠️",
    "challenge": "🚫",
    "no_session": "➖",
    None: "❔",
}


@bot.message_handler(commands=["status"])
def show_status(message):
    if not is_authorized(message):
        return

    account_lines = []
    for acc in range(1, ACCOUNT_COUNT + 1):
        row = db.get_account_status(acc)
        status = row["status"] if row else None
        account_lines.append(f"{_STATUS_ICON.get(status, '❔')} Account {acc}: {status or 'not checked yet'}")

    jobs = db.get_pending_jobs_for_chat(message.chat.id)
    text = "👤 Account health:\n" + "\n".join(account_lines)

    if not jobs:
        text += "\n\nNo pending, scheduled, or review-needed jobs."
        bot.reply_to(message, text)
        return

    lines = []
    for j in jobs:
        when = "ASAP" if not j["scheduled_for"] else \
            datetime.datetime.fromtimestamp(j["scheduled_for"]).strftime("%Y-%m-%d %H:%M")
        lines.append(f"#{j['id']} · Account {j['account']} · {j['status']} · {when}")
    text += "\n\n📋 Your jobs:\n" + "\n".join(lines)
    bot.reply_to(message, text)

    # Offer explicit action buttons for anything needing manual review,
    # instead of requiring direct database/code intervention.
    review_jobs = [j for j in jobs if j["status"] == "needs_review"]
    for j in review_jobs:
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("✅ Checked — not posted, retry", callback_data=f"review_retry_{j['id']}"),
            types.InlineKeyboardButton("🗑️ Discard", callback_data=f"review_discard_{j['id']}"),
        )
        bot.send_message(
            message.chat.id,
            f"Job #{j['id']} (Account {j['account']}) needs review:\n{j.get('error') or 'Unknown outcome.'}",
            reply_markup=markup,
        )


# ---------------- Persistent keyboard button routing ----------------
# The buttons on _main_keyboard() aren't inline callbacks — Telegram just
# sends their label back as a plain text message, so route those exact
# strings to the same handlers the equivalent /command already uses.

@bot.message_handler(func=lambda m: m.text == "📊 Status")
def kb_status(message):
    show_status(message)


@bot.message_handler(func=lambda m: m.text == "❌ Cancel")
def kb_cancel(message):
    cancel_flow(message)


@bot.message_handler(func=lambda m: m.text == "➕ Add Account")
def kb_add_account(message):
    add_account_start(message)


@bot.message_handler(func=lambda m: m.text == "❓ Help")
def kb_help(message):
    send_welcome(message)


@bot.message_handler(func=lambda m: m.text == "📈 Analytics")
def kb_analytics(message):
    if not is_authorized(message):
        return
    _send_analytics_picker(message.chat.id)


@bot.callback_query_handler(func=lambda call: call.data.startswith("review_"))
def handle_review_action(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    _, action, job_id_str = call.data.split("_", 2)
    job_id = int(job_id_str)
    job = db.get_job(job_id)
    if not job or job["status"] != "needs_review":
        bot.send_message(call.message.chat.id, "That job is no longer awaiting review.")
        return

    if action == "discard":
        db.update_job(job_id, status="cancelled")
        if job.get("video_path") and os.path.exists(job["video_path"]):
            try:
                os.remove(job["video_path"])
            except OSError:
                pass
        bot.send_message(call.message.chat.id, f"🗑️ Job #{job_id} discarded.")

    elif action == "retry":
        if not job.get("video_path") or not os.path.exists(job["video_path"]):
            bot.send_message(
                call.message.chat.id,
                f"❌ Can't retry job #{job_id} — the original video file is no longer on disk. "
                f"Please resend the video from scratch.",
            )
            db.update_job(job_id, status="cancelled")
            return
        # Re-queue as a fresh 'pending' job — a human has explicitly
        # confirmed it's safe, so this is the ONE path where a
        # previously-uncertain job is allowed to run again.
        db.update_job(job_id, status="pending", attempts=0, error=None)
        bot.send_message(call.message.chat.id, f"🔁 Job #{job_id} re-queued for publishing.")


# ---------------- Video intake ----------------

# Standard cloud Telegram Bot API caps file downloads via getFile at 20MB,
# regardless of what limit we set in video_check.py. Going over this fails
# with an API error, not a clean "video too big" message, so check it
# up front using the size Telegram already reports on the message object.
TELEGRAM_CLOUD_API_DOWNLOAD_LIMIT_BYTES = 20 * 1024 * 1024


@bot.message_handler(content_types=["video"])
def handle_video(message):
    if not is_authorized(message):
        return

    existing = db.get_user_state(message.chat.id)
    if existing and existing.get("video_path"):
        # Any in-progress flow (choosing account, writing caption, confirming)
        # has a video_path set. Don't silently clobber it with a new upload.
        bot.reply_to(
            message,
            "⚠️ You already have an unfinished post in progress. Send /cancel first if you "
            "want to discard it and start over with this new video.",
        )
        return
    if existing and str(existing.get("stage", "")).startswith("add_account:"):
        bot.reply_to(
            message,
            "⚠️ You're in the middle of /addaccount. Send /cancel first if you want to "
            "abandon that and post a video instead.",
        )
        return

    if message.video.file_size and message.video.file_size > TELEGRAM_CLOUD_API_DOWNLOAD_LIMIT_BYTES:
        mb = message.video.file_size / (1024 * 1024)
        bot.reply_to(
            message,
            f"❌ This video is {mb:.1f}MB. The standard Telegram Bot API can only download "
            f"files up to 20MB — larger files need a self-hosted Local Bot API Server "
            f"(see SETUP.md) to lift that limit. Try a smaller/more compressed file for now.",
        )
        return

    bot.reply_to(message, "⏳ Downloading video...")

    try:
        file_info = bot.get_file(message.video.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
    except Exception as e:
        logger.warning(f"Video download failed for chat {message.chat.id}: {e}")
        bot.reply_to(
            message,
            "❌ Couldn't download that video from Telegram. It may be too large for the "
            "current setup, or Telegram had a transient error — try again or use a smaller file.",
        )
        return

    video_filename = f"reel_{int(time.time())}.mp4"
    local_video_path = os.path.join(DOWNLOAD_DIR, video_filename)
    with open(local_video_path, "wb") as f:
        f.write(downloaded_file)

    ok, reason = validate_video(local_video_path)
    if not ok:
        os.remove(local_video_path)
        bot.reply_to(message, f"❌ Video rejected: {reason}")
        return

    db.set_user_state(
        message.chat.id, video_path=local_video_path, account=None, caption=None,
        stage="choose_accounts", extra=json.dumps([]),
    )

    markup = _build_account_checkbox_markup([])
    bot.send_message(
        message.chat.id,
        "🎥 Video received. Tap accounts to select (multiple allowed), then Done:",
        reply_markup=markup,
    )


def _build_account_checkbox_markup(selected):
    """selected: list of int account numbers currently checked."""
    markup = types.InlineKeyboardMarkup(row_width=1)
    for i in range(1, ACCOUNT_COUNT + 1):
        mark = "☑️" if i in selected else "☐"
        markup.add(types.InlineKeyboardButton(f"{mark} Account {i}", callback_data=f"toggleacc_{i}"))
    done_label = f"✅ Done ({len(selected)} selected)" if selected else "✅ Done"
    markup.add(
        types.InlineKeyboardButton(done_label, callback_data="accounts_done"),
        types.InlineKeyboardButton("❌ Cancel", callback_data="accounts_cancel"),
    )
    return markup


@bot.callback_query_handler(func=lambda call: call.data.startswith("toggleacc_"))
def toggle_account_checkbox(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    account_num = int(call.data.split("_")[1])
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "choose_accounts":
        return

    if not account_exists(account_num):
        bot.answer_callback_query(call.id, f"No saved session for Account {account_num}.", show_alert=True)
        return

    selected = json.loads(state.get("extra") or "[]")
    if account_num in selected:
        selected.remove(account_num)
    else:
        selected.append(account_num)
    db.set_user_state(call.message.chat.id, extra=json.dumps(selected))

    markup = _build_account_checkbox_markup(selected)
    try:
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=markup)
    except Exception:
        pass  # e.g. "message not modified" if double-tapped — harmless


@bot.callback_query_handler(func=lambda call: call.data == "accounts_cancel")
def cancel_account_selection(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if state and state.get("video_path") and os.path.exists(state["video_path"]):
        try:
            os.remove(state["video_path"])
        except OSError:
            pass
    db.clear_user_state(call.message.chat.id)
    bot.send_message(call.message.chat.id, "❌ Cancelled.")


@bot.callback_query_handler(func=lambda call: call.data == "accounts_done")
def confirm_accounts(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "choose_accounts":
        return

    selected = json.loads(state.get("extra") or "[]")
    if not selected:
        bot.answer_callback_query(call.id, "Select at least one account first.", show_alert=True)
        return

    # From here on, "extra" switches shape from a plain accounts list to a
    # dict that also carries the per-post hide-likes choice — starts off
    # matching the .env global default (HIDE_LIKE_COUNTS), tap the button
    # at confirm time to override it just for this post.
    db.set_user_state(
        call.message.chat.id, stage="await_caption",
        extra=json.dumps({"accounts": selected, "hide_likes": HIDE_LIKE_COUNTS}),
    )
    names = ", ".join(str(a) for a in sorted(selected))
    msg = bot.send_message(call.message.chat.id, f"✅ Account(s) {names} selected.\n\n✍️ Send the caption:")
    bot.register_next_step_handler(msg, handle_caption)


def _confirm_markup(hide_likes):
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("📤 Post Now", callback_data="mode_now"),
        types.InlineKeyboardButton("🕒 Schedule", callback_data="mode_schedule"),
    )
    hide_label = "🙈 Hide likes: ON" if hide_likes else "👁️ Hide likes: OFF"
    markup.add(types.InlineKeyboardButton(hide_label, callback_data="toggle_hide_likes"))
    markup.add(types.InlineKeyboardButton("❌ Cancel", callback_data="mode_cancel"))
    return markup


def handle_caption(message):
    if not is_authorized(message):
        return
    state = db.get_user_state(message.chat.id)
    if not state or not state.get("video_path"):
        bot.reply_to(message, "Session lost, please resend the video.")
        return

    caption = message.text
    # Caption is persisted in SQLite (not an in-memory dict) so it survives a
    # bot restart between "caption sent" and "confirm" — same reasoning as the
    # jobs table.
    extra = json.loads(state.get("extra") or "{}")
    extra["caption"] = caption  # stash here too so the toggle handler can rebuild the review text
    db.set_user_state(message.chat.id, caption=caption, stage="await_confirm", extra=json.dumps(extra))

    selected = extra.get("accounts", [])
    accounts_str = ", ".join(str(a) for a in sorted(selected))
    # Plain text, NOT parse_mode="Markdown" — the caption is arbitrary user
    # content and may contain _, *, `, [ etc. Telegram's legacy Markdown
    # parser throws a "can't parse entities" error on unbalanced markers,
    # which would silently break this step for any caption containing them.
    bot.send_message(
        message.chat.id,
        f"📋 Review\nAccount(s): {accounts_str}\nCaption: {caption}\n\nWhat would you like to do?",
        reply_markup=_confirm_markup(extra.get("hide_likes", False)),
    )


@bot.callback_query_handler(func=lambda call: call.data == "toggle_hide_likes")
def toggle_hide_likes_btn(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    state = db.get_user_state(call.message.chat.id)
    if not state or state.get("stage") != "await_confirm":
        return
    extra = json.loads(state.get("extra") or "{}")
    extra["hide_likes"] = not extra.get("hide_likes", False)
    db.set_user_state(call.message.chat.id, extra=json.dumps(extra))
    try:
        bot.edit_message_reply_markup(
            call.message.chat.id, call.message.message_id,
            reply_markup=_confirm_markup(extra["hide_likes"]),
        )
    except Exception:
        pass  # e.g. "message not modified" if double-tapped — harmless


@bot.callback_query_handler(func=lambda call: call.data.startswith("mode_"))
def handle_mode(call):
    if not is_authorized(call):
        return
    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id
    state = db.get_user_state(chat_id)
    caption = state.get("caption") if state else None
    extra = json.loads(state.get("extra") or "{}") if state else {}
    selected = extra.get("accounts", [])
    hide_likes = extra.get("hide_likes", False)

    if call.data == "mode_cancel" or not state or caption is None or not selected:
        if state and state.get("video_path") and os.path.exists(state["video_path"]):
            os.remove(state["video_path"])
        db.clear_user_state(chat_id)
        bot.send_message(chat_id, "❌ Cancelled.")
        return

    if call.data == "mode_now":
        for acc in selected:
            db.create_job(chat_id, acc, state["video_path"], caption, scheduled_for=None, hide_likes=int(hide_likes))
        names = ", ".join(str(a) for a in sorted(selected))
        tag = " (likes hidden)" if hide_likes else ""
        bot.send_message(
            chat_id,
            f"🚀 Queued for immediate publishing to Account(s) {names}{tag}. I'll message you with updates.",
        )
        db.clear_user_state(chat_id)

    elif call.data == "mode_schedule":
        msg = bot.send_message(
            chat_id, "🕒 Send the date/time in format `YYYY-MM-DD HH:MM` (24h, server local time):",
            parse_mode="Markdown",
        )
        bot.register_next_step_handler(msg, handle_schedule_time)


def handle_schedule_time(message):
    if not is_authorized(message):
        return
    chat_id = message.chat.id
    state = db.get_user_state(chat_id)
    extra = json.loads(state.get("extra") or "{}") if state else {}
    selected = extra.get("accounts", [])
    hide_likes = extra.get("hide_likes", False)
    if not state or not state.get("video_path") or not state.get("caption") or not selected:
        bot.reply_to(message, "Session lost, please resend the video.")
        return

    try:
        dt = datetime.datetime.strptime(message.text.strip(), "%Y-%m-%d %H:%M")
        ts = dt.timestamp()
        if ts < time.time():
            bot.reply_to(message, "That time is in the past. Please /cancel and try again.")
            return
    except ValueError:
        bot.reply_to(message, "Invalid format. Please /cancel and try again with YYYY-MM-DD HH:MM.")
        return

    for acc in selected:
        db.create_job(chat_id, acc, state["video_path"], state["caption"], scheduled_for=ts, hide_likes=int(hide_likes))
    names = ", ".join(str(a) for a in sorted(selected))
    tag = " (likes hidden)" if hide_likes else ""
    bot.send_message(chat_id, f"✅ Scheduled for {dt.strftime('%Y-%m-%d %H:%M')} on Account(s) {names}{tag}.")
    db.clear_user_state(chat_id)


def _recover_after_restart():
    """Any job stuck in 'publishing' means the process died mid-attempt.
    Never assume it's safe to retry — mark it needs_review and tell the
    relevant chat, same policy as the live PublishUncertainError path."""
    recovered = db.recover_stuck_publishing_jobs()
    for job in recovered:
        logger.warning(f"Recovered stuck job {job['id']} (was 'publishing') as needs_review.")
        try:
            bot.send_message(
                job["chat_id"],
                f"⚠️ The bot restarted while job #{job['id']} (Account {job['account']}) was "
                f"publishing. Outcome unknown — please check the account manually before "
                f"resending, to avoid a duplicate post. Use /status to see it.",
            )
        except Exception as e:
            logger.warning(f"Could not notify chat {job['chat_id']} about recovered job: {e}")


if __name__ == "__main__":
    logger.info("Bot starting...")
    _recover_after_restart()
    start_scheduler(bot)
    start_health_checker(bot)
    print("🤖 Buzznity bot online.")
    bot.infinity_polling(timeout=60, long_polling_timeout=60)
