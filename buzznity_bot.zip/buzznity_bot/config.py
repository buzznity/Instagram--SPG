"""
config.py — central configuration loader.
All secrets come from environment variables (.env file), never hardcoded.
"""
import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
ALLOWED_CHAT_ID_RAW = os.getenv("ALLOWED_CHAT_ID")

if not BOT_TOKEN or not ALLOWED_CHAT_ID_RAW:
    raise SystemExit(
        "[CRITICAL] Missing TELEGRAM_BOT_TOKEN or ALLOWED_CHAT_ID. "
        "Copy .env.example to .env and fill it in."
    )

ALLOWED_CHAT_ID = int(ALLOWED_CHAT_ID_RAW)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DOWNLOAD_DIR = os.path.join(BASE_DIR, "downloads")
SESSION_DIR = os.path.join(BASE_DIR, "sessions")
LOG_DIR = os.path.join(BASE_DIR, "logs")
DB_PATH = os.path.join(BASE_DIR, "buzznity.db")

for d in (DOWNLOAD_DIR, SESSION_DIR, LOG_DIR):
    os.makedirs(d, exist_ok=True)

# Session dir holds live Instagram browser cookies — restrict to owner-only.
try:
    os.chmod(SESSION_DIR, 0o700)
except OSError:
    pass

# Minimum minutes between two posts on the SAME account.
# Keeping this non-trivial reduces (does not eliminate) the chance of
# Instagram's automation detection flagging the account.
MIN_MINUTES_BETWEEN_POSTS = int(os.getenv("MIN_MINUTES_BETWEEN_POSTS", "20"))

# How many accounts this deployment supports (numbered 1..N sessions)
ACCOUNT_COUNT = int(os.getenv("ACCOUNT_COUNT", "3"))

# Retry attempts for a single publish job before giving up
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "2"))

# How often (minutes) to check each account's session health in the background
HEALTH_CHECK_INTERVAL_MINUTES = int(os.getenv("HEALTH_CHECK_INTERVAL_MINUTES", "10"))

# If true, wait one full interval before the FIRST health check instead of
# checking immediately on startup.
HEALTH_CHECK_DELAY_FIRST_RUN = os.getenv("HEALTH_CHECK_DELAY_FIRST_RUN", "false").lower() == "true"
