# Buzznity Instagram Repost Test

This patch adds an Instagram Reel URL intake flow to the existing Telegram bot.

Flow:
Instagram public Reel URL
→ yt-dlp download (best single-file MP4, no ffmpeg required)
→ original description/caption extraction
→ target account selection
→ existing Buzznity scheduler/publisher
→ Telegram status/report

## Install

Inside the project virtualenv:

    pip install -r requirements.txt

## Test

1. Configure the existing `.env`.
2. Make sure at least one Instagram account session is saved.
3. Start the bot normally.
4. Send a public Reel URL from an account/content you own or are authorized to repost.
5. Select the target account.
6. Tap `Repost Now`.

## Important

This uses the existing browser-based Instagram publisher already present in
this project. It does not bypass CAPTCHAs, challenges, or account security
controls. Instagram access/automation rules still apply.

For the highest possible video quality, the downloader currently chooses the
best single-file format so it works without ffmpeg. If you install ffmpeg,
the downloader can later be changed to merge separate best video/audio
streams for higher available quality.
