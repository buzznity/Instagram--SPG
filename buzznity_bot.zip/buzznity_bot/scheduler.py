"""
scheduler.py — background thread that:
  1. Publishes 'pending' jobs (posted immediately, but still rate-limited)
  2. Publishes 'scheduled' jobs once their time is due
  3. Enforces MIN_MINUTES_BETWEEN_POSTS per account
Runs inside the same process as the bot, started as a daemon thread.
"""
import threading
import time
import os
from config import MIN_MINUTES_BETWEEN_POSTS
from logger import logger
import database as db
from poster import publish_reel, SessionExpiredError, ChallengeRequiredError, PublishError, PublishUncertainError

CHECK_INTERVAL_SECONDS = 30


def _process_job(job, bot):
    account = job["account"]
    minutes_since = db.minutes_since_last_post(account)

    if minutes_since is not None and minutes_since < MIN_MINUTES_BETWEEN_POSTS:
        # Not due yet — leave as-is, will be re-checked next loop.
        return False

    db.update_job(job["id"], status="publishing", attempts=job["attempts"] + 1)
    logger.info(f"Publishing job {job['id']} on account {account}")

    def status_cb(msg):
        try:
            bot.send_message(job["chat_id"], f"ℹ️ Account {account}: {msg}")
        except Exception:
            pass

    keep_video_file = False  # set True only for the "uncertain outcome" case

    try:
        publish_reel(account, job["video_path"], job["caption"], status_cb=status_cb)
        db.update_job(job["id"], status="done", error=None)
        db.record_post(account, job_id=job["id"])
        bot.send_message(
            job["chat_id"],
            f"🎉 Reel published successfully on Account {account}!",
        )
    except SessionExpiredError as e:
        db.update_job(job["id"], status="failed", error=str(e))
        bot.send_message(
            job["chat_id"],
            f"❌ Session expired for Account {account}. Run login.py to re-authenticate, "
            f"then resend the video.",
        )
    except ChallengeRequiredError as e:
        db.update_job(job["id"], status="failed", error=str(e))
        bot.send_message(
            job["chat_id"],
            f"🚫 Account {account}: Instagram has flagged this account with a checkpoint/"
            f"challenge/restriction. {e}\n\nThis requires manual action in a real browser — "
            f"automated retries will not fix it and may look worse to Instagram.",
        )
    except PublishUncertainError as e:
        # Deliberately NOT auto-retried and NOT marked plain "failed" — this
        # needs a human to check the account before anyone resends the video,
        # or a duplicate post is likely. The video file is kept (not deleted
        # below) so it can be resent once a human confirms it's safe.
        keep_video_file = True
        db.update_job(job["id"], status="needs_review", error=str(e))
        bot.send_message(
            job["chat_id"],
            f"⚠️ Account {account}: publish outcome UNKNOWN. {e}\n\n"
            f"Please check the account manually. Do NOT resend this video until you've "
            f"confirmed whether it already posted — resending an already-posted reel "
            f"will duplicate it.",
        )
    except PublishError as e:
        db.update_job(job["id"], status="failed", error=str(e))
        bot.send_message(job["chat_id"], f"❌ Publish failed for Account {account}: {e}")
    except Exception as e:
        db.update_job(job["id"], status="failed", error=str(e))
        logger.exception(f"Unexpected error on job {job['id']}")
        bot.send_message(job["chat_id"], f"❌ Unexpected error on Account {account}: {e}")
    finally:
        if not keep_video_file and os.path.exists(job["video_path"]):
            try:
                os.remove(job["video_path"])
            except OSError:
                pass
    return True


def _loop(bot):
    logger.info("Scheduler thread started.")
    while True:
        try:
            with db.get_conn() as conn:
                rows = conn.execute(
                    "SELECT * FROM jobs WHERE status='pending'"
                ).fetchall()
                pending = [dict(r) for r in rows]
            due_scheduled = db.get_due_scheduled_jobs()

            for job in pending + due_scheduled:
                _process_job(job, bot)
        except Exception:
            logger.exception("Scheduler loop error")
        time.sleep(CHECK_INTERVAL_SECONDS)


def start_scheduler(bot):
    t = threading.Thread(target=_loop, args=(bot,), daemon=True)
    t.start()
    return t
