"""
scheduler.py — background thread that:
  1. Publishes 'pending' jobs (posted immediately, but still rate-limited)
  2. Publishes 'scheduled' jobs once their time is due
  3. Enforces MIN_MINUTES_BETWEEN_POSTS per account
Runs inside the same process as the bot, started as a daemon thread.
"""
import threading
import time
import os
from config import MIN_MINUTES_BETWEEN_POSTS
from logger import logger
import database as db
from poster import publish_reel, SessionExpiredError, ChallengeRequiredError, PublishError, PublishUncertainError

CHECK_INTERVAL_SECONDS = 30

# Telegram messages have a hard ~4096 character cap — a send_message() call
# over that limit throws instead of sending, which (if unhandled) silently
# swallows the very failure notification it was trying to deliver. Some
# Playwright TimeoutErrors embed their entire internal retry log (dozens of
# lines) in the exception text, easily blowing past this. Always truncate
# any exception text before it goes into a Telegram message body.
TELEGRAM_MSG_SAFE_LIMIT = 3500


def _short(text, limit=TELEGRAM_MSG_SAFE_LIMIT):
    text = str(text)
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n... (truncated, {len(text) - limit} more characters — see logs/buzznity.log)"


def _send_screenshot_if_any(bot, chat_id, account, exc):
    """If the exception carries a screenshot_path and/or elements_path (set
    by poster.py on failure), send them directly to Telegram instead of
    requiring a manual VPS file-manager trip to fetch them."""
    shot = getattr(exc, "screenshot_path", None)
    if shot and os.path.exists(shot):
        try:
            with open(shot, "rb") as f:
                bot.send_photo(chat_id, f, caption=f"📸 Account {account} — debug screenshot")
        except Exception as send_err:
            logger.warning(f"Could not send screenshot {shot} to chat {chat_id}: {send_err}")

    dump = getattr(exc, "elements_path", None)
    if dump and os.path.exists(dump):
        try:
            with open(dump, "rb") as f:
                bot.send_document(
                    chat_id, f,
                    caption=f"🔍 Account {account} — page elements at time of failure",
                )
        except Exception as send_err:
            logger.warning(f"Could not send element dump {dump} to chat {chat_id}: {send_err}")


def _render_progress_bar(percent):
    filled = int(round(percent / 10))
    filled = max(0, min(10, filled))
    return "█" * filled + "░" * (10 - filled)


def _process_job(job, bot):
    account = job["account"]
    minutes_since = db.minutes_since_last_post(account)

    if minutes_since is not None and minutes_since < MIN_MINUTES_BETWEEN_POSTS:
        # Not due yet — leave as-is, will be re-checked next loop.
        return False

    db.update_job(job["id"], status="publishing", attempts=job["attempts"] + 1)
    logger.info(f"Publishing job {job['id']} on account {account}")

    # Single message, edited in place as progress updates come in — much
    # cleaner in the chat than a new message per step.
    progress_state = {"percent": 0, "message_id": None}
    try:
        sent = bot.send_message(
            job["chat_id"],
            f"⏳ Account {account}: starting...\n{_render_progress_bar(0)} 0%",
        )
        progress_state["message_id"] = sent.message_id
    except Exception:
        pass

    def status_cb(msg, percent=None):
        if percent is not None:
            progress_state["percent"] = percent
        pct = progress_state["percent"]
        text = f"⏳ Account {account}: {_short(msg, 500)}\n{_render_progress_bar(pct)} {pct}%"
        try:
            if progress_state["message_id"] is not None:
                bot.edit_message_text(
                    text, chat_id=job["chat_id"], message_id=progress_state["message_id"]
                )
            else:
                bot.send_message(job["chat_id"], text)
        except Exception:
            # Edits can fail harmlessly (e.g. identical text, or the
            # message is too old) — never let a status update crash the
            # actual publish flow.
            pass

    def screenshot_cb(path, msg):
        # Always wired up (not gated by DEBUG_SCREENSHOTS) since
        # poster.py now also uses this for the final post-publish profile
        # verification screenshot, which should always be sent. When
        # DEBUG_SCREENSHOTS=true, poster.py additionally calls this for
        # every intermediate step too, so the whole flow can be watched
        # screen by screen.
        try:
            with open(path, "rb") as f:
                bot.send_photo(job["chat_id"], f, caption=f"Account {account}: {msg}")
        except Exception as e:
            logger.warning(f"Could not send screenshot {path}: {e}")

    def document_cb(path, msg):
        # Same idea as screenshot_cb but for non-image debug files (the
        # page-elements .txt dumps), which Telegram won't accept via
        # send_photo.
        try:
            with open(path, "rb") as f:
                bot.send_document(job["chat_id"], f, caption=f"Account {account}: {msg}")
        except Exception as e:
            logger.warning(f"Could not send document {path}: {e}")

    keep_video_file = False  # set True only for the "uncertain outcome" case

    # job["hide_likes"] is 0/1/None from SQLite — None means "use the .env
    # global default" (poster.py handles that fallback itself).
    hide_likes = job.get("hide_likes")
    if hide_likes is not None:
        hide_likes = bool(hide_likes)

    try:
        publish_reel(
            account, job["video_path"], job["caption"],
            status_cb=status_cb,
            screenshot_cb=screenshot_cb,
            document_cb=document_cb,
            hide_likes=hide_likes,
        )
        db.update_job(job["id"], status="done", error=None)
        db.record_post(account, job_id=job["id"])
        bot.send_message(
            job["chat_id"],
            f"🎉 Reel published successfully on Account {account}!",
        )
    except SessionExpiredError as e:
        db.update_job(job["id"], status="failed", error=str(e))
        bot.send_message(
            job["chat_id"],
            f"❌ Session expired for Account {account}. Run login.py to re-authenticate, "
            f"then resend the video.",
        )
    except ChallengeRequiredError as e:
        db.update_job(job["id"], status="failed", error=str(e))
        bot.send_message(
            job["chat_id"],
            f"🚫 Account {account}: Instagram has flagged this account with a checkpoint/"
            f"challenge/restriction. {_short(e)}\n\nThis requires manual action in a real "
            f"browser — automated retries will not fix it and may look worse to Instagram.",
        )
        _send_screenshot_if_any(bot, job["chat_id"], account, e)
    except PublishUncertainError as e:
        # Deliberately NOT auto-retried and NOT marked plain "failed" — this
        # needs a human to check the account before anyone resends the video,
        # or a duplicate post is likely. The video file is kept (not deleted
        # below) so it can be resent once a human confirms it's safe.
        keep_video_file = True
        db.update_job(job["id"], status="needs_review", error=str(e))
        bot.send_message(
            job["chat_id"],
            f"⚠️ Account {account}: publish outcome UNKNOWN. {_short(e)}\n\n"
            f"Please check the account manually. Do NOT resend this video until you've "
            f"confirmed whether it already posted — resending an already-posted reel "
            f"will duplicate it.",
        )
        _send_screenshot_if_any(bot, job["chat_id"], account, e)
    except PublishError as e:
        # Keep the video file after a failure (not just the "uncertain"
        # case) — PublishError specifically means nothing was posted, so
        # there's no duplicate-post risk in keeping it, and having it
        # around makes debugging (checking the file itself, or manually
        # retrying) much easier than needing to re-upload from scratch.
        keep_video_file = True
        db.update_job(job["id"], status="failed", error=str(e))
        bot.send_message(
            job["chat_id"],
            f"❌ Publish failed for Account {account}: {_short(e)}\n\n"
            f"(Video file kept on the VPS at {job['video_path']} for inspection — "
            f"it won't auto-retry further. Delete it manually once you're done "
            f"checking it, or resend the video fresh to try again.)",
        )
        _send_screenshot_if_any(bot, job["chat_id"], account, e)
    except Exception as e:
        keep_video_file = True
        db.update_job(job["id"], status="failed", error=str(e))
        logger.exception(f"Unexpected error on job {job['id']}")
        bot.send_message(job["chat_id"], f"❌ Unexpected error on Account {account}: {_short(e)}")
    finally:
        if not keep_video_file and os.path.exists(job["video_path"]):
            try:
                os.remove(job["video_path"])
            except OSError:
                pass
    return True


def _loop(bot):
    logger.info("Scheduler thread started.")
    while True:
        try:
            with db.get_conn() as conn:
                rows = conn.execute(
                    "SELECT * FROM jobs WHERE status='pending'"
                ).fetchall()
                pending = [dict(r) for r in rows]
            due_scheduled = db.get_due_scheduled_jobs()

            for job in pending + due_scheduled:
                _process_job(job, bot)
        except Exception:
            logger.exception("Scheduler loop error")
        time.sleep(CHECK_INTERVAL_SECONDS)


def start_scheduler(bot):
    t = threading.Thread(target=_loop, args=(bot,), daemon=True)
    t.start()
    return t
