# Buzznity Reel Publisher — VPS Setup Guide

## ⚠️ Read this first

This tool automates Instagram through a real browser session (Playwright),
not Instagram's official API. That means:

- It **violates Instagram's Terms of Service**. Instagram actively detects
  and penalizes non-official automation — accounts can be rate-limited,
  action-blocked, or permanently banned, regardless of how careful the code is.
- This is **not something Anthropic/Claude built to evade detection**. No
  fingerprint spoofing, no captcha bypass, no anti-ban tricks are included,
  and none should be added.
- Get **written agreement from your client** that they own the Instagram
  account(s), understand the ban/suspension risk, and accept it. Don't post
  volumes or content types that look spammy — that's what triggers reviews.
- Keep `MIN_MINUTES_BETWEEN_POSTS` reasonable (20-60+ min). Rapid-fire
  posting across accounts is the single biggest red flag for automation
  detection.

If you want a version of this with zero ban risk, the alternative is
Instagram's official Content Publishing API (Graph API) — no browser
automation, but it requires a Business/Creator account, Meta App Review, and
only supports specific account types. Worth mentioning to the client as an
option.

---

## 1. Requirements

- A VPS (Ubuntu 22.04 recommended), at least 2GB RAM
- Root or sudo access
- A Telegram bot token from [@BotFather](https://t.me/BotFather)
- Your own Telegram numeric chat ID (message [@userinfobot](https://t.me/userinfobot) to get it)

## 2. Initial VPS setup

```bash
# SSH into your VPS
ssh root@your_vps_ip

# Create a dedicated non-root user (best practice)
adduser buzznity
usermod -aG sudo buzznity
su - buzznity

# System packages
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3 python3-venv python3-pip git unzip
```

## 3. Deploy the code

Upload the zip to the VPS (from your local machine):

```bash
scp buzznity_bot.zip buzznity@your_vps_ip:~/
```

Then on the VPS:

```bash
cd ~
unzip buzznity_bot.zip
cd buzznity_bot

python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
playwright install --with-deps chromium
playwright install chrome

# Optional but recommended: enables video duration validation
sudo apt install -y ffmpeg
```

⚠️ **`playwright install chrome` is required, not optional.** Playwright's
bundled open-source Chromium is missing H.264 video codec support on
Linux (a licensing restriction, not a bug) — it silently cannot
decode/preview video files at all. This breaks Instagram's own upload UI:
a video gets "selected" with no error, but the page never advances past
the empty drag-and-drop screen, because Instagram's client-side code is
waiting on a video preview that can never render. The bot code is already
set to use `channel="chrome"` (real Chrome) everywhere — this command is
what actually installs it.

## 4. Configure environment

```bash
cp .env.example .env
nano .env
```

Fill in:
- `TELEGRAM_BOT_TOKEN` — from BotFather
- `ALLOWED_CHAT_ID` — your Telegram numeric ID (only this ID can control the bot)
- Adjust `MIN_MINUTES_BETWEEN_POSTS`, `ACCOUNT_COUNT`, `MAX_RETRIES` if needed

## 5. Log in to each Instagram account (one-time, manual)

`login.py` deliberately uses `headless=False` — you need to actually see the
browser to type the password and any 2FA/challenge code. A stock Ubuntu VPS
has no display, so `headless=False` will crash there unless you bridge a
display. Three working options, easiest first:

**Option A — run login.py on your own laptop, then upload the session
folder (recommended, zero VPS display setup needed):**
```bash
# On your local machine — clone/copy this same project there first
python -m venv venv && source venv/bin/activate   # (Windows: venv\Scripts\activate)
pip install -r requirements.txt
playwright install chromium
playwright install chrome
python login.py
# This creates sessions/account_1/ (or 2, 3...) locally.
# Upload that exact folder to the VPS:
scp -r sessions/account_1 buzznity@your_vps_ip:~/buzznity_bot/sessions/
```
Repeat per account. This is the most reliable option and avoids any
VPS-side display complexity entirely.

**Option B — X11 forwarding (if your local machine has an X server, e.g.
Linux/macOS with XQuartz, or Windows with an X server installed):**
```bash
ssh -X buzznity@your_vps_ip
cd buzznity_bot && source venv/bin/activate
python login.py
```
The Chromium window opens *on your local screen* even though it's running
on the VPS. Can be slow/laggy over high-latency connections.

**Option C — Xvfb + VNC, if you must do it entirely on the VPS with no
local X server available:**
```bash
sudo apt install -y xvfb x11vnc

# Start a virtual display and VNC server (run in separate terminals/tmux panes,
# or background them):
Xvfb :99 -screen 0 1280x720x24 &
x11vnc -display :99 -forever -passwd yourVNCpassword &

# In a NEW terminal, on the SAME VPS, run login.py against that virtual display:
export DISPLAY=:99
cd ~/buzznity_bot && source venv/bin/activate
python login.py
```
Then, from your local machine, forward the VNC port over SSH and connect
with any VNC viewer (e.g. TigerVNC, RealVNC):
```bash
ssh -L 5900:localhost:5900 buzznity@your_vps_ip
# then point your VNC client at localhost:5900
```
You'll see the browser window in the VNC viewer and can type into it
normally. Kill `Xvfb`/`x11vnc` when done — don't leave a VNC server running
long-term, it's a security surface.

Whichever option you use, repeat for every account (1, 2, 3...). You'll
type the username/password and any 2FA/challenge code directly into the
opened browser window — `login.py` itself does not change between options,
only how you view/reach the display.

**Note:** `login.py` coordinates with the running bot service via the same
lock file the bot uses internally (`sessions/.account_N.lock`), so it's now
safe to run even while the bot service is live — it will wait for a
publish/health-check on that account to finish rather than opening the same
Chromium profile at the same time. You don't need to stop the service first,
though stopping it (`sudo systemctl stop buzznity-bot`) avoids any wait.

### 5b. Alternative: add an account via Telegram (no login.py, no VPS display)

Instead of the above, you can add an account by sending `/addaccount` to the
bot and pasting 4 cookie values copied from an already-logged-in browser's
dev tools (F12 → Application/Storage → Cookies → instagram.com):
`sessionid`, `csrftoken`, `ds_user_id`, `mid`. The bot asks for each one in
turn and **deletes your message immediately** after reading it, since these
are live login credentials.

This is faster (no VPS display juggling) but less robust than a full
`login.py` session — it's just those 4 cookies, not a whole browser profile,
so Instagram may ask for re-verification sooner. Use `login.py` when you can;
use `/addaccount` when you just need something working quickly. Sessions
created either way work identically for posting and health checks
afterward — the bot detects which kind is saved per account automatically.

⚠️ Copy these values from a browser session you trust, over a connection you
trust (i.e. don't do this on a shared/public computer) — anyone with these 4
values can access that Instagram account directly.

## 6. Test it manually first

```bash
cd ~/buzznity_bot
source venv/bin/activate
python bot.py
```

Message your bot on Telegram, send a test video, and confirm the full flow
works before setting it up as a 24/7 service.

Press `Ctrl+C` to stop once confirmed.

## 7. Run 24/7 with systemd

```bash
sudo cp buzznity-bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable buzznity-bot
sudo systemctl start buzznity-bot
```

Check status / logs:
```bash
sudo systemctl status buzznity-bot
tail -f ~/buzznity_bot/logs/buzznity.log
```

The service auto-restarts if it crashes (`Restart=always`) and starts
automatically on VPS reboot (`enable`).

## 7b. Session health checker

`health_checker.py` runs automatically alongside the bot (started from
`bot.py`). Every `HEALTH_CHECK_INTERVAL_MINUTES` (default 10), it briefly
opens each account's saved session headlessly and checks logged-in vs
expired — you'll get a Telegram message **only when status changes**
(e.g. goes from logged_in → expired), not on every check.

It shares a per-account lock (`account_locks.py`) with the publisher, so it
will never open the same browser profile while a real post is in progress —
it just skips that account for the current check and tries again next cycle.

## 8. Bot commands (for your client)

- Send any `.mp4` video to start a post
- `/status` — see pending/scheduled jobs
- `/cancel` — cancel the current in-progress flow

## 8b. Video size limit

The standard cloud Telegram Bot API can only download files up to **20MB**
via `getFile` (a hard Telegram-side limit, unrelated to this code). The bot
now checks this up front and rejects larger videos with a clear message
instead of failing obscurely mid-download.

If your client needs to send larger reels, the real fix is running a
[Local Bot API Server](https://github.com/tdlib/telegram-bot-api) on the
same VPS (raises the limit to ~2000MB) and pointing `pyTelegramBotAPI` at it
via `apihelper.API_URL`. This is a meaningful extra piece of infrastructure
— worth doing only if your client actually hits the 20MB wall regularly with
compressed reels (most well-compressed <60s reels are well under 20MB).

## 9. Maintenance

- **Session expired?** Re-run `login.py` for that account (locally, then
  re-upload the `sessions/account_N` folder — or via X11 forwarding on the VPS).
- **Instagram changed their UI and selectors broke?** This will happen
  eventually — Instagram changes their DOM periodically. Check
  `logs/buzznity.log` for the exact error, the fix is usually updating one
  selector in `poster.py`.
- **Logs**: `logs/buzznity.log` (app logs, rotates daily, keeps 14 days),
  `logs/service.log` (raw systemd stdout/stderr).
- **Sessions folder holds live Instagram cookies.** `login.py` and
  `config.py` both set it to `chmod 700` automatically, but double check
  after upload — especially if you `scp`'d it — and make sure the
  `buzznity` user (not root) owns it: `chown -R buzznity:buzznity sessions/`.
- **Debug screenshots**: on ambiguous/failed publishes and failed logins,
  a screenshot is saved to `logs/screenshots/`. Check there first when
  debugging a failure — it's usually faster than reading selectors.
- **Database**: `buzznity.db` (SQLite) holds all job history — back this up
  periodically if the client wants records.

## 10. Updating the bot

```bash
sudo systemctl stop buzznity-bot
# replace code files (keep .env, sessions/, buzznity.db)
sudo systemctl start buzznity-bot
```
