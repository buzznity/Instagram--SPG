"""
video_check.py — basic sanity checks on an uploaded video before it enters
the publish pipeline: extension, minimum size (catches truncated/failed
downloads), and Instagram's known Reels duration window if ffprobe is
available. This is not exhaustive video validation, just enough to catch
obviously-bad uploads before wasting a browser automation run on them.
"""
import os
import shutil
import subprocess
from logger import logger

MIN_SIZE_BYTES = 10 * 1024  # 10 KB — anything smaller almost certainly failed to download
MAX_SIZE_BYTES = 4 * 1024 * 1024 * 1024  # 4 GB — generous upper bound
MIN_DURATION_SECONDS = 3
MAX_DURATION_SECONDS = 90 * 60  # Instagram Reels cap is far lower, but this just catches absurd files


def validate_video(path: str):
    """Returns (ok: bool, reason: str|None)."""
    if not path.lower().endswith(".mp4"):
        return False, "File is not an .mp4."

    try:
        size = os.path.getsize(path)
    except OSError as e:
        return False, f"Could not read file: {e}"

    if size < MIN_SIZE_BYTES:
        return False, "File is too small — the download likely failed or was cut off."
    if size > MAX_SIZE_BYTES:
        return False, "File is too large."

    if shutil.which("ffprobe"):
        try:
            result = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=noprint_wrappers=1:nokey=1", path],
                capture_output=True, text=True, timeout=15,
            )
            duration = float(result.stdout.strip())
            if duration < MIN_DURATION_SECONDS:
                return False, f"Video is too short ({duration:.1f}s)."
            if duration > MAX_DURATION_SECONDS:
                return False, f"Video is unusually long ({duration/60:.1f} min) — check the file."
        except Exception as e:
            # ffprobe present but failed to parse — don't block on this,
            # just log it, since duration isn't a hard Instagram requirement here.
            logger.warning(f"ffprobe duration check failed for {path}: {e}")
    else:
        logger.info("ffprobe not installed — skipping duration check (extension/size checks still applied).")

    return True, None
