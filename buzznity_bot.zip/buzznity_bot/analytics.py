"""
analytics.py — read-only Instagram automation: visits an account's own
profile/reels tab and reads the view/like/comment counts Instagram already
shows on screen, then (optionally) asks an LLM via OpenRouter to summarize
what's working. Never modifies anything on Instagram — no posting, no
liking, no following. Same session/browser plumbing as poster.py.

Selector note (read this before debugging a failed scrape): exactly like
the posting flow, these selectors are a first-pass best guess at Instagram's
current grid/overlay markup, not verified against a live screenshot yet.
If scraping comes back empty or wrong, turn on DEBUG_SCREENSHOTS and check
the screenshot + element dump this sends to Telegram, the same way every
posting-flow selector got fixed earlier.
"""
import os
import re
import json
import time
import base64
import requests
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
import session_store
from config import OPENROUTER_API_KEY, OPENROUTER_MODEL, DEBUG_SCREENSHOTS
from logger import logger
from poster import _save_screenshot, _dump_page_elements, SCREENSHOT_DIR  # reuse the same debug helpers


def _parse_count(text):
    """Instagram shows counts like '1.6K', '235.3K', '12M', or plain '482'."""
    if not text:
        return None
    text = text.strip().upper().replace(",", "")
    m = re.match(r"^([\d.]+)([KM]?)$", text)
    if not m:
        m = re.search(r"([\d.]+)\s*([KM]?)\b", text)
        if not m:
            return None
    num, suffix = m.group(1), m.group(2)
    try:
        value = float(num)
    except ValueError:
        return None
    if suffix == "K":
        value *= 1_000
    elif suffix == "M":
        value *= 1_000_000
    return int(value)


def read_view_counts_via_ai(screenshot_path, expected_count):
    """Fallback for when text-scraping the grid tiles comes back mostly
    empty (Instagram's view-count overlay apparently isn't in accessible
    text form on this account/session). Sends the screenshot itself to a
    vision-capable model via OpenRouter and asks it to read the numbers
    directly off the image — the same way a person would just look at it.
    Returns a list of ints/None (same length as expected_count when
    possible), or None entirely if this couldn't run (no API key, no
    screenshot, or the AI call/parse failed)."""
    if not OPENROUTER_API_KEY or not screenshot_path or not os.path.exists(screenshot_path):
        return None
    try:
        with open(screenshot_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")

        prompt = (
            f"This is a screenshot of an Instagram profile's Reels grid, showing up to "
            f"{expected_count} video tiles in reading order (left to right, top to bottom). "
            f"Each tile typically has a small view-count overlay (a play/eye icon next to a "
            f"number like '39.4K' or '512'). Read each tile's view count in order.\n\n"
            f"Reply with ONLY a JSON array of integers, one per tile, converting 'K' to "
            f"thousands and 'M' to millions (e.g. '39.4K' -> 39400). Use null for any tile "
            f"whose count isn't visible or readable. No other text, just the JSON array."
        )
        resp = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={"Authorization": f"Bearer {OPENROUTER_API_KEY}"},
            json={
                "model": OPENROUTER_MODEL,
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                    ],
                }],
            },
            timeout=45,
        )
        resp.raise_for_status()
        text = resp.json()["choices"][0]["message"]["content"].strip()
        # Models sometimes wrap JSON in ```json fences despite instructions —
        # strip those before parsing.
        text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
        parsed = json.loads(text)
        if not isinstance(parsed, list):
            return None
        return [int(v) if isinstance(v, (int, float)) else None for v in parsed]
    except Exception as e:
        logger.warning(f"[analytics] AI vision view-count reading failed: {e}")
        return None


def scrape_profile_stats(page):
    """Reads 'N posts', 'N followers', 'N following' from the profile
    header. Returns a dict with any of the three as None if not found —
    matched against the page's plain visible text rather than a specific
    selector, since this exact three-number line is a stable convention
    Instagram has kept even as other markup has shifted."""
    stats = {"posts": None, "followers": None, "following": None}
    try:
        body_text = page.locator("body").inner_text(timeout=5000)
    except Exception:
        return stats
    for key in ("posts", "followers", "following"):
        m = re.search(r"([\d.,]+[KM]?)\s+" + key, body_text, re.I)
        if m:
            stats[key] = _parse_count(m.group(1))
    return stats


def scrape_recent_posts(account, limit=20, screenshot_cb=None, document_cb=None):
    """Returns (profile_stats, entries):
      profile_stats — dict with posts/followers/following (may have None
        values if not readable).
      entries — list of dicts: post_url, caption_snippet, likes, comments,
        views, is_likely_viral (any numeric field may be None if not
        readable). "is_likely_viral" is computed AFTER scraping, by
        comparing each post's views against the account's own average —
        not just handed to the AI to eyeball, so the flagging is
        consistent regardless of which model is summarizing it.
    Raises on total failure (e.g. no session, couldn't reach the profile
    at all) — callers should catch and report that clearly rather than
    silently returning empty results."""
    results = []
    if session_store.session_kind(account) is None:
        raise RuntimeError(f"No saved session for account {account}.")

    with sync_playwright() as p, session_store.open_context(p, account, headless=True) as context:
        page = context.new_page()
        page.goto("https://www.instagram.com/", timeout=30000)

        try:
            avatar_img = page.locator("img[alt*='profile picture' i]").first
            avatar_img.wait_for(state="visible", timeout=15000)
            avatar_link = avatar_img.locator("xpath=ancestor::a[1]")
            avatar_link.click()
            page.wait_for_timeout(2500)
        except PWTimeout as e:
            shot = _save_screenshot(page, account, "analytics_profile_nav_failed")
            dump = _dump_page_elements(page, account, "analytics_profile_nav_failed")
            if shot and screenshot_cb:
                screenshot_cb(shot, f"Account {account} — couldn't reach profile page")
            if dump and document_cb:
                document_cb(dump, "Profile navigation elements")
            raise RuntimeError(f"Could not navigate to the profile page: {e}")

        profile_stats = scrape_profile_stats(page)

        # View-count overlays are shown on the dedicated Reels tab, not
        # necessarily the general "Posts" grid the profile lands on by
        # default — try switching to it. Best-effort: if this tab isn't
        # found under this label, scraping continues on whatever grid is
        # currently showing rather than failing outright.
        try:
            reels_tab = page.get_by_role("link", name=re.compile("reels", re.I)).first
            reels_tab.wait_for(state="visible", timeout=5000)
            reels_tab.click()
            page.wait_for_timeout(2000)
        except PWTimeout:
            pass

        # Each grid tile is a link to /reel/<id>/ or /p/<id>/. Instagram
        # typically overlays a view/like-style count directly on video
        # tiles — read whatever text is inside the tile as a first pass.
        tiles = page.locator("a[href*='/reel/'], a[href*='/p/']")
        try:
            tiles.first.wait_for(state="visible", timeout=15000)
        except PWTimeout as e:
            shot = _save_screenshot(page, account, "analytics_no_tiles_found")
            dump = _dump_page_elements(page, account, "analytics_no_tiles_found")
            if shot and screenshot_cb:
                screenshot_cb(shot, f"Account {account} — no post tiles found on profile")
            if dump and document_cb:
                document_cb(dump, "Profile grid elements")
            raise RuntimeError(f"No posts found on the profile grid: {e}")

        count = min(tiles.count(), limit)
        debug_lines = []
        for i in range(count):
            tile = tiles.nth(i)
            try:
                post_url = tile.get_attribute("href")
                raw_text = tile.inner_text(timeout=3000)
            except Exception:
                post_url, raw_text = None, ""
            numbers = re.findall(r"[\d.,]+[KM]?", raw_text or "")
            parsed = [_parse_count(n) for n in numbers]
            parsed = [n for n in parsed if n is not None]
            debug_lines.append(f"Tile {i+1}: raw_text={raw_text!r} -> parsed_numbers={parsed}")
            # Best-effort only — grid tiles usually show ONE overlay stat
            # (views for video posts). Likes/comments generally require
            # opening the individual post, which this first pass doesn't
            # do yet (kept simple/fast for now).
            results.append({
                "post_url": post_url,
                "caption_snippet": None,
                "views": parsed[0] if parsed else None,
                "likes": None,
                "comments": None,
            })

        # Always take this screenshot (not gated by DEBUG_SCREENSHOTS) —
        # it's needed below as the input for the AI vision fallback, not
        # just for debugging.
        grid_shot = _save_screenshot(page, account, "analytics_grid_scraped")
        if DEBUG_SCREENSHOTS and grid_shot and screenshot_cb:
            screenshot_cb(grid_shot, f"Account {account} — profile grid scraped")
            # Dump exactly what raw text each tile actually contained —
            # this is the key diagnostic for why view-count parsing
            # succeeds or fails, without guessing.
            try:
                debug_path = os.path.join(
                    SCREENSHOT_DIR, f"account{account}_tile_raw_text_{int(time.time())}.txt"
                )
                with open(debug_path, "w", encoding="utf-8") as f:
                    f.write("\n".join(debug_lines))
                if document_cb:
                    document_cb(debug_path, f"Account {account} — raw tile text (for debugging view-count parsing)")
            except Exception as e:
                logger.warning(f"[analytics] Could not save tile raw-text debug dump: {e}")

        # Fallback: if text-scraping mostly came back empty (Instagram's
        # overlay apparently isn't readable as accessible text on this
        # account/session — the exact case reported), ask a vision model
        # to just read the numbers off the screenshot directly instead.
        missing = sum(1 for r in results if r.get("views") is None)
        if results and missing > len(results) / 2 and grid_shot:
            ai_views = read_view_counts_via_ai(grid_shot, len(results))
            if ai_views:
                for i, v in enumerate(ai_views):
                    if i < len(results) and results[i].get("views") is None and v is not None:
                        results[i]["views"] = v
                logger.info(
                    f"[account {account}] AI vision fallback filled in "
                    f"{sum(1 for v in ai_views if v is not None)} view counts."
                )

    # Flag likely-viral posts by comparing each against the account's own
    # average — computed here in code, not left for the AI to eyeball, so
    # it's consistent no matter which model ends up summarizing it.
    view_values = [r["views"] for r in results if r.get("views") is not None]
    if view_values:
        avg_views = sum(view_values) / len(view_values)
        for r in results:
            r["is_likely_viral"] = (
                r.get("views") is not None and avg_views > 0 and r["views"] >= avg_views * 1.5
            )
    else:
        avg_views = None
        for r in results:
            r["is_likely_viral"] = False

    return profile_stats, results


def summarize_with_ai(account, profile_stats, entries):
    """Sends the scraped numbers to an LLM via OpenRouter and asks for a
    short, plain-language summary of what's working. Returns None (not an
    error) if OPENROUTER_API_KEY isn't configured — callers should fall
    back to showing the raw numbers only in that case."""
    if not OPENROUTER_API_KEY:
        return None
    if not entries:
        return None

    lines = []
    for i, e in enumerate(entries, 1):
        parts = [f"Post {i}:"]
        if e.get("views") is not None:
            parts.append(f"views={e['views']}")
        if e.get("likes") is not None:
            parts.append(f"likes={e['likes']}")
        if e.get("comments") is not None:
            parts.append(f"comments={e['comments']}")
        if e.get("caption_snippet"):
            parts.append(f"caption=\"{e['caption_snippet'][:80]}\"")
        if e.get("is_likely_viral"):
            parts.append("[FLAGGED AS LIKELY VIRAL — well above this account's average]")
        lines.append(" ".join(parts))
    data_block = "\n".join(lines)

    profile_line = "Profile: "
    if profile_stats:
        pieces = []
        if profile_stats.get("followers") is not None:
            pieces.append(f"{profile_stats['followers']:,} followers")
        if profile_stats.get("posts") is not None:
            pieces.append(f"{profile_stats['posts']:,} total posts")
        profile_line += ", ".join(pieces) if pieces else "(not readable)"
    else:
        profile_line += "(not readable)"

    prompt = (
        f"{profile_line}\n\n"
        f"Engagement numbers for the {len(entries)} most recent Instagram reels from this "
        f"account:\n\n{data_block}\n\n"
        f"Some posts are pre-flagged as 'likely viral' (well above this account's own "
        f"average) — call those out specifically and, if a caption is available for them, "
        f"note anything in common. In 3-5 short bullet points, give a plain-language read on "
        f"what's working and one or two concrete suggestions. Be concise — this is going "
        f"straight into a Telegram message, not a report."
    )

    try:
        resp = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={"Authorization": f"Bearer {OPENROUTER_API_KEY}"},
            json={
                "model": OPENROUTER_MODEL,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.warning(f"OpenRouter summarization failed: {e}")
        return None
