"""
analytics.py — read-only Instagram automation: visits an account's own
profile/reels tab and reads the view/like/comment counts Instagram already
shows on screen, then (optionally) asks an LLM via OpenRouter to summarize
what's working. Never modifies anything on Instagram — no posting, no
liking, no following. Same session/browser plumbing as poster.py.

Selector note (read this before debugging a failed scrape): exactly like
the posting flow, these selectors are a first-pass best guess at Instagram's
current grid/overlay markup, not verified against a live screenshot yet.
If scraping comes back empty or wrong, turn on DEBUG_SCREENSHOTS and check
the screenshot + element dump this sends to Telegram, the same way every
posting-flow selector got fixed earlier.
"""
import os
import re
import json
import time
import base64
import requests
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
import session_store
import database as db
from account_locks import account_lock
from config import OPENROUTER_API_KEY, OPENROUTER_MODEL, DEBUG_SCREENSHOTS, ANALYTICS_MAX_POSTS
from logger import logger
from poster import _save_screenshot, _dump_page_elements, SCREENSHOT_DIR  # reuse the same debug helpers


def _parse_count(text):
    """Instagram shows counts like '1.6K', '235.3K', '12M', or plain '482'."""
    if not text:
        return None
    text = text.strip().upper().replace(",", "")
    m = re.match(r"^([\d.]+)([KM]?)$", text)
    if not m:
        m = re.search(r"([\d.]+)\s*([KM]?)\b", text)
        if not m:
            return None
    num, suffix = m.group(1), m.group(2)
    try:
        value = float(num)
    except ValueError:
        return None
    if suffix == "K":
        value *= 1_000
    elif suffix == "M":
        value *= 1_000_000
    return int(value)


def read_view_counts_via_ai(screenshot_path, expected_count):
    """Fallback for when text-scraping the grid tiles comes back mostly
    empty (Instagram's view-count overlay apparently isn't in accessible
    text form on this account/session). Sends the screenshot itself to a
    vision-capable model via OpenRouter and asks it to read the numbers
    directly off the image — the same way a person would just look at it.
    Returns a list of ints/None (length as read by the model — may be
    shorter than expected_count if the screenshot has fewer rows than
    that, e.g. one viewport of a scrolled grid), or None entirely if this
    couldn't run (no API key, no screenshot, or the AI call/parse failed)."""
    if not OPENROUTER_API_KEY or not screenshot_path or not os.path.exists(screenshot_path):
        return None
    try:
        with open(screenshot_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")

        prompt = (
            f"This is a screenshot of one section of an Instagram profile's Reels grid — "
            f"it may be a partial/scrolled view, not necessarily the full grid. There are up "
            f"to {expected_count} video tiles visible in THIS image, in reading order (left "
            f"to right, top to bottom). Each tile typically has a small overlay showing its "
            f"play/view count (labeled 'views', 'plays', or 'Play count' depending on where "
            f"it's shown — a play/eye icon next to a number like '39.4K' or '512'). Read each "
            f"tile actually visible in this specific image, in order.\n\n"
            f"Reply with ONLY a JSON array of integers, one per tile you can actually see in "
            f"this image (don't pad to {expected_count} if fewer are visible), converting 'K' "
            f"to thousands and 'M' to millions (e.g. '39.4K' -> 39400). Use null for any "
            f"visible tile whose count isn't readable. No other text, just the JSON array."
        )
        resp = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={"Authorization": f"Bearer {OPENROUTER_API_KEY}"},
            json={
                "model": OPENROUTER_MODEL,
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                    ],
                }],
            },
            timeout=45,
        )
        resp.raise_for_status()
        text = resp.json()["choices"][0]["message"]["content"].strip()
        # Models sometimes wrap JSON in ```json fences despite instructions —
        # strip those before parsing.
        text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
        parsed = json.loads(text)
        if not isinstance(parsed, list):
            return None
        return [int(v) if isinstance(v, (int, float)) else None for v in parsed]
    except Exception as e:
        logger.warning(f"[analytics] AI vision view-count reading failed: {e}")
        return None


def read_all_view_counts_via_ai(page, account, tile_count, screenshot_cb=None):
    """Covers a grid too tall for one screenshot: scrolls from the top in
    viewport-sized steps, asking the AI to read each section, and
    concatenates the results in order. Stops once it has read at least
    tile_count values or scrolling stops revealing new content. Returns a
    list of ints/None the same length as tile_count (padded with None if
    short), or None entirely if nothing could be read at all."""
    try:
        page.evaluate("window.scrollTo(0, 0)")
    except Exception:
        pass
    page.wait_for_timeout(500)

    all_views = []
    prev_scroll_y = -1
    for _ in range(40):  # generous cap on sections, matches the load-scroll cap loosely
        if len(all_views) >= tile_count:
            break
        shot = _save_screenshot(page, account, f"analytics_ai_section_{len(all_views)}")
        if not shot:
            break
        # A rough per-viewport tile estimate — doesn't need to be exact,
        # it's just the prompt's upper bound, not a hard requirement.
        section_views = read_view_counts_via_ai(shot, expected_count=12)
        if section_views:
            all_views.extend(section_views)
            if DEBUG_SCREENSHOTS and screenshot_cb:
                screenshot_cb(shot, f"Account {account} — AI-read section ({len(section_views)} values)")

        try:
            scroll_y = page.evaluate("window.scrollY")
        except Exception:
            scroll_y = None
        if scroll_y is not None and scroll_y == prev_scroll_y:
            break  # reached the bottom — no further scrolling happened
        prev_scroll_y = scroll_y

        try:
            page.evaluate("window.scrollBy(0, window.innerHeight * 0.9)")
        except Exception:
            page.mouse.wheel(0, 650)
        page.wait_for_timeout(900)

    if not all_views:
        return None
    # Pad/truncate to exactly tile_count so index-based merging in the
    # caller lines up cleanly.
    all_views = (all_views + [None] * tile_count)[:tile_count]
    return all_views


def scrape_profile_stats(page):
    """Reads 'N posts', 'N followers', 'N following' from the profile
    header. Returns a dict with any of the three as None if not found —
    matched against the page's plain visible text rather than a specific
    selector, since this exact three-number line is a stable convention
    Instagram has kept even as other markup has shifted."""
    stats = {"posts": None, "followers": None, "following": None}
    try:
        body_text = page.locator("body").inner_text(timeout=5000)
    except Exception:
        return stats
    for key in ("posts", "followers", "following"):
        m = re.search(r"([\d.,]+[KM]?)\s+" + key, body_text, re.I)
        if m:
            stats[key] = _parse_count(m.group(1))
    return stats


def quick_profile_report(account, screenshot_cb=None):
    """A fast alternative to scrape_recent_posts: just the profile header
    numbers (followers/following/posts) plus one screenshot — no clicking
    into individual posts, so this takes seconds rather than the minutes a
    full /analytics run can take on an account with many posts. Returns
    a profile_stats dict (username/followers/following/posts). Raises on
    failure — same account_lock/pending-job coordination as the full
    scrape, for the same correctness reasons, though the brief runtime
    here means it's very unlikely to actually contend with a posting job."""
    if session_store.session_kind(account) is None:
        raise RuntimeError(f"No saved session for account {account}.")
    if db.has_pending_publish_job(account):
        raise RuntimeError(
            f"Account {account} has a post queued to publish right now — try again in a moment."
        )

    with account_lock(account, blocking=True):
        with sync_playwright() as p, session_store.open_context(p, account, headless=True) as context:
            page = context.new_page()
            page.goto("https://www.instagram.com/", timeout=30000)

            avatar_img = page.locator("img[alt*='profile picture' i]").first
            avatar_img.wait_for(state="visible", timeout=15000)
            avatar_link = avatar_img.locator("xpath=ancestor::a[1]")
            profile_href = avatar_link.get_attribute("href")
            username = profile_href.strip("/").split("/")[0] if profile_href else None
            avatar_link.click()
            page.wait_for_timeout(2000)

            profile_stats = scrape_profile_stats(page)
            profile_stats["username"] = username

            shot = _save_screenshot(page, account, "quick_report")
            if shot and screenshot_cb:
                screenshot_cb(shot, f"Account {account} (@{username}) — quick profile snapshot")

    return profile_stats


def scrape_recent_posts(account, limit=None, status_cb=None, screenshot_cb=None, document_cb=None):
    """Returns (profile_stats, entries):
      profile_stats — dict with posts/followers/following (may have None
        values if not readable).
      entries — list of dicts: post_url, caption_snippet, likes, comments,
        views, is_likely_viral (any numeric field may be None if not
        readable). "is_likely_viral" is computed AFTER scraping, by
        comparing each post's views against the account's own average —
        not just handed to the AI to eyeball, so the flagging is
        consistent regardless of which model is summarizing it.
    limit=None (the default) means "all of this account's posts" — reads
    the actual total from the profile header and scrolls the grid to load
    that many, up to a hard safety cap (ANALYTICS_MAX_POSTS) so a very
    large account can't turn one /analytics run into an unbounded scrape.
    Pass an explicit int to cap it lower than that.
    Raises on total failure (e.g. no session, couldn't reach the profile
    at all) — callers should catch and report that clearly rather than
    silently returning empty results."""
    results = []
    if session_store.session_kind(account) is None:
        raise RuntimeError(f"No saved session for account {account}.")
    if db.has_pending_publish_job(account):
        raise RuntimeError(
            f"Account {account} has a post queued to publish right now — analytics waits "
            f"for that to go first. Try again in a couple of minutes."
        )

    # Coordinates with poster.py/health_checker.py via the SAME lock
    # so this can never open the same profile directory concurrently
    # with a publish job (Chromium doesn't allow two processes to open
    # one persistent profile at once) — this was previously missing
    # entirely, which risked exactly that conflict.
    with account_lock(account, blocking=True):
        with sync_playwright() as p, session_store.open_context(p, account, headless=True) as context:
            page = context.new_page()
            page.goto("https://www.instagram.com/", timeout=30000)

            try:
                avatar_img = page.locator("img[alt*='profile picture' i]").first
                avatar_img.wait_for(state="visible", timeout=15000)
                avatar_link = avatar_img.locator("xpath=ancestor::a[1]")
                # Grab the href BEFORE clicking — it directly reveals which
                # account this actually is ("/username/"), so any mismatch
                # between the expected account and what actually got scraped
                # is immediately visible in the output, instead of silently
                # returning another account's numbers.
                profile_href = avatar_link.get_attribute("href")
                username_from_href = profile_href.strip("/").split("/")[0] if profile_href else None
                avatar_link.click()
                page.wait_for_timeout(2500)
            except PWTimeout as e:
                shot = _save_screenshot(page, account, "analytics_profile_nav_failed")
                dump = _dump_page_elements(page, account, "analytics_profile_nav_failed")
                if shot and screenshot_cb:
                    screenshot_cb(shot, f"Account {account} — couldn't reach profile page")
                if dump and document_cb:
                    document_cb(dump, "Profile navigation elements")
                raise RuntimeError(f"Could not navigate to the profile page: {e}")

            profile_stats = scrape_profile_stats(page)
            profile_stats["username"] = username_from_href

            # CONFIRMED via direct screenshot evidence: view-count overlays
            # (a 👁 icon + number, e.g. "5,164", "74.3K") DO appear directly
            # on grid tiles as plain visible text — but only on the
            # profile's dedicated Reels tab (instagram.com/<username>/reels/),
            # not the general "Posts" grid the profile lands on by default.
            # An earlier attempt to reach this tab via clicking a "Reels"
            # link was the actual bug (it matched the sidebar's unrelated
            # global nav icon instead, navigating away entirely). Now that
            # the username is already known, going there directly by URL
            # sidesteps that class of bug completely — there's no click
            # involved, so it can't land on the wrong page.
            if username_from_href:
                try:
                    page.goto(f"https://www.instagram.com/{username_from_href}/reels/", timeout=20000)
                    page.wait_for_timeout(2000)
                except Exception as e:
                    logger.warning(
                        f"[analytics] Could not navigate directly to the Reels tab, "
                        f"staying on the general profile grid instead: {e}"
                    )

            # Each grid tile is a link to /reel/<id>/ or /p/<id>/. Instagram
            # typically overlays a view/like-style count directly on video
            # tiles — read whatever text is inside the tile as a first pass.
            tiles = page.locator("a[href*='/reel/'], a[href*='/p/']")
            try:
                tiles.first.wait_for(state="visible", timeout=15000)
            except PWTimeout as e:
                shot = _save_screenshot(page, account, "analytics_no_tiles_found")
                dump = _dump_page_elements(page, account, "analytics_no_tiles_found")
                if shot and screenshot_cb:
                    screenshot_cb(shot, f"Account {account} — no post tiles found on profile")
                if dump and document_cb:
                    document_cb(dump, "Profile grid elements")
                raise RuntimeError(f"No posts found on the profile grid: {e}")

            # Determine how many tiles we're aiming for, then scroll the grid
            # to lazy-load that many. limit=None (the default) means "all of
            # them" — read from the profile header's own post count, capped by
            # ANALYTICS_MAX_POSTS regardless so one run can't turn into an
            # unbounded scrape on a very large account.
            if limit is not None:
                target_count = min(limit, ANALYTICS_MAX_POSTS)
            else:
                target_count = min(profile_stats.get("posts") or ANALYTICS_MAX_POSTS, ANALYTICS_MAX_POSTS)

            # Confirmed via direct report: this previously stopped early
            # (loaded 29 of a real 48) — Instagram's lazy-load can lag
            # behind a fixed short wait on a slower connection, making it
            # LOOK like loading stalled when it hadn't actually finished.
            # More patience per attempt, and require several consecutive
            # truly-empty rounds (each with its own longer settle wait)
            # before concluding we've really reached the end, rather than
            # giving up after one short quiet patch.
            last_tile_count = tiles.count()
            stall_rounds = 0
            for _ in range(150):  # generous cap on scroll attempts, not on tiles themselves
                if tiles.count() >= target_count:
                    break
                page.mouse.wheel(0, 2200)
                page.wait_for_timeout(1500)
                current = tiles.count()
                if current == last_tile_count:
                    stall_rounds += 1
                    if stall_rounds >= 8:
                        # One last, longer wait before truly giving up —
                        # covers a genuinely slow network round-trip that
                        # even 8 quick rechecks didn't catch.
                        page.wait_for_timeout(4000)
                        if tiles.count() == last_tile_count:
                            break  # confirmed — no new tiles loading, reached the actual end
                        stall_rounds = 0
                else:
                    stall_rounds = 0
                last_tile_count = current

            count = min(tiles.count(), target_count)
            if count < target_count:
                logger.warning(
                    f"[analytics] Account {account}: only {count} of {target_count} posts "
                    f"loaded after scrolling — the grid may have genuinely stopped, or a slow "
                    f"connection needs LOAD_SCROLL_WAIT_MS raised further in .env."
                )
            debug_lines = []
            for i in range(count):
                # Yield to a waiting posting job rather than making it sit
                # behind the ENTIRE analytics run (which can take minutes
                # for a large account) — check every few posts, and stop
                # early with partial results the moment one shows up. The
                # lock releases normally when this `with` block exits, so
                # posting can start within a few seconds, not minutes.
                if i > 0 and i % 5 == 0 and db.has_pending_publish_job(account):
                    logger.info(
                        f"[analytics] Account {account}: a post is queued to publish — "
                        f"stopping analytics early after {i}/{count} posts to yield the account."
                    )
                    if status_cb:
                        status_cb(
                            f"A queued post needs this account — stopping here with "
                            f"{i}/{count} posts checked, so posting can go first."
                        )
                    break

                if status_cb and (i % 5 == 0 or i == count - 1):
                    status_cb(f"Checking post {i + 1}/{count}...")

                tile = tiles.nth(i)
                try:
                    post_url = tile.get_attribute("href")
                except Exception:
                    post_url = None

                # FAST PATH: on the Reels tab specifically, the view-count
                # overlay (👁 icon + number, e.g. "5,164", "74.3K") is
                # directly readable as the tile's own text — confirmed via
                # a real screenshot. Try this first; it's a grid-load
                # instead of a full navigation per post, dramatically
                # faster than the fallback below.
                views = None
                try:
                    raw_text = tile.inner_text(timeout=2500)
                    numbers = re.findall(r"[\d.,]+[KM]?", raw_text or "")
                    parsed = [_parse_count(n) for n in numbers]
                    parsed = [n for n in parsed if n is not None]
                    if parsed:
                        views = parsed[0]
                        debug_lines.append(f"Tile {i+1}: url={post_url} grid_text={raw_text!r} -> {views} (fast path)")
                except Exception:
                    pass

                # SLOW FALLBACK: only for tiles the fast path above
                # couldn't read — click in and read the detail view's own
                # "X views"/"X plays"/"Play count: X" text (whichever
                # wording Instagram uses there), then close back to the
                # grid. One navigation per post instead of one grid load
                # for all, so only worth doing for the tiles that actually
                # need it.
                if views is None:
                    try:
                        tile.scroll_into_view_if_needed(timeout=5000)
                        tile.click(timeout=8000)
                        page.wait_for_timeout(1200)
                        detail_text = page.locator("body").inner_text(timeout=4000)
                        m = (
                            re.search(r"play\s*count\D{0,5}([\d.,]+[KM]?)", detail_text, re.I)
                            or re.search(r"([\d.,]+[KM]?)\s*(?:views|plays)\b", detail_text, re.I)
                        )
                        if m:
                            views = _parse_count(m.group(1))
                        debug_lines.append(
                            f"Tile {i+1}: url={post_url} detail_match={m.group(0) if m else None} (slow fallback)"
                        )
                    except Exception as e:
                        debug_lines.append(f"Tile {i+1}: url={post_url} error={e}")
                    finally:
                        # Close back to the grid — try a close (X) button
                        # first, fall back to Escape. Escape is safe
                        # specifically here (unlike in the posting flow):
                        # this is a read-only view/lightbox, not a compose
                        # flow, so there's no "Discard post?"-style risk.
                        try:
                            close_btn = page.locator("svg[aria-label='Close']").first
                            close_btn.locator(
                                "xpath=ancestor::*[self::button or @role='button'][1]"
                            ).click(timeout=2000)
                        except Exception:
                            try:
                                page.keyboard.press("Escape")
                            except Exception:
                                pass
                        page.wait_for_timeout(600)

                results.append({
                    "post_url": post_url,
                    "caption_snippet": None,
                    "views": views,
                    "likes": None,
                    "comments": None,
                })

            # Always take this screenshot (not gated by DEBUG_SCREENSHOTS) —
            # it's needed below as the input for the AI vision fallback, not
            # just for debugging.
            grid_shot = _save_screenshot(page, account, "analytics_grid_scraped")
            if DEBUG_SCREENSHOTS and grid_shot and screenshot_cb:
                screenshot_cb(grid_shot, f"Account {account} — profile grid scraped")
                # Dump exactly what each opened post's detail view actually
                # contained — this is the key diagnostic for why view-count
                # reading succeeds or fails, without guessing.
                try:
                    debug_path = os.path.join(
                        SCREENSHOT_DIR, f"account{account}_tile_raw_text_{int(time.time())}.txt"
                    )
                    with open(debug_path, "w", encoding="utf-8") as f:
                        f.write("\n".join(debug_lines))
                    if document_cb:
                        document_cb(debug_path, f"Account {account} — raw tile text (for debugging view-count parsing)")
                except Exception as e:
                    logger.warning(f"[analytics] Could not save tile raw-text debug dump: {e}")

            # Fallback: if text-scraping mostly came back empty (Instagram's
            # overlay apparently isn't readable as accessible text on this
            # account/session — the exact case reported), ask a vision model
            # to just read the numbers off the screenshots directly instead —
            # scrolling through in sections now that "all posts" can mean far
            # more than fits in one screenshot.
            missing = sum(1 for r in results if r.get("views") is None)
            if results and missing > len(results) / 2:
                ai_views = read_all_view_counts_via_ai(page, account, len(results), screenshot_cb=screenshot_cb)
                if ai_views:
                    for i, v in enumerate(ai_views):
                        if i < len(results) and results[i].get("views") is None and v is not None:
                            results[i]["views"] = v
                    logger.info(
                        f"[account {account}] AI vision fallback filled in "
                        f"{sum(1 for v in ai_views if v is not None)} view counts."
                    )

        # Flag likely-viral posts by comparing each against the account's own
        # average — computed here in code, not left for the AI to eyeball, so
        # it's consistent no matter which model ends up summarizing it.
        view_values = [r["views"] for r in results if r.get("views") is not None]
        if view_values:
            avg_views = sum(view_values) / len(view_values)
            for r in results:
                r["is_likely_viral"] = (
                    r.get("views") is not None and avg_views > 0 and r["views"] >= avg_views * 1.5
                )
        else:
            avg_views = None
            for r in results:
                r["is_likely_viral"] = False

        return profile_stats, results


def summarize_with_ai(account, profile_stats, entries):
    """Sends the scraped numbers to an LLM via OpenRouter and asks for a
    short, plain-language summary of what's working. Returns None (not an
    error) if OPENROUTER_API_KEY isn't configured — callers should fall
    back to showing the raw numbers only in that case."""
    if not OPENROUTER_API_KEY:
        return None
    if not entries:
        return None

    lines = []
    for i, e in enumerate(entries, 1):
        parts = [f"Post {i}:"]
        if e.get("views") is not None:
            parts.append(f"views={e['views']}")
        if e.get("likes") is not None:
            parts.append(f"likes={e['likes']}")
        if e.get("comments") is not None:
            parts.append(f"comments={e['comments']}")
        if e.get("caption_snippet"):
            parts.append(f"caption=\"{e['caption_snippet'][:80]}\"")
        if e.get("is_likely_viral"):
            parts.append("[FLAGGED AS LIKELY VIRAL — well above this account's average]")
        lines.append(" ".join(parts))
    data_block = "\n".join(lines)

    profile_line = "Profile: "
    if profile_stats:
        pieces = []
        if profile_stats.get("username"):
            pieces.append(f"@{profile_stats['username']}")
        if profile_stats.get("followers") is not None:
            pieces.append(f"{profile_stats['followers']:,} followers")
        if profile_stats.get("posts") is not None:
            pieces.append(f"{profile_stats['posts']:,} total posts")
        profile_line += ", ".join(pieces) if pieces else "(not readable)"
    else:
        profile_line += "(not readable)"

    prompt = (
        f"{profile_line}\n\n"
        f"Engagement numbers for the {len(entries)} most recent Instagram reels from this "
        f"account:\n\n{data_block}\n\n"
        f"Some posts are pre-flagged as 'likely viral' (well above this account's own "
        f"average) — call those out specifically and, if a caption is available for them, "
        f"note anything in common. In 3-5 short bullet points, give a plain-language read on "
        f"what's working and one or two concrete suggestions. Be concise — this is going "
        f"straight into a Telegram message, not a report."
    )

    try:
        resp = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={"Authorization": f"Bearer {OPENROUTER_API_KEY}"},
            json={
                "model": OPENROUTER_MODEL,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.warning(f"OpenRouter summarization failed: {e}")
        return None
