# login.py — one-time manual session creator, run this yourself per account.
import os
import time
import getpass
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
from config import SESSION_DIR, ACCOUNT_COUNT, LOG_DIR
from logger import logger
from account_locks import account_lock

SCREENSHOT_DIR = os.path.join(LOG_DIR, "screenshots")
os.makedirs(SCREENSHOT_DIR, exist_ok=True)


def dismiss_popup_if_present(page, text, timeout=4000):
    try:
        btn = page.locator(f"button:has-text('{text}')")
        btn.wait_for(state="visible", timeout=timeout)
        btn.click()
        return True
    except PWTimeout:
        return False


def create_session():
    print("\n==============================================")
    print("INSTAGRAM MANUAL LOGIN SESSION GENERATOR")
    print("==============================================")
    for i in range(1, ACCOUNT_COUNT + 1):
        print(f"{i}. Account {i}")

    try:
        choice = int(input(f"\nWhich account slot are you setting up? (1-{ACCOUNT_COUNT}): "))
        if choice not in range(1, ACCOUNT_COUNT + 1):
            print("Invalid selection.")
            return
    except ValueError:
        print("Please enter a number.")
        return

    user_data_dir = os.path.join(SESSION_DIR, f"account_{choice}")
    # Session data contains live Instagram cookies — restrict to owner-only.
    os.makedirs(user_data_dir, exist_ok=True)
    try:
        os.chmod(user_data_dir, 0o700)
    except OSError:
        pass

    # Coordinate with a possibly-running bot service via the same
    # cross-process lock poster.py/health_checker.py use. If the bot is
    # currently publishing (or health-checking) this exact account, opening
    # the same Chromium profile here at the same time would corrupt it.
    with account_lock(choice, blocking=False) as acquired:
        if not acquired:
            print(
                f"\n⚠️ Account {choice} is currently in use by the running bot service "
                f"(publishing or a health check in progress)."
            )
            print("   Waiting for it to finish... (Ctrl+C to abort, or stop the service with "
                  "'sudo systemctl stop buzznity-bot' if you don't want to wait)")

    print(f"\nOpening browser for Account {choice}...")

    with account_lock(choice, blocking=True):
        _run_login_browser(choice, user_data_dir)


def _run_login_browser(choice, user_data_dir):
    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            headless=False,
            viewport={"width": 1280, "height": 720},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            ),
        )
        page = context.new_page()

        try:
            page.goto("https://www.instagram.com/", timeout=30000)
            page.wait_for_selector("input[name='username']", timeout=15000)
        except PWTimeout:
            print("Login form never appeared. Check your network/VPS egress and try again.")
            context.close()
            return

        username = input("Instagram username: ").strip()
        password = getpass.getpass("Instagram password (hidden): ").strip()

        page.locator("input[name='username']").fill(username)
        page.locator("input[name='password']").fill(password)
        page.locator("button[type='submit']").click()
        print("Login submitted, waiting for response...")

        # Wait for ANY of the known outcomes instead of relying on
        # networkidle, which is unreliable on a dynamic site like Instagram
        # (background connections keep it from ever going "idle"). We poll
        # for a set of possible next-screens instead.
        outcome = None
        deadline = time.time() + 20
        while time.time() < deadline and outcome is None:
            if page.locator("input[name='verificationCode']").is_visible():
                outcome = "otp_code"
            elif page.locator("text=Choose a way to confirm").is_visible():
                outcome = "otp_choice"
            elif page.locator("svg[aria-label='New post'], svg[aria-label='Direct']").first.is_visible():
                outcome = "logged_in"
            elif page.locator("text=incorrect").is_visible() or page.locator("text=Incorrect").is_visible():
                outcome = "wrong_password"
            else:
                page.wait_for_timeout(500)

        # Instagram has many possible verification flows (SMS code, email
        # code, authenticator app, "choose a way to confirm" screen, push
        # approval from another logged-in device, etc). Rather than trying
        # to hard-code every selector variant Instagram might show — which
        # will inevitably drift — fall back to letting you complete
        # whatever's on screen manually, since this script only needs to
        # run once per account anyway.
        if outcome in ("otp_code", "otp_choice") or outcome is None:
            print("\n⚠️ Instagram is asking for additional verification (2FA/OTP/checkpoint),")
            print("   or the next screen wasn't automatically recognized.")
            if outcome == "otp_code":
                otp = input("Enter the verification code shown/received: ").strip()
                page.locator("input[name='verificationCode']").fill(otp)
                confirm_btn = page.locator("button:has-text('Confirm')")
                if confirm_btn.is_visible():
                    confirm_btn.click()
            else:
                print("   Please complete it manually in the browser window that opened.")
            input("   Press Enter here once you've finished in the browser (or if it auto-completed)...")

        # Dismiss common post-login popups
        dismiss_popup_if_present(page, "Save Info")
        dismiss_popup_if_present(page, "Not Now")

        # Validate login succeeded
        try:
            page.wait_for_selector(
                "svg[aria-label='New post'], svg[aria-label='Direct']", timeout=15000
            )
            print(f"\n✅ Account {choice} session saved successfully to:\n   {user_data_dir}")
            logger.info(f"Session created OK for account {choice}")
        except PWTimeout:
            try:
                shot_path = os.path.join(SCREENSHOT_DIR, f"login_account{choice}_failed_{int(time.time())}.png")
                page.screenshot(path=shot_path)
                print(f"   (Saved a debug screenshot to {shot_path})")
            except Exception:
                pass
            print("\n❌ Login did not complete. Wrong password, wrong OTP, or Instagram "
                  "showed a challenge/captcha that needs manual handling in this window.")
            logger.warning(f"Session creation FAILED for account {choice}")

        input("\nPress Enter to close the browser window...")
        context.close()


if __name__ == "__main__":
    create_session()

