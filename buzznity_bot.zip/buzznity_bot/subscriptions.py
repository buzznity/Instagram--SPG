"""
subscriptions.py — Phase 1 of the multi-tenant subscription system.

Scope of this phase: database schema, plan definitions, customer
registration, manual payment submission (screenshot/reference sent to the
admin for approval — NOT an automated payment gateway; see the note in
the module docstring of bot.py's admin section for why), and the core
admin approve/reject flow.

NOT yet in this phase (intentionally — this is a big enough change to
build and test in stages rather than all at once):
  - Enforcing account_limit against the EXISTING /addaccount and posting
    flows (those still use the single-owner ACCOUNT_COUNT model for now).
  - The full admin panel (Revenue, Expiring Soon, Suspended Users,
    Statistics, Plans management UI) — only user/payment approve/reject
    and a basic list are here.
  - Recurring/automatic renewal reminders or expiry enforcement.
Each of those is a meaningful next phase once this foundation is tested.
"""
import time
import sqlite3
from contextlib import contextmanager
from database import get_conn
import billing_api
from config import PAYMENT_REQUEST_EXPIRY_MINUTES
from logger import logger

# Hardcoded for now, per your message. Move to a `plans` DB table in a
# later phase if these need to change without a code deploy.
# NOTE: this hardcoded dict is now only the SEED data used the first time
# init_subscription_tables() runs (see the `plans` table below) — for
# actually reading plans anywhere in the app, always call get_plans(),
# never reference this dict directly, so Plan Management edits (price,
# account_limit, duration) take effect immediately everywhere.
_SEED_PLANS = {
    "basic": {"name": "Basic", "price_usd": 29, "account_limit": 2, "duration_days": 30},
    "pro": {"name": "Pro", "price_usd": 59, "account_limit": 6, "duration_days": 30},
}


def init_subscription_tables():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS customers (
                chat_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                contact TEXT,
                created_at REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'unregistered'
                -- unregistered / onboarding / pending_payment / active / expired / suspended
            )
        """)
        # Migration: onboarding fields — the name/purpose the customer
        # actually TYPES during Activate My Account, distinct from
        # `full_name` (which is just whatever Telegram reports).
        for col, coltype in (("onboarded_name", "TEXT"), ("purpose", "TEXT")):
            try:
                conn.execute(f"ALTER TABLE customers ADD COLUMN {col} {coltype}")
            except sqlite3.OperationalError:
                pass
        conn.execute("""
            CREATE TABLE IF NOT EXISTS subscriptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                plan_key TEXT NOT NULL,
                account_limit INTEGER NOT NULL,
                started_at REAL,
                expires_at REAL,
                status TEXT NOT NULL DEFAULT 'pending'
                -- pending / active / expired / suspended / cancelled
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                plan_key TEXT NOT NULL,
                amount_usd REAL NOT NULL,
                proof_file_id TEXT,
                proof_note TEXT,
                submitted_at REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                -- pending / verified / rejected
                reviewed_by INTEGER,
                reviewed_at REAL,
                reject_reason TEXT
            )
        """)
        # Migration: automatic-payment fields (Buzznity Billing API) —
        # provider distinguishes 'manual' (screenshot review, the
        # original Phase 1 flow) from 'auto' (billing_api.py). request_id
        # UNIQUE prevents ever double-processing the same billing-API
        # payment if a status check somehow runs twice concurrently.
        for col, coltype in (
            ("provider", "TEXT NOT NULL DEFAULT 'manual'"),
            ("request_id", "TEXT"),
            ("transaction_id", "TEXT"),
            ("payment_link", "TEXT"),
        ):
            try:
                conn.execute(f"ALTER TABLE payments ADD COLUMN {col} {coltype}")
            except sqlite3.OperationalError:
                pass
        try:
            conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_request_id "
                "ON payments(request_id) WHERE request_id IS NOT NULL"
            )
        except sqlite3.OperationalError:
            pass
        conn.execute("""
            CREATE TABLE IF NOT EXISTS instagram_accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                label TEXT,
                instagram_username TEXT,
                created_at REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending_login'
                -- pending_login / active / expired_session / removed
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS plans (
                plan_key TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                price_usd REAL NOT NULL,
                account_limit INTEGER NOT NULL,
                duration_days INTEGER NOT NULL,
                active INTEGER NOT NULL DEFAULT 1
            )
        """)
        # Seed once — INSERT OR IGNORE so re-running this on an existing
        # DB never overwrites plans an admin has since edited.
        for key, p in _SEED_PLANS.items():
            conn.execute(
                "INSERT OR IGNORE INTO plans (plan_key, name, price_usd, account_limit, "
                "duration_days, active) VALUES (?, ?, ?, ?, ?, 1)",
                (key, p["name"], p["price_usd"], p["account_limit"], p["duration_days"]),
            )
        conn.execute("""
            CREATE TABLE IF NOT EXISTS support_messages (
                forwarded_message_id INTEGER PRIMARY KEY,
                admin_chat_id INTEGER NOT NULL,
                customer_chat_id INTEGER NOT NULL,
                created_at REAL NOT NULL
            )
        """)


# ---------------- live support (admin reply-to-relay) ----------------

def record_support_forward(forwarded_message_id, admin_chat_id, customer_chat_id):
    with get_conn() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO support_messages (forwarded_message_id, admin_chat_id, "
            "customer_chat_id, created_at) VALUES (?, ?, ?, ?)",
            (forwarded_message_id, admin_chat_id, customer_chat_id, time.time()),
        )


def get_support_customer(forwarded_message_id):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT customer_chat_id FROM support_messages WHERE forwarded_message_id=?",
            (forwarded_message_id,),
        ).fetchone()
        return row["customer_chat_id"] if row else None


# ---------------- plans (Plan Management) ----------------

def get_plans(include_inactive=False):
    """Returns {plan_key: {name, price_usd, account_limit, duration_days}}
    — same shape the old hardcoded PLANS dict had, so every existing call
    site (subscriptions.get_plans()[key], .get(key), .items()) keeps working
    once updated to call this instead. Always reads fresh from the DB —
    no caching — so a Plan Management edit takes effect immediately
    everywhere, including for a payment flow already in progress."""
    with get_conn() as conn:
        if include_inactive:
            rows = conn.execute("SELECT * FROM plans ORDER BY price_usd").fetchall()
        else:
            rows = conn.execute("SELECT * FROM plans WHERE active=1 ORDER BY price_usd").fetchall()
        return {
            r["plan_key"]: {
                "name": r["name"], "price_usd": r["price_usd"],
                "account_limit": r["account_limit"], "duration_days": r["duration_days"],
            }
            for r in rows
        }


def update_plan(plan_key, **fields):
    """fields: any of name/price_usd/account_limit/duration_days/active.
    Does NOT retroactively change any customer's ALREADY-active
    subscription (those keep whatever account_limit/duration they were
    granted at the time) — only affects NEW subscriptions/renewals going
    forward, which is the expected behavior for a price/limit change."""
    if not fields:
        return
    cols = ", ".join(f"{k}=?" for k in fields)
    with get_conn() as conn:
        conn.execute(f"UPDATE plans SET {cols} WHERE plan_key=?", (*fields.values(), plan_key))


def create_plan(plan_key, name, price_usd, account_limit, duration_days):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO plans (plan_key, name, price_usd, account_limit, duration_days, active) "
            "VALUES (?, ?, ?, ?, ?, 1)",
            (plan_key, name, price_usd, account_limit, duration_days),
        )


# ---------------- instagram_accounts (per-customer ownership) ----------------
# The "account number" used everywhere ELSE in this codebase (session file
# names, poster.py/analytics.py/scheduler.py's `account: int` parameter,
# jobs.account, account_locks, etc.) stays a PLAIN INTEGER — none of those
# files needed to change. What changes is WHERE that integer comes from:
# instead of a small 1..ACCOUNT_COUNT range picked from a fixed button
# list, a customer's account gets an id from this table, offset so it can
# never collide with the operator's own existing 1..ACCOUNT_COUNT
# accounts. Ownership is enforced by checking this table BEFORE any
# customer-facing action touches a given account number — never by
# trusting whatever number a button's callback_data claims.
ACCOUNT_ID_OFFSET = 1000


def _raw_id(account_number):
    return account_number - ACCOUNT_ID_OFFSET


def create_instagram_account(chat_id, label=None):
    """Returns the new account NUMBER (already offset) — pass this
    directly to session_store/poster/scheduler/analytics exactly like any
    other account number."""
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO instagram_accounts (chat_id, label, created_at, status) "
            "VALUES (?, ?, ?, 'pending_login')",
            (chat_id, label, time.time()),
        )
        row_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
    return row_id + ACCOUNT_ID_OFFSET


def get_owned_accounts(chat_id):
    """Returns full rows (with 'account_number' added) for everything this
    customer owns, regardless of status."""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM instagram_accounts WHERE chat_id=? AND status!='removed' ORDER BY id",
            (chat_id,),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["account_number"] = d["id"] + ACCOUNT_ID_OFFSET
            out.append(d)
        return out


def is_account_owned_by(account_number, chat_id):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT 1 FROM instagram_accounts WHERE id=? AND chat_id=? AND status!='removed'",
            (_raw_id(account_number), chat_id),
        ).fetchone()
        return row is not None


def count_owned_accounts(chat_id):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS c FROM instagram_accounts WHERE chat_id=? AND status!='removed'",
            (chat_id,),
        ).fetchone()
        return row["c"]


def get_all_owned_account_numbers():
    """Every customer-owned account number, across ALL customers — used
    by health_checker.py to extend its periodic check loop beyond the
    operator's own 1..ACCOUNT_COUNT range."""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id FROM instagram_accounts WHERE status!='removed'"
        ).fetchall()
        return [r["id"] + ACCOUNT_ID_OFFSET for r in rows]


def set_instagram_account_status(account_number, status, username=None):
    with get_conn() as conn:
        if username is not None:
            conn.execute(
                "UPDATE instagram_accounts SET status=?, instagram_username=? WHERE id=?",
                (status, username, _raw_id(account_number)),
            )
        else:
            conn.execute(
                "UPDATE instagram_accounts SET status=? WHERE id=?",
                (status, _raw_id(account_number)),
            )


def can_add_account(chat_id):
    """Returns (allowed: bool, reason: str, current: int, limit: int|None).
    Checks BOTH that the customer has an active subscription AND that
    they're under its account_limit — the two checks a real /addaccount
    entry point must never skip."""
    sub = get_active_subscription(chat_id)
    if not sub:
        return False, "No active subscription. Use /start to pick a plan.", 0, None
    current = count_owned_accounts(chat_id)
    if current >= sub["account_limit"]:
        return (
            False,
            f"Account limit reached ({current}/{sub['account_limit']}). "
            f"Upgrade your plan to add more.",
            current,
            sub["account_limit"],
        )
    return True, "", current, sub["account_limit"]


# ---------------- customers ----------------

def get_or_create_customer(chat_id, username=None, full_name=None):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM customers WHERE chat_id=?", (chat_id,)).fetchone()
        if row:
            return dict(row)
        conn.execute(
            "INSERT INTO customers (chat_id, username, full_name, created_at, status) "
            "VALUES (?, ?, ?, ?, 'unregistered')",
            (chat_id, username, full_name, time.time()),
        )
        row = conn.execute("SELECT * FROM customers WHERE chat_id=?", (chat_id,)).fetchone()
        return dict(row)


def set_customer_status(chat_id, status):
    with get_conn() as conn:
        conn.execute("UPDATE customers SET status=? WHERE chat_id=?", (status, chat_id))


def save_onboarding_info(chat_id, name, purpose):
    with get_conn() as conn:
        conn.execute(
            "UPDATE customers SET onboarded_name=?, purpose=? WHERE chat_id=?",
            (name, purpose, chat_id),
        )


def get_customer(chat_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM customers WHERE chat_id=?", (chat_id,)).fetchone()
        return dict(row) if row else None


def list_customers(status=None):
    with get_conn() as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM customers WHERE status=? ORDER BY created_at DESC", (status,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM customers ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]


# ---------------- payments (manual submission + admin review) ----------------

def submit_payment(chat_id, plan_key, proof_file_id=None, proof_note=None):
    plan = get_plans(include_inactive=True)[plan_key]
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO payments (chat_id, plan_key, amount_usd, proof_file_id, proof_note, "
            "submitted_at, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')",
            (chat_id, plan_key, plan["price_usd"], proof_file_id, proof_note, time.time()),
        )
        payment_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
    set_customer_status(chat_id, "pending_payment")
    return payment_id


def get_payment(payment_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM payments WHERE id=?", (payment_id,)).fetchone()
        return dict(row) if row else None


def list_payments_for_customer(chat_id, limit=10):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM payments WHERE chat_id=? ORDER BY submitted_at DESC LIMIT ?",
            (chat_id, limit),
        ).fetchall()
        return [dict(r) for r in rows]


def list_pending_payments():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM payments WHERE status='pending' ORDER BY submitted_at ASC"
        ).fetchall()
        return [dict(r) for r in rows]


def _activate_subscription_for_payment(payment_id, reviewed_by):
    """Canonical activation logic — the ONE place a payment (however it
    was verified: manual admin review, or the automatic billing API)
    turns into an active/extended subscription. Both approve_payment()
    and check_and_activate_auto_payment() call this rather than
    duplicating the logic, so there's never a risk of the two paths
    drifting apart. Returns the new subscription row, or None if the
    payment wasn't actually pending (already handled)."""
    now = time.time()
    with get_conn() as conn:
        # Atomic claim: the UPDATE's WHERE clause re-checks status='pending'
        # at the moment of the write itself (SQLite serializes writes at
        # the file level), not just at an earlier read — closes a real
        # race where the customer's manual "Check Payment" tap and the
        # background poller (payment_poller.py) could otherwise both see
        # 'pending' in a separate read and both activate a subscription
        # for the same payment. rowcount tells us definitively whether
        # THIS call won the race.
        cur = conn.execute(
            "UPDATE payments SET status='verified', reviewed_by=?, reviewed_at=? "
            "WHERE id=? AND status='pending'",
            (reviewed_by, now, payment_id),
        )
        if cur.rowcount == 0:
            return None  # already handled (by this same race, or genuinely not pending)

        payment = dict(conn.execute("SELECT * FROM payments WHERE id=?", (payment_id,)).fetchone())
        plan = get_plans(include_inactive=True)[payment["plan_key"]]

        # Extend from the CURRENT active subscription's expiry if there is
        # one and it hasn't lapsed yet, rather than always from "now" — a
        # renewal paid a few days early shouldn't shorten what they
        # already have.
        current = conn.execute(
            "SELECT * FROM subscriptions WHERE chat_id=? AND status='active' "
            "ORDER BY expires_at DESC LIMIT 1",
            (payment["chat_id"],),
        ).fetchone()
        start_from = now
        if current and current["expires_at"] and current["expires_at"] > now:
            start_from = current["expires_at"]
            conn.execute("UPDATE subscriptions SET status='expired' WHERE id=?", (current["id"],))

        expires_at = start_from + plan["duration_days"] * 86400
        conn.execute(
            "INSERT INTO subscriptions (chat_id, plan_key, account_limit, started_at, "
            "expires_at, status) VALUES (?, ?, ?, ?, ?, 'active')",
            (payment["chat_id"], payment["plan_key"], plan["account_limit"], now, expires_at),
        )
    set_customer_status(payment["chat_id"], "active")
    return get_active_subscription(payment["chat_id"])


def approve_payment(payment_id, reviewed_by):
    """Manual-review path — pass an admin's chat_id as reviewed_by."""
    return _activate_subscription_for_payment(payment_id, reviewed_by)


# Sentinel used as reviewed_by for auto-verified payments, so it's always
# visually obvious in the payments table which path activated a given row
# without needing a real admin chat_id.
AUTO_REVIEWER_SENTINEL = -1


def submit_auto_payment_request(chat_id, plan_key):
    """Starts the automatic-payment path via the Buzznity Billing API.
    Returns the local payment row (including request_id/payment_link/
    transaction_id, plus a non-persisted 'qr_code_url' key) on success.
    Raises billing_api.BillingAPIError on any failure — callers should
    catch this and offer the manual proof-submission flow as a fallback
    rather than leaving the customer stuck."""
    plan = get_plans(include_inactive=True)[plan_key]
    now = time.time()

    # Insert a placeholder row FIRST so its own id can be passed to the
    # billing API as `reference` (per the operator's PHP reference
    # implementation) — a simple, stable tracking link between "our"
    # payment record and "their" request, independent of requestId.
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO payments (chat_id, plan_key, amount_usd, submitted_at, status, provider) "
            "VALUES (?, ?, ?, ?, 'pending', 'auto')",
            (chat_id, plan_key, plan["price_usd"], now),
        )
        payment_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    try:
        data = billing_api.create_payment_request(
            plan["price_usd"],
            note=f"Buzznity {plan['name']} - chat {chat_id}",
            reference=payment_id,
        )
    except billing_api.BillingAPIError:
        with get_conn() as conn:
            conn.execute("DELETE FROM payments WHERE id=?", (payment_id,))
        raise

    with get_conn() as conn:
        conn.execute(
            "UPDATE payments SET request_id=?, transaction_id=?, payment_link=? WHERE id=?",
            (data.get("requestId"), data.get("transactionId"), data.get("paymentLink"), payment_id),
        )
    set_customer_status(chat_id, "pending_payment")
    payment = get_payment(payment_id)
    payment["qr_code_url"] = data.get("qrCodeUrl")  # not persisted — a data: URI, decoded once and discarded
    return payment


def check_and_activate_auto_payment(payment_id):
    """Polls the billing API for this payment's current status. Returns
    one of: ('paid', subscription_row), ('pending', None), ('failed',
    None), ('expired', None). Raises billing_api.BillingAPIError if the
    status check itself fails (network etc — distinct from the payment
    simply not being paid yet)."""
    payment = get_payment(payment_id)
    if not payment or payment["status"] != "pending" or not payment.get("request_id"):
        return "pending", None

    # Confirmed by the operator: the request/QR is only valid for
    # PAYMENT_REQUEST_EXPIRY_MINUTES. Past that, don't bother calling the
    # API — it's known stale — mark it failed locally and tell the
    # caller to prompt for a fresh request instead.
    age_minutes = (time.time() - payment["submitted_at"]) / 60.0
    if age_minutes > PAYMENT_REQUEST_EXPIRY_MINUTES:
        with get_conn() as conn:
            cur = conn.execute(
                "UPDATE payments SET status='rejected', reject_reason='request expired (10 min)' "
                "WHERE id=? AND status='pending'",
                (payment_id,),
            )
            claimed = cur.rowcount > 0
        if claimed:
            set_customer_status(payment["chat_id"], "unregistered")
        return "expired", None

    status_response = billing_api.check_payment_status(payment["request_id"])
    if billing_api.is_payment_successful(status_response):
        sub = _activate_subscription_for_payment(payment_id, AUTO_REVIEWER_SENTINEL)
        return "paid", sub
    if billing_api.is_payment_failed(status_response):
        return "failed", None
    return "pending", None


def reject_payment(payment_id, reviewed_by, reason=None):
    with get_conn() as conn:
        # Same atomic-claim pattern as _activate_subscription_for_payment
        # — the WHERE clause re-checks 'pending' at write time, closing
        # the same race (e.g. an admin rejecting the instant the billing
        # API confirms it, or two admins clicking Reject at once).
        cur = conn.execute(
            "UPDATE payments SET status='rejected', reviewed_by=?, reviewed_at=?, "
            "reject_reason=? WHERE id=? AND status='pending'",
            (reviewed_by, time.time(), reason, payment_id),
        )
        if cur.rowcount == 0:
            return False
        payment = dict(conn.execute("SELECT * FROM payments WHERE id=?", (payment_id,)).fetchone())
    set_customer_status(payment["chat_id"], "unregistered")
    return True


# ---------------- subscriptions ----------------

def get_active_subscription(chat_id):
    """Returns the current subscription row if status='active' AND not
    past its expiry, else None — callers should treat None as "no active
    plan" regardless of which specific reason applies."""
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM subscriptions WHERE chat_id=? AND status='active' "
            "ORDER BY expires_at DESC LIMIT 1",
            (chat_id,),
        ).fetchone()
        if not row:
            return None
        row = dict(row)
        if row["expires_at"] and row["expires_at"] < time.time():
            return None  # lapsed — a background sweep should catch this and flip status; see mark_expired_subscriptions
        return row


def mark_expired_subscriptions():
    """Flips any 'active' subscription past its expires_at to 'expired',
    and the corresponding customer to 'expired' too (only if they don't
    have ANOTHER still-active subscription row, e.g. a fresh renewal that
    already superseded it). Intended to be called periodically (e.g. from
    health_checker's existing loop) — not wired into that loop yet in this
    phase; call manually or wire in Phase 2."""
    now = time.time()
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM subscriptions WHERE status='active' AND expires_at<?", (now,)
        ).fetchall()
        for row in rows:
            conn.execute("UPDATE subscriptions SET status='expired' WHERE id=?", (row["id"],))
            still_active = conn.execute(
                "SELECT 1 FROM subscriptions WHERE chat_id=? AND status='active' AND expires_at>=?",
                (row["chat_id"], now),
            ).fetchone()
            if not still_active:
                conn.execute(
                    "UPDATE customers SET status='expired' WHERE chat_id=?", (row["chat_id"],)
                )
        return len(rows)


def extend_subscription(chat_id, days, extended_by):
    """Admin action — extends the customer's current subscription (active
    OR expired, so a lapsed customer can be restored this way too)
    by `days`, from whichever is later: its current expiry, or now.
    Creates a fresh 'active' subscription row extending the plan/limit
    of their most recent one. Returns the new subscription row, or None
    if the customer has no subscription history at all to extend."""
    now = time.time()
    with get_conn() as conn:
        latest = conn.execute(
            "SELECT * FROM subscriptions WHERE chat_id=? ORDER BY id DESC LIMIT 1",
            (chat_id,),
        ).fetchone()
        if not latest:
            return None
        latest = dict(latest)
        if latest["status"] == "active" and latest["expires_at"] and latest["expires_at"] > now:
            conn.execute("UPDATE subscriptions SET status='expired' WHERE id=?", (latest["id"],))
            start_from = latest["expires_at"]
        else:
            start_from = now
        expires_at = start_from + days * 86400
        conn.execute(
            "INSERT INTO subscriptions (chat_id, plan_key, account_limit, started_at, "
            "expires_at, status) VALUES (?, ?, ?, ?, ?, 'active')",
            (chat_id, latest["plan_key"], latest["account_limit"], now, expires_at),
        )
    set_customer_status(chat_id, "active")
    logger.info(f"[subscriptions] Admin {extended_by} extended chat_id {chat_id} by {days} days.")
    return get_active_subscription(chat_id)


def grant_subscription(chat_id, plan_key, days, granted_by):
    """Admin action — activates a subscription for a customer with NO
    payment record at all (comp/manual grant, e.g. for a customer who
    paid outside the normal flow). Uses the plan's own account_limit as
    the starting point; use change_account_limit() afterward for a
    custom limit. Returns the new subscription row."""
    plan = get_plans(include_inactive=True)[plan_key]
    now = time.time()
    with get_conn() as conn:
        current = conn.execute(
            "SELECT * FROM subscriptions WHERE chat_id=? AND status='active' "
            "ORDER BY expires_at DESC LIMIT 1",
            (chat_id,),
        ).fetchone()
        start_from = now
        if current and current["expires_at"] and current["expires_at"] > now:
            start_from = current["expires_at"]
            conn.execute("UPDATE subscriptions SET status='expired' WHERE id=?", (current["id"],))
        expires_at = start_from + days * 86400
        conn.execute(
            "INSERT INTO subscriptions (chat_id, plan_key, account_limit, started_at, "
            "expires_at, status) VALUES (?, ?, ?, ?, ?, 'active')",
            (chat_id, plan_key, plan["account_limit"], now, expires_at),
        )
    set_customer_status(chat_id, "active")
    logger.info(f"[subscriptions] Admin {granted_by} granted chat_id {chat_id} {plan_key} for {days} days (no payment).")
    return get_active_subscription(chat_id)


def change_account_limit(chat_id, new_limit, changed_by):
    """Admin action — directly overrides the account_limit on the
    customer's CURRENT active subscription (doesn't touch plan_key or
    expiry). Returns the updated subscription row, or None if they have
    no active subscription to modify."""
    sub = get_active_subscription(chat_id)
    if not sub:
        return None
    with get_conn() as conn:
        conn.execute("UPDATE subscriptions SET account_limit=? WHERE id=?", (new_limit, sub["id"]))
    logger.info(f"[subscriptions] Admin {changed_by} changed chat_id {chat_id}'s account_limit to {new_limit}.")
    return get_active_subscription(chat_id)


def list_pending_auto_payments():
    """Every still-pending UPI/automatic payment — used by
    payment_poller.py's background loop to activate a subscription the
    moment a payment clears, without the customer needing to tap
    'Check Payment' themselves."""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM payments WHERE status='pending' AND provider='auto' "
            "AND request_id IS NOT NULL"
        ).fetchall()
        return [dict(r) for r in rows]


def suspend_customer(chat_id):
    with get_conn() as conn:
        conn.execute("UPDATE subscriptions SET status='suspended' WHERE chat_id=? AND status='active'", (chat_id,))
    set_customer_status(chat_id, "suspended")


def reactivate_customer(chat_id):
    """Un-suspends — restores the most recent suspended subscription to
    active IF it hasn't actually expired in the meantime."""
    now = time.time()
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM subscriptions WHERE chat_id=? AND status='suspended' "
            "ORDER BY expires_at DESC LIMIT 1",
            (chat_id,),
        ).fetchone()
        if not row:
            return False
        if row["expires_at"] and row["expires_at"] < now:
            return False  # actually expired — reactivating would be wrong, needs a new payment instead
        conn.execute("UPDATE subscriptions SET status='active' WHERE id=?", (row["id"],))
    set_customer_status(chat_id, "active")
    return True
