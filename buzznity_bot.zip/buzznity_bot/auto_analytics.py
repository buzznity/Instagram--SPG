"""
auto_analytics.py — background thread that periodically (every
AUTO_ANALYTICS_INTERVAL_HOURS, default 3) sends each active customer a
snapshot of their own account(s): a profile screenshot, the latest
follower/post count, a congratulations note if followers grew since the
last check, and a gentle reminder if nothing's been posted in a while.
The admin gets a compiled summary too.

Uses analytics.quick_profile_report() (fast: just the profile header
numbers + one screenshot) rather than the full scrape_recent_posts()
(slow: clicks into every single post). Running the deep scrape
automatically for every customer's every account on a fixed schedule
would be far too resource-intensive and would compete with actual
posting jobs for browser capacity (account_lock serializes them). A
customer who wants the full per-post breakdown can still run
📈 Analytics themselves any time — this is a lightweight heartbeat, not
a replacement for it.
"""
import threading
import time
from logger import logger
import subscriptions
import analytics
import database as db
from config import (
    AUTO_ANALYTICS_INTERVAL_HOURS, ALLOWED_CHAT_ID, SUPER_ADMIN_GROUP_ID,
    AUTO_ANALYTICS_POST_REMINDER_HOURS,
)


def _run_once(bot):
    customers = subscriptions.list_customers(status="active")
    admin_lines = []

    for c in customers:
        chat_id = c["chat_id"]
        owned = subscriptions.get_owned_accounts(chat_id)
        for acc in owned:
            if acc["status"] != "active":
                continue
            account_number = acc["account_number"]

            def screenshot_cb(path, msg, _chat_id=chat_id):
                try:
                    with open(path, "rb") as f:
                        bot.send_photo(_chat_id, f)
                except Exception as e:
                    logger.warning(f"[auto_analytics] Could not send snapshot photo: {e}")

            try:
                stats = analytics.quick_profile_report(account_number, screenshot_cb=screenshot_cb)
            except Exception as e:
                logger.info(
                    f"[auto_analytics] Snapshot failed for account {account_number} "
                    f"(chat_id {chat_id}): {e}"
                )
                continue

            username = stats.get("username")
            followers = stats.get("followers")
            previous_followers = subscriptions.get_and_update_follower_count(account_number, followers)

            lines = [
                f"📊 *Account Snapshot* — #{account_number}"
                + (f" (@{username})" if username else "")
            ]
            if followers is not None:
                lines.append(f"👥 {followers:,} followers")
            if stats.get("posts") is not None:
                lines.append(f"🎞️ {stats['posts']:,} total posts")

            # Congratulations note — only when we actually have a
            # PREVIOUS number to compare against (never on the very
            # first check for a freshly-added account) and it genuinely
            # grew.
            if previous_followers is not None and followers is not None and followers > previous_followers:
                gained = followers - previous_followers
                lines.append(f"\n🎉 *Congratulations!* You gained *{gained:,}* new follower(s) since the last check!")

            # Gentle posting reminder — only if it's been a genuinely
            # long time (AUTO_ANALYTICS_POST_REMINDER_HOURS), not just
            # since the last few-hour check, to avoid nagging.
            minutes_since = db.minutes_since_last_post(account_number)
            if minutes_since is None or minutes_since > AUTO_ANALYTICS_POST_REMINDER_HOURS * 60:
                lines.append(
                    f"\n📤 It's been a while since your last post — send a video or Reel "
                    f"link any time to keep your account active!"
                )

            try:
                bot.send_message(chat_id, "\n".join(lines), parse_mode="Markdown")
            except Exception as e:
                logger.warning(f"[auto_analytics] Could not send snapshot to customer {chat_id}: {e}")

            who = f"@{c['username']}" if c.get("username") else f"chat_id {chat_id}"
            follower_note = f" — {followers:,} followers" if followers is not None else ""
            growth_note = f" (+{followers - previous_followers})" if (
                previous_followers is not None and followers is not None and followers > previous_followers
            ) else ""
            admin_lines.append(
                f"{who} — #{account_number}" + (f" @{username}" if username else "") + follower_note + growth_note
            )

    if admin_lines:
        # Telegram messages have a length cap — batch into chunks rather
        # than risk one giant message failing to send once there are
        # enough customers/accounts for this to matter.
        chunk = []
        chunk_len = 0
        admin_chat_id = SUPER_ADMIN_GROUP_ID or ALLOWED_CHAT_ID
        for line in admin_lines:
            if chunk_len + len(line) > 3500:
                try:
                    bot.send_message(
                        admin_chat_id, "📊 *Periodic snapshots*\n\n" + "\n".join(chunk), parse_mode="Markdown"
                    )
                except Exception as e:
                    logger.warning(f"[auto_analytics] Could not send admin summary chunk: {e}")
                chunk, chunk_len = [], 0
            chunk.append(line)
            chunk_len += len(line)
        if chunk:
            try:
                bot.send_message(
                    admin_chat_id, "📊 *Periodic snapshots*\n\n" + "\n".join(chunk), parse_mode="Markdown"
                )
            except Exception as e:
                logger.warning(f"[auto_analytics] Could not send admin summary chunk: {e}")


def _loop(bot):
    logger.info("Auto-analytics thread started.")
    while True:
        try:
            _run_once(bot)
        except Exception:
            logger.exception("Auto-analytics loop error")
        time.sleep(AUTO_ANALYTICS_INTERVAL_HOURS * 3600)


def start_auto_analytics(bot):
    t = threading.Thread(target=_loop, args=(bot,), daemon=True)
    t.start()
