"""
auto_analytics.py — background thread that periodically (every
AUTO_ANALYTICS_INTERVAL_HOURS, default 12) sends each active customer a
quick snapshot of their own account(s), plus a compiled summary to the
admin.

Uses analytics.quick_profile_report() (fast: just the profile header
numbers — followers/posts) rather than the full scrape_recent_posts()
(slow: clicks into every single post). Running the deep scrape
automatically for every customer's every account on a fixed schedule
would be far too resource-intensive and would compete with actual
posting jobs for browser capacity (account_lock serializes them). A
customer who wants the full per-post breakdown can still run
📈 Analytics themselves any time — this is just a lightweight heartbeat,
not a replacement for it.
"""
import threading
import time
from logger import logger
import subscriptions
import analytics
from config import AUTO_ANALYTICS_INTERVAL_HOURS, ALLOWED_CHAT_ID, SUPER_ADMIN_GROUP_ID


def _run_once(bot):
    customers = subscriptions.list_customers(status="active")
    admin_lines = []

    for c in customers:
        chat_id = c["chat_id"]
        owned = subscriptions.get_owned_accounts(chat_id)
        for acc in owned:
            if acc["status"] != "active":
                continue
            account_number = acc["account_number"]
            try:
                stats = analytics.quick_profile_report(account_number)
            except Exception as e:
                logger.info(
                    f"[auto_analytics] Snapshot failed for account {account_number} "
                    f"(chat_id {chat_id}): {e}"
                )
                continue

            username = stats.get("username")
            lines = [
                f"📊 *Your Account Snapshot* — #{account_number}"
                + (f" (@{username})" if username else "")
            ]
            if stats.get("followers") is not None:
                lines.append(f"👥 {stats['followers']:,} followers")
            if stats.get("posts") is not None:
                lines.append(f"🎞️ {stats['posts']:,} total posts")
            try:
                bot.send_message(chat_id, "\n".join(lines), parse_mode="Markdown")
            except Exception as e:
                logger.warning(f"[auto_analytics] Could not send snapshot to customer {chat_id}: {e}")

            who = f"@{c['username']}" if c.get("username") else f"chat_id {chat_id}"
            follower_note = f" — {stats['followers']:,} followers" if stats.get("followers") is not None else ""
            admin_lines.append(f"{who} — #{account_number}" + (f" @{username}" if username else "") + follower_note)

    if admin_lines:
        # Telegram messages have a length cap — batch into chunks rather
        # than risk one giant message failing to send once there are
        # enough customers/accounts for this to matter.
        chunk = []
        chunk_len = 0
        admin_chat_id = SUPER_ADMIN_GROUP_ID or ALLOWED_CHAT_ID
        for line in admin_lines:
            if chunk_len + len(line) > 3500:
                try:
                    bot.send_message(admin_chat_id, "📊 *12-hour snapshots*\n\n" + "\n".join(chunk), parse_mode="Markdown")
                except Exception as e:
                    logger.warning(f"[auto_analytics] Could not send admin summary chunk: {e}")
                chunk, chunk_len = [], 0
            chunk.append(line)
            chunk_len += len(line)
        if chunk:
            try:
                bot.send_message(admin_chat_id, "📊 *12-hour snapshots*\n\n" + "\n".join(chunk), parse_mode="Markdown")
            except Exception as e:
                logger.warning(f"[auto_analytics] Could not send admin summary chunk: {e}")


def _loop(bot):
    logger.info("Auto-analytics thread started.")
    while True:
        try:
            _run_once(bot)
        except Exception:
            logger.exception("Auto-analytics loop error")
        time.sleep(AUTO_ANALYTICS_INTERVAL_HOURS * 3600)


def start_auto_analytics(bot):
    t = threading.Thread(target=_loop, args=(bot,), daemon=True)
    t.start()
