"""
video_enhance.py — optional ffmpeg-based quality pass run automatically
right after a video is received (Telegram upload or .mp4 link), before it
enters the publish pipeline. Off by default (VIDEO_ENHANCE=false) — it
adds real processing time (roughly 0.5-2x the video's own length on a
typical VPS CPU, since there's no GPU to accelerate this), which trades
against wanting posts to go out fast. Turn it on in .env if quality
matters more than speed for a given deployment.

QUALITY SAFETY: re-encoding always incurs some generation loss. By
default (VIDEO_ENHANCE_ONLY_IF_NEEDED=true), this only actually touches a
video when there's a concrete reason to — below the target resolution, or
clearly low-bitrate — and leaves an already-good source completely
untouched rather than re-encoding it "for improvement" and making it
worse. Denoising is off by default too (VIDEO_ENHANCE_DENOISE=false),
since it's the filter most likely to smooth away real detail on already-
clean footage; turn it on only if source videos are visibly noisy.

What it does, when enabled (each step toggleable individually):
  - Denoising (VIDEO_ENHANCE_DENOISE): a light spatial+temporal filter to
    clean up compression artifacts before the other passes touch it.
  - Upscales to at least VIDEO_ENHANCE_MIN_HEIGHT (default 1920, matching
    Instagram's recommended Reels resolution) if the source is smaller,
    using a high-quality (lanczos) scaling filter — never downscales.
  - A mild sharpening pass (unsharp) — subtle by design; a heavy sharpen
    looks artificial and works against Instagram's own compression pass
    afterward anyway.
  - Color/contrast lift (VIDEO_ENHANCE_COLOR): a small, tasteful
    contrast/saturation nudge, not a heavy filter-look.
  - Re-encodes video at a quality-focused CRF; audio is stream-copied
    (not re-encoded) since it doesn't need it and re-encoding audio too
    would just add time for no benefit.

On AI-based upscaling specifically (e.g. Real-ESRGAN-style super
resolution): NOT implemented here, and honestly not practical on the
infrastructure this bot runs on — that class of model needs a GPU to run
in any reasonable time; on a CPU-only VPS a single reel could take well
over an hour. OpenRouter (already used elsewhere in this bot for text/
vision) is an LLM API and doesn't offer a video-upscaling service either.
The ffmpeg pipeline above is the practical ceiling without adding GPU
infrastructure.

Best-effort: if ffmpeg isn't installed, or the enhancement pass fails for
any reason, this returns the ORIGINAL path unchanged and logs a warning —
it never blocks a post over a quality-enhancement failure.
"""
import os
import shutil
import subprocess
from logger import logger
from config import (
    VIDEO_ENHANCE, VIDEO_ENHANCE_MIN_HEIGHT, VIDEO_ENHANCE_CRF, VIDEO_ENHANCE_TIMEOUT_SECONDS,
    VIDEO_ENHANCE_DENOISE, VIDEO_ENHANCE_COLOR, VIDEO_ENHANCE_ONLY_IF_NEEDED,
)


def _ffmpeg_available():
    return shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


def _get_video_dimensions(path):
    """Returns (width, height) or (None, None) if ffprobe isn't available
    or the file can't be read."""
    if not shutil.which("ffprobe"):
        return None, None
    try:
        result = subprocess.run(
            [
                "ffprobe", "-v", "error", "-select_streams", "v:0",
                "-show_entries", "stream=width,height",
                "-of", "csv=s=x:p=0", path,
            ],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0 and "x" in result.stdout:
            w, h = result.stdout.strip().split("x")
            return int(w), int(h)
    except Exception as e:
        logger.warning(f"[video_enhance] Could not read video dimensions: {e}")
    return None, None


def _get_video_duration(path):
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0 and result.stdout.strip():
            return float(result.stdout.strip())
    except Exception as e:
        logger.warning(f"[video_enhance] Could not read video duration: {e}")
    return None


def _get_video_bitrate(path):
    """Returns bitrate in bits/sec, or None if not readable."""
    try:
        result = subprocess.run(
            [
                "ffprobe", "-v", "error", "-select_streams", "v:0",
                "-show_entries", "stream=bit_rate", "-of", "csv=p=0", path,
            ],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0 and result.stdout.strip().isdigit():
            return int(result.stdout.strip())
    except Exception as e:
        logger.warning(f"[video_enhance] Could not read video bitrate: {e}")
    return None


def enhance_video(input_path):
    """Returns the path to use going forward — either a new enhanced file
    (input_path with an "_enhanced" suffix) or input_path itself unchanged
    if enhancement is off, ffmpeg is unavailable, the source doesn't
    actually need it, or the pass failed. Never raises; always returns
    SOME usable path.

    Quality-safety guard: re-encoding ALWAYS incurs some generation loss —
    applying this pipeline to a video that's already at/above the target
    resolution and reasonably good bitrate would make it WORSE, not
    better, for no benefit. So by default (VIDEO_ENHANCE_ONLY_IF_NEEDED),
    this only actually processes the video when there's a concrete reason
    to (below the target resolution, or bitrate low enough that it's
    likely to be visibly soft/blocky) — otherwise it leaves the original
    completely untouched."""
    if not VIDEO_ENHANCE:
        return input_path
    if not _ffmpeg_available():
        logger.warning("[video_enhance] VIDEO_ENHANCE is on but ffmpeg/ffprobe isn't installed — skipping.")
        return input_path

    width, height = _get_video_dimensions(input_path)
    needs_upscale = height is not None and height < VIDEO_ENHANCE_MIN_HEIGHT
    bitrate = _get_video_bitrate(input_path)
    # A rough "this looks compressed enough to be worth touching" signal —
    # well below what a clean 1080p+ H.264 reel typically carries.
    looks_low_quality = bitrate is not None and bitrate < 2_500_000

    if VIDEO_ENHANCE_ONLY_IF_NEEDED and not needs_upscale and not looks_low_quality:
        logger.info(
            f"[video_enhance] Source already {width}x{height} at "
            f"{f'{bitrate/1000:.0f}kbps' if bitrate else 'unknown bitrate'} — good enough, "
            f"skipping to avoid a needless re-encode (VIDEO_ENHANCE_ONLY_IF_NEEDED=true)."
        )
        return input_path

    base, ext = os.path.splitext(input_path)
    output_path = f"{base}_enhanced{ext}"

    # Order matters: denoise BEFORE upscaling/sharpening (sharpening noisy
    # source footage just makes the noise itself sharper/more visible),
    # then scale up, then a mild sharpen + color pass to finish. Only
    # scale UP, never down — downscaling would just throw away quality,
    # the opposite of the point here.
    filters = []
    if VIDEO_ENHANCE_DENOISE:
        # hqdn3d: a solid general-purpose spatial+temporal denoiser —
        # deliberately gentler than a typical preset (lower luma/chroma
        # strength) since the risk here is smoothing away real detail,
        # not leaving a little noise behind.
        filters.append("hqdn3d=1.5:1:2:1.5")
    if needs_upscale:
        # -2 keeps width divisible by 2 (required by most encoders) while
        # preserving aspect ratio exactly.
        filters.append(f"scale=-2:{VIDEO_ENHANCE_MIN_HEIGHT}:flags=lanczos")
    filters.append("unsharp=5:5:0.5:5:5:0.0")  # mild luma sharpen only
    if VIDEO_ENHANCE_COLOR:
        # eq: small, tasteful contrast/saturation lift — NOT a heavy
        # filter-look, just enough to counter the slightly flat/washed
        # look re-encoded/compressed video often has.
        filters.append("eq=contrast=1.05:saturation=1.08:brightness=0.01")

    cmd = [
        "ffmpeg", "-y", "-i", input_path,
        "-vf", ",".join(filters),
        "-c:v", "libx264", "-crf", str(VIDEO_ENHANCE_CRF), "-preset", "fast",
        "-c:a", "copy",
        output_path,
    ]

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=VIDEO_ENHANCE_TIMEOUT_SECONDS
        )
        if result.returncode != 0 or not os.path.exists(output_path) or os.path.getsize(output_path) < 1024:
            logger.warning(f"[video_enhance] ffmpeg enhancement failed, using original: {result.stderr[-500:]}")
            if os.path.exists(output_path):
                os.remove(output_path)
            return input_path

        # Sanity check: the enhanced output's duration should roughly
        # match the source's — a truncated/corrupted encode (which can
        # still exit 0 and produce a file) would silently hand back a
        # partial video otherwise. Reject anything more than ~2s off.
        src_duration = _get_video_duration(input_path)
        out_duration = _get_video_duration(output_path)
        if src_duration and out_duration and abs(src_duration - out_duration) > 2:
            logger.warning(
                f"[video_enhance] Enhanced output duration ({out_duration:.1f}s) doesn't match "
                f"source ({src_duration:.1f}s) — likely a truncated encode, using original instead."
            )
            os.remove(output_path)
            return input_path

        logger.info(
            f"[video_enhance] Enhanced {input_path} -> {output_path} "
            f"(upscaled: {needs_upscale}, source was {width}x{height})"
        )
        # The original, un-enhanced download is no longer needed once the
        # enhanced version exists — remove it so it's not left behind.
        try:
            os.remove(input_path)
        except OSError:
            pass
        return output_path
    except subprocess.TimeoutExpired:
        logger.warning(
            f"[video_enhance] Enhancement pass exceeded {VIDEO_ENHANCE_TIMEOUT_SECONDS}s, using original."
        )
        if os.path.exists(output_path):
            os.remove(output_path)
        return input_path
    except Exception as e:
        logger.warning(f"[video_enhance] Enhancement failed unexpectedly, using original: {e}")
        if os.path.exists(output_path):
            os.remove(output_path)
        return input_path
