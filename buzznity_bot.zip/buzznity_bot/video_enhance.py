"""
video_enhance.py — optional ffmpeg-based quality pass run automatically
right after a video is received (Telegram upload or .mp4 link), before it
enters the publish pipeline. Off by default (VIDEO_ENHANCE=false) — it
adds real processing time (roughly 0.5-2x the video's own length on a
typical VPS CPU, since there's no GPU to accelerate this), which trades
against wanting posts to go out fast. Turn it on in .env if quality
matters more than speed for a given deployment.

What it does, when enabled:
  - Upscales to at least VIDEO_ENHANCE_MIN_HEIGHT (default 1920, matching
    Instagram's recommended Reels resolution) if the source is smaller,
    using a high-quality (lanczos) scaling filter — never downscales.
  - Applies a mild sharpening pass (unsharp) — subtle by design; a heavy
    sharpen looks artificial and works against Instagram's own
    compression pass afterward anyway.
  - Re-encodes video at a quality-focused CRF; audio is stream-copied
    (not re-encoded) since it doesn't need it and re-encoding audio too
    would just add time for no benefit.

Best-effort: if ffmpeg isn't installed, or the enhancement pass fails for
any reason, this returns the ORIGINAL path unchanged and logs a warning —
it never blocks a post over a quality-enhancement failure.
"""
import os
import shutil
import subprocess
from logger import logger
from config import (
    VIDEO_ENHANCE, VIDEO_ENHANCE_MIN_HEIGHT, VIDEO_ENHANCE_CRF, VIDEO_ENHANCE_TIMEOUT_SECONDS,
)


def _ffmpeg_available():
    return shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


def _get_video_dimensions(path):
    """Returns (width, height) or (None, None) if ffprobe isn't available
    or the file can't be read."""
    if not shutil.which("ffprobe"):
        return None, None
    try:
        result = subprocess.run(
            [
                "ffprobe", "-v", "error", "-select_streams", "v:0",
                "-show_entries", "stream=width,height",
                "-of", "csv=s=x:p=0", path,
            ],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0 and "x" in result.stdout:
            w, h = result.stdout.strip().split("x")
            return int(w), int(h)
    except Exception as e:
        logger.warning(f"[video_enhance] Could not read video dimensions: {e}")
    return None, None


def enhance_video(input_path):
    """Returns the path to use going forward — either a new enhanced file
    (input_path with an "_enhanced" suffix) or input_path itself unchanged
    if enhancement is off, ffmpeg is unavailable, or the pass failed.
    Never raises; always returns SOME usable path."""
    if not VIDEO_ENHANCE:
        return input_path
    if not _ffmpeg_available():
        logger.warning("[video_enhance] VIDEO_ENHANCE is on but ffmpeg/ffprobe isn't installed — skipping.")
        return input_path

    width, height = _get_video_dimensions(input_path)
    needs_upscale = height is not None and height < VIDEO_ENHANCE_MIN_HEIGHT

    base, ext = os.path.splitext(input_path)
    output_path = f"{base}_enhanced{ext}"

    # Only scale UP, never down — downscaling would just throw away
    # quality, the opposite of the point here. If already at/above the
    # target, skip the scale filter entirely and just do the sharpen +
    # re-encode pass.
    filters = []
    if needs_upscale:
        # -2 keeps width divisible by 2 (required by most encoders) while
        # preserving aspect ratio exactly.
        filters.append(f"scale=-2:{VIDEO_ENHANCE_MIN_HEIGHT}:flags=lanczos")
    filters.append("unsharp=5:5:0.5:5:5:0.0")  # mild luma sharpen only

    cmd = [
        "ffmpeg", "-y", "-i", input_path,
        "-vf", ",".join(filters),
        "-c:v", "libx264", "-crf", str(VIDEO_ENHANCE_CRF), "-preset", "fast",
        "-c:a", "copy",
        output_path,
    ]

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=VIDEO_ENHANCE_TIMEOUT_SECONDS
        )
        if result.returncode != 0 or not os.path.exists(output_path) or os.path.getsize(output_path) < 1024:
            logger.warning(f"[video_enhance] ffmpeg enhancement failed, using original: {result.stderr[-500:]}")
            if os.path.exists(output_path):
                os.remove(output_path)
            return input_path
        logger.info(
            f"[video_enhance] Enhanced {input_path} -> {output_path} "
            f"(upscaled: {needs_upscale}, source was {width}x{height})"
        )
        # The original, un-enhanced download is no longer needed once the
        # enhanced version exists — remove it so it's not left behind.
        try:
            os.remove(input_path)
        except OSError:
            pass
        return output_path
    except subprocess.TimeoutExpired:
        logger.warning(
            f"[video_enhance] Enhancement pass exceeded {VIDEO_ENHANCE_TIMEOUT_SECONDS}s, using original."
        )
        if os.path.exists(output_path):
            os.remove(output_path)
        return input_path
    except Exception as e:
        logger.warning(f"[video_enhance] Enhancement failed unexpectedly, using original: {e}")
        if os.path.exists(output_path):
            os.remove(output_path)
        return input_path
