"""
database.py — SQLite persistence so pending/scheduled jobs and rate-limit
history survive a bot restart (previously this was an in-memory dict that
was wiped every restart, which is not acceptable for a paid client tool).
"""
import sqlite3
import time
from contextlib import contextmanager
from config import DB_PATH


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                account INTEGER NOT NULL,
                video_path TEXT NOT NULL,
                caption TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending', -- pending/scheduled/publishing/done/failed/cancelled
                scheduled_for REAL,                      -- unix timestamp, NULL = post ASAP
                attempts INTEGER NOT NULL DEFAULT 0,
                error TEXT,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS post_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account INTEGER NOT NULL,
                posted_at REAL NOT NULL,
                job_id INTEGER
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS user_state (
                chat_id INTEGER PRIMARY KEY,
                video_path TEXT,
                account INTEGER,
                caption TEXT,
                stage TEXT,
                updated_at REAL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS account_status (
                account INTEGER PRIMARY KEY,
                status TEXT NOT NULL DEFAULT 'unknown', -- unknown/logged_in/expired
                last_checked REAL
            )
        """)


# ---------- user_state (multi-step conversation flow) ----------

def set_user_state(chat_id, **fields):
    with get_conn() as conn:
        row = conn.execute("SELECT chat_id FROM user_state WHERE chat_id=?", (chat_id,)).fetchone()
        now = time.time()
        if row:
            cols = ", ".join(f"{k}=?" for k in fields)
            conn.execute(
                f"UPDATE user_state SET {cols}, updated_at=? WHERE chat_id=?",
                (*fields.values(), now, chat_id),
            )
        else:
            keys = ["chat_id", "updated_at"] + list(fields.keys())
            vals = [chat_id, now] + list(fields.values())
            placeholders = ",".join("?" * len(keys))
            conn.execute(f"INSERT INTO user_state ({','.join(keys)}) VALUES ({placeholders})", vals)


def get_user_state(chat_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM user_state WHERE chat_id=?", (chat_id,)).fetchone()
        return dict(row) if row else None


def clear_user_state(chat_id):
    with get_conn() as conn:
        conn.execute("DELETE FROM user_state WHERE chat_id=?", (chat_id,))


# ---------- jobs ----------

def create_job(chat_id, account, video_path, caption, scheduled_for=None):
    now = time.time()
    status = "scheduled" if scheduled_for else "pending"
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO jobs (chat_id, account, video_path, caption, status,
               scheduled_for, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (chat_id, account, video_path, caption, status, scheduled_for, now, now),
        )
        return cur.lastrowid


def update_job(job_id, **fields):
    fields["updated_at"] = time.time()
    with get_conn() as conn:
        cols = ", ".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE jobs SET {cols} WHERE id=?", (*fields.values(), job_id))


def get_job(job_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return dict(row) if row else None


def get_due_scheduled_jobs():
    now = time.time()
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM jobs WHERE status='scheduled' AND scheduled_for<=?", (now,)
        ).fetchall()
        return [dict(r) for r in rows]


def get_pending_jobs_for_chat(chat_id):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM jobs WHERE chat_id=? AND status IN "
            "('pending','scheduled','publishing','needs_review') "
            "ORDER BY created_at DESC",
            (chat_id,),
        ).fetchall()
        return [dict(r) for r in rows]


def cancel_job(job_id):
    update_job(job_id, status="cancelled")


def recover_stuck_publishing_jobs():
    """Call once at startup. Any job still marked 'publishing' means the
    process died (crash, VPS reboot, OOM kill, etc.) mid-attempt — we cannot
    know whether Share was already clicked before the crash, so treat every
    one of these the same way as an ambiguous post-share outcome: needs_review,
    never silently auto-retried. Returns the list of recovered job dicts so
    the caller can notify the relevant chats."""
    now = time.time()
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM jobs WHERE status='publishing'").fetchall()
        recovered = [dict(r) for r in rows]
        if recovered:
            conn.execute(
                "UPDATE jobs SET status='needs_review', "
                "error='Process restarted while this job was publishing — outcome unknown.', "
                "updated_at=? WHERE status='publishing'",
                (now,),
            )
    return recovered


# ---------- rate limiting ----------

def record_post(account, job_id=None):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO post_history (account, posted_at, job_id) VALUES (?,?,?)",
            (account, time.time(), job_id),
        )


def minutes_since_last_post(account):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT MAX(posted_at) as last FROM post_history WHERE account=?", (account,)
        ).fetchone()
        if not row or row["last"] is None:
            return None
        return (time.time() - row["last"]) / 60.0


# ---------- account health status ----------

def get_account_status(account):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM account_status WHERE account=?", (account,)).fetchone()
        return dict(row) if row else None


def set_account_status(account, status):
    now = time.time()
    with get_conn() as conn:
        row = conn.execute("SELECT account FROM account_status WHERE account=?", (account,)).fetchone()
        if row:
            conn.execute(
                "UPDATE account_status SET status=?, last_checked=? WHERE account=?",
                (status, now, account),
            )
        else:
            conn.execute(
                "INSERT INTO account_status (account, status, last_checked) VALUES (?,?,?)",
                (account, status, now),
            )
