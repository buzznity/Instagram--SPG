"""
database.py — SQLite persistence so pending/scheduled jobs and rate-limit
history survive a bot restart (previously this was an in-memory dict that
was wiped every restart, which is not acceptable for a paid client tool).
"""
import sqlite3
import time
from contextlib import contextmanager
from config import DB_PATH


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                account INTEGER NOT NULL,
                video_path TEXT NOT NULL,
                caption TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending', -- pending/scheduled/publishing/done/failed/cancelled
                scheduled_for REAL,                      -- unix timestamp, NULL = post ASAP
                attempts INTEGER NOT NULL DEFAULT 0,
                error TEXT,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            )
        """)
        # Migration: per-post override for "hide like/view counts", chosen
        # via a button at confirm time — NULL means "use the .env global
        # default" (HIDE_LIKE_COUNTS), 0/1 means the person explicitly
        # chose off/on for this specific post.
        try:
            conn.execute("ALTER TABLE jobs ADD COLUMN hide_likes INTEGER")
        except sqlite3.OperationalError:
            pass
        conn.execute("""
            CREATE TABLE IF NOT EXISTS post_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account INTEGER NOT NULL,
                posted_at REAL NOT NULL,
                job_id INTEGER
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS user_state (
                chat_id INTEGER PRIMARY KEY,
                video_path TEXT,
                account INTEGER,
                caption TEXT,
                stage TEXT,
                updated_at REAL
            )
        """)
        # Migration: "extra" holds generic scratch JSON for a conversation
        # flow — currently the list of selected account numbers during
        # multi-account checkbox selection. Added after the original
        # table, so existing installs need it added on top; SQLite has no
        # "ADD COLUMN IF NOT EXISTS", so just ignore the error if it's
        # already there.
        try:
            conn.execute("ALTER TABLE user_state ADD COLUMN extra TEXT")
        except sqlite3.OperationalError:
            pass
        conn.execute("""
            CREATE TABLE IF NOT EXISTS account_status (
                account INTEGER PRIMARY KEY,
                status TEXT NOT NULL DEFAULT 'unknown', -- unknown/logged_in/expired
                last_checked REAL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS post_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account INTEGER NOT NULL,
                post_url TEXT,
                caption_snippet TEXT,
                likes INTEGER,
                comments INTEGER,
                views INTEGER,
                scraped_at REAL NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS admins (
                chat_id INTEGER PRIMARY KEY,
                label TEXT,
                added_by INTEGER,
                added_at REAL NOT NULL
            )
        """)


# ---------- admins (multi-user access, beyond the .env owner) ----------

def add_admin(chat_id, added_by, label=None):
    with get_conn() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO admins (chat_id, label, added_by, added_at) VALUES (?, ?, ?, ?)",
            (chat_id, label, added_by, time.time()),
        )


def remove_admin(chat_id):
    with get_conn() as conn:
        cur = conn.execute("DELETE FROM admins WHERE chat_id=?", (chat_id,))
        return cur.rowcount > 0


def is_admin(chat_id):
    with get_conn() as conn:
        row = conn.execute("SELECT 1 FROM admins WHERE chat_id=?", (chat_id,)).fetchone()
        return row is not None


def list_admins():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM admins ORDER BY added_at").fetchall()
        return [dict(r) for r in rows]


# ---------- post_metrics (analytics) ----------

def save_post_metrics(account, entries):
    """entries: list of dicts with keys post_url, caption_snippet, likes,
    comments, views (any may be None if not readable)."""
    now = time.time()
    with get_conn() as conn:
        for e in entries:
            conn.execute(
                "INSERT INTO post_metrics (account, post_url, caption_snippet, likes, comments, views, scraped_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (account, e.get("post_url"), e.get("caption_snippet"), e.get("likes"),
                 e.get("comments"), e.get("views"), now),
            )


def get_latest_metrics(account, limit=6):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM post_metrics WHERE account=? ORDER BY scraped_at DESC, id DESC LIMIT ?",
            (account, limit),
        ).fetchall()
        return [dict(r) for r in rows]


# ---------- user_state (multi-step conversation flow) ----------

def set_user_state(chat_id, **fields):
    with get_conn() as conn:
        row = conn.execute("SELECT chat_id FROM user_state WHERE chat_id=?", (chat_id,)).fetchone()
        now = time.time()
        if row:
            cols = ", ".join(f"{k}=?" for k in fields)
            conn.execute(
                f"UPDATE user_state SET {cols}, updated_at=? WHERE chat_id=?",
                (*fields.values(), now, chat_id),
            )
        else:
            keys = ["chat_id", "updated_at"] + list(fields.keys())
            vals = [chat_id, now] + list(fields.values())
            placeholders = ",".join("?" * len(keys))
            conn.execute(f"INSERT INTO user_state ({','.join(keys)}) VALUES ({placeholders})", vals)


def get_user_state(chat_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM user_state WHERE chat_id=?", (chat_id,)).fetchone()
        return dict(row) if row else None


def clear_user_state(chat_id):
    with get_conn() as conn:
        conn.execute("DELETE FROM user_state WHERE chat_id=?", (chat_id,))


# ---------- jobs ----------

def create_job(chat_id, account, video_path, caption, scheduled_for=None, hide_likes=None):
    now = time.time()
    status = "scheduled" if scheduled_for else "pending"
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO jobs (chat_id, account, video_path, caption, status,
               scheduled_for, hide_likes, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (chat_id, account, video_path, caption, status, scheduled_for, hide_likes, now, now),
        )
        return cur.lastrowid


def update_job(job_id, **fields):
    fields["updated_at"] = time.time()
    with get_conn() as conn:
        cols = ", ".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE jobs SET {cols} WHERE id=?", (*fields.values(), job_id))


def get_job(job_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return dict(row) if row else None


def get_due_scheduled_jobs():
    now = time.time()
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM jobs WHERE status='scheduled' AND scheduled_for<=?", (now,)
        ).fetchall()
        return [dict(r) for r in rows]


def get_pending_jobs_for_chat(chat_id):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM jobs WHERE chat_id=? AND status IN "
            "('pending','scheduled','publishing','needs_review') "
            "ORDER BY created_at DESC",
            (chat_id,),
        ).fetchall()
        return [dict(r) for r in rows]


def cancel_job(job_id):
    update_job(job_id, status="cancelled")


def recover_stuck_publishing_jobs():
    """Call once at startup. Any job still marked 'publishing' means the
    process died (crash, VPS reboot, OOM kill, etc.) mid-attempt — we cannot
    know whether Share was already clicked before the crash, so treat every
    one of these the same way as an ambiguous post-share outcome: needs_review,
    never silently auto-retried. Returns the list of recovered job dicts so
    the caller can notify the relevant chats."""
    now = time.time()
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM jobs WHERE status='publishing'").fetchall()
        recovered = [dict(r) for r in rows]
        if recovered:
            conn.execute(
                "UPDATE jobs SET status='needs_review', "
                "error='Process restarted while this job was publishing — outcome unknown.', "
                "updated_at=? WHERE status='publishing'",
                (now,),
            )
    return recovered


# ---------- rate limiting ----------

def record_post(account, job_id=None):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO post_history (account, posted_at, job_id) VALUES (?,?,?)",
            (account, time.time(), job_id),
        )


def minutes_since_last_post(account):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT MAX(posted_at) as last FROM post_history WHERE account=?", (account,)
        ).fetchone()
        if not row or row["last"] is None:
            return None
        return (time.time() - row["last"]) / 60.0


# ---------- account health status ----------

def get_account_status(account):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM account_status WHERE account=?", (account,)).fetchone()
        return dict(row) if row else None


def set_account_status(account, status):
    now = time.time()
    with get_conn() as conn:
        row = conn.execute("SELECT account FROM account_status WHERE account=?", (account,)).fetchone()
        if row:
            conn.execute(
                "UPDATE account_status SET status=?, last_checked=? WHERE account=?",
                (status, now, account),
            )
        else:
            conn.execute(
                "INSERT INTO account_status (account, status, last_checked) VALUES (?,?,?)",
                (account, status, now),
            )
