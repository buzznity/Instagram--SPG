"""
test_billing_api.py — run this ON THE VPS (not here) to see the REAL
request-payment and payment-status responses, using the BILLING_API_KEY
already configured in .env. Two steps, since payment-status only makes
sense after you've actually paid:

STEP 1 (before paying):
    cd ~/Instagram--SPG
    source venv/bin/activate
    python test_billing_api.py request

This prints the raw payment-request JSON and saves requestId to
/tmp/buzznity_test_request_id.txt. Copy the printed JSON here in chat
(mask/remove anything that looks like a real secret/token, though this
endpoint shouldn't return one).

STEP 2 (open the paymentLink from step 1, pay the ₹97 test amount, THEN):
    python test_billing_api.py status

This reads the saved requestId and prints the raw payment-status JSON.
Copy that here too.

This intentionally does NOT print BILLING_API_KEY itself anywhere.
"""
import sys
import json
import billing_api

REQUEST_ID_FILE = "/tmp/buzznity_test_request_id.txt"


def do_request():
    # ₹97 test amount — same figure you mentioned ($1). Sending it as a
    # RAW integer here (not run through the USD/cents conversion in
    # billing_api.create_payment_request) specifically so we can see
    # EXACTLY what the API echoes back for "amount" and what the
    # paymentLink/QR actually asks the payer for — that comparison is
    # what tells us the real unit, instead of guessing.
    try:
        resp = billing_api.requests.post(
            f"{billing_api.BILLING_API_BASE_URL}/payment-request",
            headers=billing_api._headers(),
            json={"amount": 97, "note": "Buzznity live test payment"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        print(f"❌ Request failed: {e}")
        sys.exit(1)

    print("=== RAW payment-request response ===")
    print(json.dumps(data, indent=2))

    request_id = data.get("requestId")
    if request_id:
        with open(REQUEST_ID_FILE, "w") as f:
            f.write(request_id)
        print(f"\n✅ Saved requestId to {REQUEST_ID_FILE}")
        print("\nNow open the paymentLink above, pay the ₹97, THEN run:")
        print("    python test_billing_api.py status")
    else:
        print("\n⚠️ No 'requestId' field in the response — check the JSON above for the actual field name.")


def do_status():
    try:
        with open(REQUEST_ID_FILE) as f:
            request_id = f.read().strip()
    except FileNotFoundError:
        print(f"❌ No saved requestId found at {REQUEST_ID_FILE} — run 'python test_billing_api.py request' first.")
        sys.exit(1)

    try:
        resp = billing_api.requests.get(
            f"{billing_api.BILLING_API_BASE_URL}/payment-status/{request_id}",
            headers=billing_api._headers(),
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        print(f"❌ Status check failed: {e}")
        sys.exit(1)

    print("=== RAW payment-status response ===")
    print(json.dumps(data, indent=2))


if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] not in ("request", "status"):
        print("Usage: python test_billing_api.py request|status")
        sys.exit(1)
    if sys.argv[1] == "request":
        do_request()
    else:
        do_status()
