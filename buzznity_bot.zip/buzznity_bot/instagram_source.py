"""
instagram_source.py
Downloads a public Instagram Reel and extracts its available description.
Uses yt-dlp. This intentionally requests a single-file format so it can
work on lightweight/Pydroid-style environments without requiring ffmpeg.
"""

import os
import yt_dlp


def download_reel(url: str, output_dir: str):
    os.makedirs(output_dir, exist_ok=True)
    output = os.path.join(output_dir, "ig_%(id)s.%(ext)s")

    opts = {
        "format": "best[ext=mp4]/best",
        "outtmpl": output,
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
    }

    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        filename = ydl.prepare_filename(info)

    if not os.path.isfile(filename):
        raise FileNotFoundError("Instagram video was downloaded but the file was not found.")

    return {
        "path": filename,
        "caption": info.get("description") or info.get("title") or "",
        "username": info.get("uploader") or "",
        "title": info.get("title") or "",
        "id": info.get("id") or "",
    }
