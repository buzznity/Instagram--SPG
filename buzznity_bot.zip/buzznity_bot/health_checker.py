"""
health_checker.py — every HEALTH_CHECK_INTERVAL_MINUTES, opens each account's
saved session headlessly, checks logged-in vs expired, and messages the
allowed Telegram chat ONLY when status changes (not on every check, to avoid
spamming). Skips an account entirely if its lock is currently held by a
publish job or a manual login.py run, rather than waiting/blocking.
"""
import threading
import time
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

from config import (
    ALLOWED_CHAT_ID, ACCOUNT_COUNT,
    HEALTH_CHECK_INTERVAL_MINUTES, HEALTH_CHECK_DELAY_FIRST_RUN,
)
from logger import logger
import database as db
from account_locks import account_lock
import session_store

# Statuses that are safe/meaningful to persist and notify on. "network_error"
# is deliberately NOT one of these — it's transient by definition, so it's
# only logged, never written to account_status or turned into a Telegram
# message. Otherwise a brief VPS network hiccup would look identical to a
# real session expiry to the client.
PERSISTABLE_STATUSES = {"logged_in", "expired", "challenge", "no_session"}


def _check_account(account: int):
    """Returns (status, username). status is 'logged_in', 'expired',
    'challenge', 'no_session', or 'network_error'. Only the first four are
    ever persisted/notified — 'network_error' means we genuinely couldn't
    tell, so the caller should just skip this cycle rather than concluding
    anything. username is only ever populated when status is 'logged_in'
    (grabbed from the profile avatar link's href, same technique as
    analytics.py) — None in every other case."""
    if session_store.session_kind(account) is None:
        return "no_session", None

    with sync_playwright() as p, session_store.open_context(p, account, headless=True) as context:
        page = context.new_page()

        # A navigation failure here (DNS blip, VPS network hiccup, etc.)
        # is a NETWORK problem, not evidence the session expired. Keep
        # this in its own try/except so it's never confused with the
        # "logged out" signal below.
        try:
            page.goto("https://www.instagram.com/", timeout=30000)
        except Exception as e:
            logger.info(f"[health] Account {account} navigation failed (network): {e}")
            return "network_error", None

        try:
            page.wait_for_selector(
                "svg[aria-label='New post'], svg[aria-label='Direct'], input[name='username']",
                timeout=15000,
            )
        except PWTimeout:
            # Neither the logged-in dashboard NOR the login form appeared.
            # This is ambiguous — could be a slow/unstable connection,
            # could be an unrecognized Instagram screen. It is NOT a
            # confirmed "expired" signal (that requires actually seeing
            # the username field), so treat it as a network/unknown
            # blip rather than reporting false expiry to the client.
            return "network_error", None

        # From here on, one of the expected elements definitely rendered,
        # so these ARE trustworthy, specific signals.
        if page.locator("input[name='username']").is_visible():
            return "expired", None

        if "/challenge/" in page.url or "/accounts/suspended" in page.url:
            return "challenge", None

        username = None
        try:
            avatar_img = page.locator("img[alt*='profile picture' i]").first
            avatar_img.wait_for(state="visible", timeout=5000)
            href = avatar_img.locator("xpath=ancestor::a[1]").get_attribute("href")
            username = href.strip("/").split("/")[0] if href else None
        except Exception:
            pass  # best-effort — a login-status check succeeding matters far more than this

        return "logged_in", username


def _run_once(bot):
    for account in range(1, ACCOUNT_COUNT + 1):
        with account_lock(account, blocking=False) as acquired:
            if not acquired:
                logger.info(f"[health] Account {account} is busy (publishing or login.py), skipping.")
                continue
            try:
                new_status, username = _check_account(account)
            except Exception as e:
                logger.warning(f"[health] Account {account} check errored unexpectedly: {e}")
                continue

        if new_status not in PERSISTABLE_STATUSES:
            # e.g. "network_error" — log only, don't touch stored status or notify.
            logger.info(f"[health] Account {account} check inconclusive ({new_status}), will retry next cycle.")
            continue

        prev = db.get_account_status(account)
        prev_status = prev["status"] if prev else None
        db.set_account_status(account, new_status, username=username)

        if new_status != prev_status:
            logger.info(f"[health] Account {account} status changed: {prev_status} -> {new_status}")
            if new_status == "expired":
                bot.send_message(
                    ALLOWED_CHAT_ID,
                    f"⚠️ Account {account} session has EXPIRED. Re-run login.py to restore it — "
                    f"posts to this account will fail until then.",
                )
            elif new_status == "challenge":
                bot.send_message(
                    ALLOWED_CHAT_ID,
                    f"🚫 Account {account} has an Instagram checkpoint/challenge/restriction. "
                    f"This needs manual resolution — re-run login.py and follow whatever "
                    f"Instagram is asking for in that browser window.",
                )
            elif new_status == "logged_in" and prev_status in ("expired", "challenge"):
                bot.send_message(ALLOWED_CHAT_ID, f"✅ Account {account} session is back and healthy.")
            elif new_status == "no_session":
                bot.send_message(
                    ALLOWED_CHAT_ID,
                    f"ℹ️ Account {account} has no saved session yet (run login.py to set it up).",
                )


def _loop(bot):
    logger.info(
        f"Health checker thread started (every {HEALTH_CHECK_INTERVAL_MINUTES} min, "
        f"delay first run: {HEALTH_CHECK_DELAY_FIRST_RUN})."
    )
    if HEALTH_CHECK_DELAY_FIRST_RUN:
        time.sleep(HEALTH_CHECK_INTERVAL_MINUTES * 60)
    while True:
        try:
            _run_once(bot)
        except Exception:
            logger.exception("Health checker loop error")
        time.sleep(HEALTH_CHECK_INTERVAL_MINUTES * 60)


def start_health_checker(bot):
    t = threading.Thread(target=_loop, args=(bot,), daemon=True)
    t.start()
    return t
