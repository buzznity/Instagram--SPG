"""
account_locks.py — one lock per Instagram account session.

Two layers, because there are two kinds of concurrency to guard against:
  1. Intra-process (bot.py's scheduler thread vs its health_checker thread)
     -> a plain threading.Lock, fast, no disk I/O.
  2. Cross-process (bot.py running as a service, vs login.py run manually
     by a developer in a separate terminal/session)
     -> an flock() on a lock file, since threading.Lock is invisible outside
     the process that created it. Without this, running login.py while the
     bot service is live can open the same Chromium user_data_dir twice at
     once, which corrupts or silently rejects one of the two sessions.

Use `with account_lock(account, blocking=True/False) as acquired:` — see
poster.py, health_checker.py, and login.py for how each side uses it.
"""
import os
import threading
import fcntl
from contextlib import contextmanager
from config import SESSION_DIR

_locks = {}
_registry_lock = threading.Lock()


def _get_thread_lock(account: int) -> threading.Lock:
    with _registry_lock:
        if account not in _locks:
            _locks[account] = threading.Lock()
        return _locks[account]


def _lock_file_path(account: int) -> str:
    path = os.path.join(SESSION_DIR, f".account_{account}.lock")
    if not os.path.exists(path):
        open(path, "a").close()
    return path


@contextmanager
def account_lock(account: int, blocking: bool = True):
    """Yields True if the lock was acquired, False if not (only possible
    when blocking=False). Always releases cleanly on exit."""
    thread_lock = _get_thread_lock(account)
    got_thread_lock = thread_lock.acquire(blocking=blocking)
    if not got_thread_lock:
        yield False
        return

    fd = None
    got_file_lock = False
    try:
        fd = open(_lock_file_path(account), "r+")
        try:
            flags = fcntl.LOCK_EX if blocking else (fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(fd, flags)
            got_file_lock = True
        except (BlockingIOError, OSError):
            got_file_lock = False

        if not got_file_lock:
            yield False
            return

        yield True
    finally:
        if fd is not None:
            if got_file_lock:
                try:
                    fcntl.flock(fd, fcntl.LOCK_UN)
                except OSError:
                    pass
            fd.close()
        thread_lock.release()


# Backward-compatible helper for any code that still wants the raw
# threading.Lock for intra-process-only use (kept for clarity; poster.py and
# health_checker.py use account_lock() directly).
def get_lock(account: int) -> threading.Lock:
    return _get_thread_lock(account)
