"""
logger.py — timestamped logging to both console and a rotating daily file,
so you have an audit trail to show the client and to debug failures.
"""
import logging
import os
from logging.handlers import TimedRotatingFileHandler
from config import LOG_DIR

_log_path = os.path.join(LOG_DIR, "buzznity.log")

logger = logging.getLogger("buzznity")
logger.setLevel(logging.INFO)

if not logger.handlers:
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")

    file_handler = TimedRotatingFileHandler(_log_path, when="midnight", backupCount=14, encoding="utf-8")
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(fmt)
    logger.addHandler(console_handler)
