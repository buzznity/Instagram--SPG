"""
session_store.py — a single place that understands the two ways an
account's Instagram session can be stored on disk, and hands back a ready
Playwright BrowserContext regardless of which one is in use.

1. Persistent Chromium profile: sessions/account_N/  (a real folder)
   Created by running `python login.py` and completing an interactive
   login. This is the default, most robust option — Instagram sees a
   full, consistent browser profile (cache, local storage, etc.), not
   just a handful of cookies.

2. Cookie-only session: sessions/account_N.json  (a single file)
   Created via the Telegram /addaccount flow, by pasting four cookie
   values (sessionid, csrftoken, ds_user_id, mid) copied out of a
   browser's dev tools. Lighter weight and faster to set up, but more
   fragile — no browsing history/local storage, so Instagram is
   somewhat more likely to ask for re-verification down the line. Use
   login.py instead when possible; this exists for convenience.

If both exist for the same account number, the persistent profile wins,
since it's the more complete option.
"""
import os
import json
import contextlib
from config import SESSION_DIR

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)
VIEWPORT = {"width": 1280, "height": 720}

# The only cookies we accept from the manual /addaccount flow. Deliberately
# a fixed, minimal set — not an open-ended "paste any cookie" mechanism.
REQUIRED_COOKIE_FIELDS = ["sessionid", "csrftoken", "ds_user_id", "mid"]


def profile_dir(account):
    return os.path.join(SESSION_DIR, f"account_{account}")


def cookie_json_path(account):
    return os.path.join(SESSION_DIR, f"account_{account}.json")


def session_kind(account):
    """Returns 'profile', 'cookie', or None (no session saved at all)."""
    p = profile_dir(account)
    if os.path.isdir(p) and os.listdir(p):
        return "profile"
    if os.path.isfile(cookie_json_path(account)):
        return "cookie"
    return None


def save_cookie_session(account, cookie_values: dict):
    """cookie_values must contain exactly REQUIRED_COOKIE_FIELDS keys.
    Writes a Playwright storage_state JSON file that new_context(storage_state=...)
    can load directly."""
    missing = [f for f in REQUIRED_COOKIE_FIELDS if not cookie_values.get(f)]
    if missing:
        raise ValueError(f"Missing cookie values: {', '.join(missing)}")

    cookies = []
    for name in REQUIRED_COOKIE_FIELDS:
        cookies.append({
            "name": name,
            "value": cookie_values[name],
            "domain": ".instagram.com",
            "path": "/",
            "expires": -1,
            "httpOnly": name in ("sessionid", "mid"),
            "secure": True,
            "sameSite": "Lax",
        })

    state = {"cookies": cookies, "origins": []}
    path = cookie_json_path(account)
    with open(path, "w") as f:
        json.dump(state, f)
    os.chmod(path, 0o600)
    return path


def delete_session(account):
    """Removes whichever session type is currently saved for this account."""
    removed = []
    cpath = cookie_json_path(account)
    if os.path.isfile(cpath):
        os.remove(cpath)
        removed.append(cpath)
    pdir = profile_dir(account)
    if os.path.isdir(pdir):
        import shutil
        shutil.rmtree(pdir)
        removed.append(pdir)
    return removed


@contextlib.contextmanager
def open_context(playwright, account, headless=True):
    """Yields a ready-to-use Playwright BrowserContext for this account, no
    matter which storage format it's using, and cleans up whatever browser/
    context resources it opened. Raises FileNotFoundError if no session is
    saved yet for this account."""
    kind = session_kind(account)

    if kind == "profile":
        context = playwright.chromium.launch_persistent_context(
            user_data_dir=profile_dir(account),
            headless=headless,
            viewport=VIEWPORT,
            user_agent=USER_AGENT,
        )
        try:
            yield context
        finally:
            context.close()

    elif kind == "cookie":
        browser = playwright.chromium.launch(headless=headless)
        try:
            context = browser.new_context(
                storage_state=cookie_json_path(account),
                viewport=VIEWPORT,
                user_agent=USER_AGENT,
            )
            try:
                yield context
            finally:
                context.close()
        finally:
            browser.close()

    else:
        raise FileNotFoundError(f"No saved session for account {account}.")
