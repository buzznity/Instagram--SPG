"""
billing_api.py — thin client for the Buzznity Billing API
(billing.buzznity.in), used for automatic payment verification as an
alternative to the manual screenshot-review flow in subscriptions.py.

CONFIRMED via the operator's own PHP reference implementation
(buzznity-payment-integration.php) — no longer guesses:
  - amount is a PLAIN decimal (e.g. createPaymentRequest(499.00, ...)),
    NOT cents/paise. AMOUNT_IS_CENTS is now False. (This was previously
    guessed True — left uncorrected, a $29 plan would have requested
    2900 instead of 29, a 100x overcharge.)
  - status is "PENDING" or "CONFIRMED" (matches the sandbox test result
    already observed).
  - There's an optional `reference` field on payment-request, useful for
    tracking (this bot passes the local payment_id as the reference).

Payment requests/QR codes are valid for 10 minutes (confirmed by the
operator) — see PAYMENT_REQUEST_EXPIRY_MINUTES in config.py, which
check_and_activate_auto_payment() in subscriptions.py uses to stop
polling a stale request and prompt for a fresh one instead.
"""
import requests
from logger import logger
from config import BILLING_API_KEY, BILLING_API_BASE_URL

AMOUNT_IS_CENTS = False  # CONFIRMED via the operator's PHP reference — plain decimal amount


class BillingAPIError(Exception):
    pass


def _headers():
    return {
        "Authorization": f"Bearer {BILLING_API_KEY}",
        "Content-Type": "application/json",
    }


def create_payment_request(amount_usd, note, reference=None):
    """amount_usd: the price in whole/fractional dollars (e.g. 29 for the
    Basic plan) — confirmed to be a plain decimal, not cents (see module
    docstring). reference: optional tracking id (this bot passes its own
    local payment_id) — the operator's own PHP reference implementation
    supports this field for exactly that purpose. Returns the parsed JSON
    dict on success. Raises BillingAPIError on any failure (network,
    non-2xx, unexpected shape) — callers should catch this and fall back
    to the manual payment-proof flow rather than leaving the customer
    stuck."""
    if not BILLING_API_KEY:
        raise BillingAPIError("BILLING_API_KEY is not configured.")

    amount = int(round(amount_usd * 100)) if AMOUNT_IS_CENTS else amount_usd
    body = {"amount": amount, "note": note}
    if reference is not None:
        body["reference"] = str(reference)
    try:
        resp = requests.post(
            f"{BILLING_API_BASE_URL}/payment-request",
            headers=_headers(),
            json=body,
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
    except requests.exceptions.RequestException as e:
        raise BillingAPIError(f"payment-request call failed: {e}")
    except ValueError as e:
        raise BillingAPIError(f"payment-request returned non-JSON response: {e}")

    for field in ("requestId", "paymentLink"):
        if field not in data:
            raise BillingAPIError(f"payment-request response missing expected field '{field}': {data}")
    logger.info(f"[billing_api] Created payment request {data.get('requestId')} for ${amount_usd}")
    return data


# CONFIRMED (real sandbox response): "CONFIRMED" is the actual value on
# success. The rest remain speculative fallbacks for now.
_PAID_STATUS_VALUES = {"confirmed", "paid", "success", "successful", "completed"}
_FAILED_STATUS_VALUES = {"failed", "cancelled", "canceled", "expired", "declined"}


def check_payment_status(request_id):
    """Returns the parsed JSON dict. Raises BillingAPIError on failure.
    Use is_payment_successful()/is_payment_failed() on the result rather
    than reading its 'status' field directly, so the (currently guessed)
    matching logic lives in exactly one place."""
    if not BILLING_API_KEY:
        raise BillingAPIError("BILLING_API_KEY is not configured.")
    try:
        resp = requests.get(
            f"{BILLING_API_BASE_URL}/payment-status/{request_id}",
            headers=_headers(),
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
    except requests.exceptions.RequestException as e:
        raise BillingAPIError(f"payment-status call failed: {e}")
    except ValueError as e:
        raise BillingAPIError(f"payment-status returned non-JSON response: {e}")

    logger.info(f"[billing_api] Status for {request_id}: {data}")
    return data


def is_payment_successful(status_response):
    status = str(status_response.get("status", "")).strip().lower()
    return status in _PAID_STATUS_VALUES


def is_payment_failed(status_response):
    status = str(status_response.get("status", "")).strip().lower()
    return status in _FAILED_STATUS_VALUES
