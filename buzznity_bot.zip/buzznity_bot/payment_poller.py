"""
payment_poller.py — background thread that automatically polls the
Buzznity Billing API for any still-pending automatic (UPI) payments, and
activates the corresponding subscription the moment one clears — the
customer doesn't need to tap "🔄 Check Payment" themselves for this to
happen, though that button still works too (useful if they want to know
right away rather than waiting up to POLL_INTERVAL_SECONDS).

Also sweeps for expired subscriptions each cycle (subscriptions.
mark_expired_subscriptions()) — this is the wiring that was previously
missing (the function existed but nothing called it periodically).
"""
import threading
import time
import datetime
from logger import logger
import subscriptions
import billing_api

POLL_INTERVAL_SECONDS = 60


def _poll_pending_payments(bot):
    for payment in subscriptions.list_pending_auto_payments():
        try:
            result, sub = subscriptions.check_and_activate_auto_payment(payment["id"])
        except billing_api.BillingAPIError as e:
            logger.info(f"[payment_poller] Status check failed for payment {payment['id']}: {e}")
            continue

        if result == "paid":
            plan = subscriptions.PLANS[sub["plan_key"]]
            expires = datetime.datetime.fromtimestamp(sub["expires_at"]).strftime("%Y-%m-%d")
            try:
                bot.send_message(
                    payment["chat_id"],
                    f"🎉 Payment verified! You're now on the *{plan['name']}* plan "
                    f"({plan['account_limit']} accounts), active until {expires}.\n\n"
                    f"Send /start to add your Instagram accounts.",
                    parse_mode="Markdown",
                )
            except Exception as e:
                logger.warning(f"Could not notify customer {payment['chat_id']} of auto-activated payment: {e}")
        elif result == "expired":
            # Silently stops polling this one (list_pending_auto_payments
            # won't return it again — status is no longer 'pending' once
            # check_and_activate_auto_payment marks it expired). A gentle
            # heads-up is still worth sending since the customer may be
            # sitting there waiting.
            try:
                bot.send_message(
                    payment["chat_id"],
                    "⌛ That payment link expired (valid for 10 minutes). Send /start and "
                    "pick your plan again for a fresh one.",
                )
            except Exception:
                pass
        elif result == "failed":
            try:
                bot.send_message(
                    payment["chat_id"],
                    "❌ That payment didn't go through. Please try again via /start.",
                )
            except Exception:
                pass
        # "pending" — say nothing, just check again next cycle.


def _sweep_expired_subscriptions(bot):
    # mark_expired_subscriptions() only flips database status — it
    # doesn't know who to notify, so notification happens here: anyone
    # whose customer row just flipped to 'expired' gets a heads-up.
    # (Simple approach: re-check each customer whose status changes this
    # cycle by comparing before/after — mark_expired_subscriptions
    # returns a count, not the affected chat_ids, so for notification
    # purposes we query customers currently in 'expired' state that
    # weren't already known to be expired... to keep this simple and
    # correct without adding more plumbing, notification is best-effort:
    # skip it for now and rely on /start showing their expired status
    # next time they open the bot. A "just expired" push notification is
    # a reasonable future improvement once this needs to feel more
    # proactive.)
    count = subscriptions.mark_expired_subscriptions()
    if count:
        logger.info(f"[payment_poller] Marked {count} subscription(s) as expired.")


def _loop(bot):
    logger.info("Payment poller thread started.")
    while True:
        try:
            _poll_pending_payments(bot)
            _sweep_expired_subscriptions(bot)
        except Exception:
            logger.exception("Payment poller loop error")
        time.sleep(POLL_INTERVAL_SECONDS)


def start_payment_poller(bot):
    t = threading.Thread(target=_loop, args=(bot,), daemon=True)
    t.start()
