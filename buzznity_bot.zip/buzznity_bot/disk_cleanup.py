"""
disk_cleanup.py — background thread that periodically removes stale
downloaded video files from DOWNLOAD_DIR, so nothing accumulates forever
on the VPS disk. Confirmed requirement: a downloaded video should be
posted and cleaned up promptly, not linger indefinitely.

Safety first: a file is only EVER deleted if it is NOT referenced by
database.get_all_referenced_video_paths() (an active user_state, a
queued intake item, or a not-yet-finished job) AND it's older than
DISK_CLEANUP_MIN_AGE_MINUTES. The minimum age is deliberately more
generous than "5 minutes" — a file can legitimately sit unreferenced for
a short window between processing steps (e.g. right after a job finishes
successfully, before its row's status flips), and a wrongly-aggressive
sweep deleting a file still one step from being touched would be a much
worse outcome than disk filling up slightly slower. 30 minutes is the
default — still far faster than "never", the actual problem being fixed.
"""
import os
import time
import threading
from logger import logger
import database as db
from config import DOWNLOAD_DIR, DISK_CLEANUP_INTERVAL_MINUTES, DISK_CLEANUP_MIN_AGE_MINUTES


def _run_once():
    if not os.path.isdir(DOWNLOAD_DIR):
        return
    referenced = db.get_all_referenced_video_paths()
    now = time.time()
    removed = 0
    for name in os.listdir(DOWNLOAD_DIR):
        path = os.path.join(DOWNLOAD_DIR, name)
        if not os.path.isfile(path) or not name.lower().endswith(".mp4"):
            continue
        if path in referenced:
            continue
        try:
            age_minutes = (now - os.path.getmtime(path)) / 60.0
        except OSError:
            continue
        if age_minutes < DISK_CLEANUP_MIN_AGE_MINUTES:
            continue
        try:
            os.remove(path)
            removed += 1
        except OSError as e:
            logger.warning(f"[disk_cleanup] Could not remove {path}: {e}")
    if removed:
        logger.info(f"[disk_cleanup] Removed {removed} stale unreferenced video file(s).")


def _loop():
    logger.info("Disk cleanup thread started.")
    while True:
        try:
            _run_once()
        except Exception:
            logger.exception("Disk cleanup loop error")
        time.sleep(DISK_CLEANUP_INTERVAL_MINUTES * 60)


def start_disk_cleanup():
    t = threading.Thread(target=_loop, daemon=True)
    t.start()
