"""
poster.py — publishes a single reel via the saved Playwright session.
Handles: session-expired detection, popups, retries on transient timeouts.
Does NOT attempt to defeat captchas/challenges or spoof detection signals —
if Instagram throws one of those, this reports failure rather than trying
to bypass it.
"""
import os
import time
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
from config import MAX_RETRIES, LOG_DIR
from logger import logger
from account_locks import account_lock
import session_store

SCREENSHOT_DIR = os.path.join(LOG_DIR, "screenshots")
os.makedirs(SCREENSHOT_DIR, exist_ok=True)


def _save_screenshot(page, account, tag):
    """Best-effort debug screenshot on failure. Never raises — a screenshot
    failure must not mask the real error."""
    try:
        path = os.path.join(SCREENSHOT_DIR, f"account{account}_{tag}_{int(time.time())}.png")
        page.screenshot(path=path)
        logger.info(f"[account {account}] Saved debug screenshot: {path}")
    except Exception as e:
        logger.warning(f"[account {account}] Could not save screenshot: {e}")


class SessionExpiredError(Exception):
    """Retryable is irrelevant here — always requires re-login, never retried."""
    pass


class ChallengeRequiredError(Exception):
    """Instagram is showing a checkpoint/suspicious-login challenge, action
    block, or similar restriction — distinct from a plain expired session.
    This needs a human to resolve manually in a real browser (see login.py);
    an automated retry will not fix it and may make Instagram more suspicious."""
    pass


class PublishError(Exception):
    """Something failed BEFORE the Share button was clicked. Safe to retry —
    no post could have been created yet."""
    pass


class PublishUncertainError(Exception):
    """Something failed AFTER the Share button was clicked and we could not
    confirm success or failure. NEVER auto-retried — retrying here risks a
    duplicate post, which is worse than a single failed/uncertain one. This
    is surfaced to a human for manual verification instead."""
    pass


def _dismiss_if_present(page, selector, timeout=3000):
    try:
        el = page.locator(selector)
        el.wait_for(state="visible", timeout=timeout)
        el.click()
        return True
    except PWTimeout:
        return False


def _publish_once(account: int, video_path: str, caption: str, status_cb=None):
    """One publish attempt. Raises SessionExpiredError or PublishError on failure.
    Blocks (briefly) on the account's lock so the health checker can never open
    the same profile at the same time as a real publish job."""

    def report(msg):
        logger.info(f"[account {account}] {msg}")
        if status_cb:
            status_cb(msg)

    if session_store.session_kind(account) is None:
        raise SessionExpiredError(f"No saved session for account {account}.")

    # Blocking acquire (both the intra-process thread lock and the
    # cross-process flock) — publishing takes priority, the health checker
    # or a manual login.py run will simply wait or skip its turn.
    with account_lock(account, blocking=True):
        _publish_locked(account, video_path, caption, report)


def _publish_locked(account, video_path, caption, report):
    with sync_playwright() as p, session_store.open_context(p, account, headless=True) as context:
        # Tracks whether the Share button was actually clicked. Once True, a
        # post may exist on Instagram's side — every failure path after this
        # point must raise PublishUncertainError (never retried), not
        # PublishError (retried), or a retry could create a duplicate post.
        share_clicked = False
        try:
            page = context.new_page()
            page.goto("https://www.instagram.com/", timeout=30000)

            try:
                page.wait_for_selector(
                    "svg[aria-label='New post'], svg[aria-label='Direct'], input[name='username']",
                    timeout=15000,
                )
            except PWTimeout:
                raise PublishError("Instagram home page never loaded properly (timeout).")

            if page.locator("input[name='username']").is_visible():
                raise SessionExpiredError(f"Session expired for account {account}. Re-run login.py.")

            # Checkpoint / suspicious-login / action-block detection — distinct
            # from a plain expired session. Instagram routes these to a
            # /challenge/ URL or shows a checkpoint-specific heading.
            current_url = page.url
            if "/challenge/" in current_url or "/accounts/suspended" in current_url:
                _save_screenshot(page, account, "challenge")
                raise ChallengeRequiredError(
                    f"Account {account} has an active Instagram checkpoint/challenge/restriction. "
                    f"This needs manual resolution in a real browser (see login.py / SETUP.md) — "
                    f"it will not resolve itself on retry."
                )

            _dismiss_if_present(page, "button:has-text('Not Now')")

            report("Opening upload panel...")
            new_post_btn = page.locator("svg[aria-label='New post']").locator("xpath=..")
            new_post_btn.wait_for(state="visible", timeout=15000)
            new_post_btn.click()

            # Current Instagram web UI shows a dropdown (Post / Reel / Story /
            # Live) after clicking the create icon, rather than jumping
            # straight to the file picker. This click is a no-op (with a
            # short timeout) for any UI variant that skips the dropdown and
            # goes straight to the picker instead.
            try:
                post_option = page.locator(
                    "a:has-text('Post'), div[role='button']:has-text('Post')"
                ).first
                post_option.wait_for(state="visible", timeout=6000)
                post_option.click()
            except PWTimeout:
                pass

            file_input = page.locator("input[accept*='video']")
            file_input.wait_for(state="attached", timeout=15000)
            file_input.set_input_files(video_path)

            report("Video uploaded, moving through crop/filter steps...")
            for _ in range(2):
                next_btn = page.locator("div[role='button']:has-text('Next')")
                try:
                    next_btn.wait_for(state="visible", timeout=15000)
                    next_btn.click()
                except PWTimeout:
                    break

            report("Writing caption...")
            caption_box = page.locator("div[aria-label='Write a caption...']")
            caption_box.wait_for(state="visible", timeout=15000)
            caption_box.fill(caption)

            share_btn = page.locator("div[role='button']:has-text('Share')")
            share_btn.wait_for(state="visible", timeout=15000)

            # POINT OF NO RETURN: the flag is set BEFORE calling click(), not
            # after. This matters because click() can itself raise an
            # exception (e.g. Playwright's "execution context destroyed"
            # error, thrown when the click's own navigation/DOM update races
            # the action) even though the click already registered on
            # Instagram's side and the post may have been submitted. If we
            # only set the flag on a *successful return* from click(), that
            # exact race would fall through to the retryable PublishError
            # path below and risk a duplicate post. Setting it first means
            # ANY exception from this point on — including from click()
            # itself — is treated as uncertain, never retried.
            share_clicked = True
            try:
                share_btn.click()
            except Exception as e:
                raise PublishUncertainError(
                    f"Error while clicking Share — outcome unknown, the click may have "
                    f"already registered before this error: {e}. Verify the account "
                    f"manually before resending, to avoid a duplicate post."
                )

            report("Waiting for Instagram to confirm the post...")
            # A single "text=A, text=B" selector string does NOT behave as an OR in
            # Playwright — it's parsed as one combined (and usually invalid) selector.
            # Use separate locators combined with .or_(), plus a DOM-based fallback
            # signal, since the toast text/wording changes across Instagram UI versions.
            confirmed = False
            try:
                toast = page.locator("text=Your reel has been shared").or_(
                    page.locator("text=Post shared")
                ).or_(
                    page.locator("text=shared")
                )
                toast.first.wait_for(state="visible", timeout=90000)
                confirmed = True
            except PWTimeout:
                pass

            if not confirmed:
                try:
                    page.wait_for_selector(
                        "div[aria-label='Write a caption...']", state="detached", timeout=30000
                    )
                    report("Share dialog closed — post likely succeeded, but no confirmation "
                           "toast was seen.")
                    confirmed = True
                except PWTimeout:
                    pass

            if not confirmed:
                # We clicked Share and genuinely don't know what happened.
                # This must NOT be retried automatically.
                _save_screenshot(page, account, "uncertain")
                raise PublishUncertainError(
                    "Share was clicked but no confirmation was seen within the timeout. "
                    "The post may or may not have gone through — check the account manually "
                    "before resending, to avoid a duplicate."
                )

            report("Publish confirmed.")
        except (SessionExpiredError, ChallengeRequiredError, PublishError, PublishUncertainError):
            raise
        except Exception as e:
            # Any OTHER unexpected error (Playwright crash, network drop, etc.)
            # after Share was clicked is just as ambiguous as a confirmation
            # timeout — treat it the same way: uncertain, not retryable.
            _save_screenshot(page, account, "unexpected")
            if share_clicked:
                raise PublishUncertainError(
                    f"Unexpected error after Share was clicked: {e}. Verify the account "
                    f"manually before resending, to avoid a duplicate post."
                )
            raise PublishError(f"Unexpected error before Share was clicked: {e}")


def publish_reel(account: int, video_path: str, caption: str, status_cb=None):
    """Publish with retry on transient, PRE-share PublishError only.
    SessionExpiredError, ChallengeRequiredError, and PublishUncertainError
    are never retried — the first two need a human to resolve manually,
    the third risks a duplicate post."""
    last_err = None
    for attempt in range(1, MAX_RETRIES + 2):  # +2 = at least 1 try + MAX_RETRIES
        try:
            _publish_once(account, video_path, caption, status_cb=status_cb)
            return True
        except SessionExpiredError:
            raise
        except ChallengeRequiredError:
            raise
        except PublishUncertainError:
            raise
        except PublishError as e:
            last_err = e
            logger.warning(f"[account {account}] attempt {attempt} failed (pre-share, safe to retry): {e}")
            if status_cb:
                status_cb(f"Attempt {attempt} failed, retrying..." if attempt <= MAX_RETRIES else "Giving up.")
    raise last_err
