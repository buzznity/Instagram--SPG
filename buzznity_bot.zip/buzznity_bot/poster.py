"""
poster.py — publishes a single reel via the saved Playwright session.
Handles: session-expired detection, popups, retries on transient timeouts.
Does NOT attempt to defeat captchas/challenges or spoof detection signals —
if Instagram throws one of those, this reports failure rather than trying
to bypass it.
"""
import os
import re
import time
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
from config import MAX_RETRIES, LOG_DIR, DEBUG_SCREENSHOTS, RETRY_BACKOFF_SECONDS, PUBLISH_VERIFY_DELAY_SECONDS
from logger import logger
from account_locks import account_lock
import session_store

SCREENSHOT_DIR = os.path.join(LOG_DIR, "screenshots")
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

# JS run inside the page to list every interactive-looking element (buttons,
# links, contenteditable/textarea fields, dialogs) with its visible text,
# aria-label, and tag — purely reading the page's own accessibility tree via
# Playwright's evaluate(), the same thing a person would see by hand in
# DevTools' "Inspect Element". Not a detection-evasion technique of any
# kind — this is read-only introspection to speed up fixing selectors.
_ELEMENT_SCAN_JS = """
() => {
  const sel = "button, [role='button'], a, [contenteditable='true'], textarea, "
            + "input, [role='textbox'], [role='dialog']";
  const collect = (root) => {
    const out = [];
    root.querySelectorAll(sel).forEach((el) => {
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;  // skip hidden elements
      const text = (el.innerText || el.value || "").trim().replace(/\\s+/g, " ").slice(0, 80);
      out.push({
        tag: el.tagName.toLowerCase(),
        role: el.getAttribute("role") || "",
        ariaLabel: el.getAttribute("aria-label") || "",
        placeholder: el.getAttribute("placeholder") || el.getAttribute("aria-placeholder") || "",
        contentEditable: el.getAttribute("contenteditable") || "",
        text: text,
      });
    });
    return out;
  };

  // Modals/dialogs (e.g. "Create new post") are typically appended at the
  // END of the DOM via a React portal, well after all the home-feed
  // content. A flat page-wide scan capped at N items would list feed
  // buttons/links first and cut off before ever reaching the actual modal
  // — which is usually the ONLY thing that matters when debugging a
  // failure. So: scan inside any open dialog/modal-like container FIRST,
  // then append the rest of the page after it.
  const dialogRoots = Array.from(
    document.querySelectorAll("[role='dialog'], [aria-modal='true']")
  );
  let dialogElements = [];
  dialogRoots.forEach((root) => { dialogElements = dialogElements.concat(collect(root)); });

  const pageElements = collect(document);
  const combined = dialogElements.concat(pageElements);
  return {
    inDialog: dialogElements.length,
    elements: combined.slice(0, 150),
  };
}
"""


def _dump_page_elements(page, account, tag):
    """Best-effort structural snapshot of the page at the moment of
    failure: every visible button/link/text-field with its tag, role,
    aria-label, and short visible text — with any open dialog/modal's
    elements listed first, since that's almost always what's relevant.
    Written as a plain text file. Never raises. Returns the saved path,
    or None if it failed."""
    try:
        result = page.evaluate(_ELEMENT_SCAN_JS)
        elements = result["elements"]
        in_dialog = result["inDialog"]
        path = os.path.join(SCREENSHOT_DIR, f"account{account}_{tag}_{int(time.time())}_elements.txt")
        lines = [
            f"Page URL: {page.url}",
            f"Elements found: {len(elements)} ({in_dialog} inside an open dialog/modal, listed first)",
            "",
        ]
        for i, el in enumerate(elements, 1):
            lines.append(
                f"{i}. <{el['tag']}> role={el['role'] or '-'} "
                f"aria-label={el['ariaLabel'] or '-'} "
                f"placeholder={el['placeholder'] or '-'} "
                f"contenteditable={el['contentEditable'] or '-'}\n"
                f"   text: {el['text'] or '(empty)'}"
            )
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        logger.info(f"[account {account}] Saved page element dump: {path}")
        return path
    except Exception as e:
        logger.warning(f"[account {account}] Could not dump page elements: {e}")
        return None


def _save_screenshot(page, account, tag):
    """Best-effort debug screenshot on failure. Never raises — a screenshot
    failure must not mask the real error. Returns the saved path, or None
    if saving failed."""
    try:
        path = os.path.join(SCREENSHOT_DIR, f"account{account}_{tag}_{int(time.time())}.png")
        page.screenshot(path=path)
        logger.info(f"[account {account}] Saved debug screenshot: {path}")
        return path
    except Exception as e:
        logger.warning(f"[account {account}] Could not save screenshot: {e}")
        return None


class SessionExpiredError(Exception):
    """Retryable is irrelevant here — always requires re-login, never retried."""
    pass


class ChallengeRequiredError(Exception):
    """Instagram is showing a checkpoint/suspicious-login challenge, action
    block, or similar restriction — distinct from a plain expired session.
    This needs a human to resolve manually in a real browser (see login.py);
    an automated retry will not fix it and may make Instagram more suspicious."""
    pass


class PublishError(Exception):
    """Something failed BEFORE the Share button was clicked. Safe to retry —
    no post could have been created yet."""
    pass


class PublishUncertainError(Exception):
    """Something failed AFTER the Share button was clicked and we could not
    confirm success or failure. NEVER auto-retried — retrying here risks a
    duplicate post, which is worse than a single failed/uncertain one. This
    is surfaced to a human for manual verification instead."""
    pass


def _dismiss_if_present(page, selector, timeout=3000):
    try:
        el = page.locator(selector)
        el.wait_for(state="visible", timeout=timeout)
        el.click()
        return True
    except PWTimeout:
        return False


def _publish_once(account: int, video_path: str, caption: str, status_cb=None, screenshot_cb=None):
    """One publish attempt. Raises SessionExpiredError or PublishError on failure.
    Blocks (briefly) on the account's lock so the health checker can never open
    the same profile at the same time as a real publish job."""

    def report(msg, percent=None):
        logger.info(f"[account {account}] {msg}")
        if status_cb:
            status_cb(msg, percent)

    if session_store.session_kind(account) is None:
        raise SessionExpiredError(f"No saved session for account {account}.")

    # Blocking acquire (both the intra-process thread lock and the
    # cross-process flock) — publishing takes priority, the health checker
    # or a manual login.py run will simply wait or skip its turn.
    with account_lock(account, blocking=True):
        _publish_locked(account, video_path, caption, report, screenshot_cb)


def _publish_locked(account, video_path, caption, report, screenshot_cb=None):
    with sync_playwright() as p, session_store.open_context(p, account, headless=True) as context:
        # Tracks whether the Share button was actually clicked. Once True, a
        # post may exist on Instagram's side — every failure path after this
        # point must raise PublishUncertainError (never retried), not
        # PublishError (retried), or a retry could create a duplicate post.
        share_clicked = False
        step_count = [0]

        def step(msg, percent=None):
            """Reports status (with a rough progress percent for a Telegram
            progress bar), plus (only when DEBUG_SCREENSHOTS is on) a
            screenshot of every step — not just failures — sent straight to
            Telegram via screenshot_cb so the person can watch each screen
            live, not just find it saved on the VPS afterward."""
            report(msg, percent)
            if DEBUG_SCREENSHOTS:
                step_count[0] += 1
                tag = "step{}_{}".format(step_count[0], msg[:24].replace(" ", "_").replace("...", ""))
                path = _save_screenshot(page, account, tag)
                if path and screenshot_cb:
                    try:
                        screenshot_cb(path, msg)
                    except Exception as e:
                        logger.warning(f"[account {account}] screenshot_cb failed: {e}")

        try:
            page = context.new_page()
            page.goto("https://www.instagram.com/", timeout=30000)

            try:
                page.wait_for_selector(
                    "svg[aria-label='New post'], svg[aria-label='Direct'], input[name='username']",
                    timeout=15000,
                )
            except PWTimeout:
                raise PublishError("Instagram home page never loaded properly (timeout).")

            if page.locator("input[name='username']").is_visible():
                raise SessionExpiredError(f"Session expired for account {account}. Re-run login.py.")

            # Checkpoint / suspicious-login / action-block detection — distinct
            # from a plain expired session. Instagram routes these to a
            # /challenge/ URL or shows a checkpoint-specific heading.
            current_url = page.url
            if "/challenge/" in current_url or "/accounts/suspended" in current_url:
                shot = _save_screenshot(page, account, "challenge")
                err = ChallengeRequiredError(
                    f"Account {account} has an active Instagram checkpoint/challenge/restriction. "
                    f"This needs manual resolution in a real browser (see login.py / SETUP.md) — "
                    f"it will not resolve itself on retry."
                )
                err.screenshot_path = shot
                raise err

            _dismiss_if_present(page, "button:has-text('Not Now')")

            step("Opening upload panel...", 8)
            new_post_btn = page.locator("svg[aria-label='New post']").locator("xpath=..")
            new_post_btn.wait_for(state="visible", timeout=15000)
            new_post_btn.click()

            # Current Instagram web UI shows a dropdown (Post / Live video /
            # Ad) after clicking the create icon, rather than jumping
            # straight to the file picker — confirmed via debug screenshot.
            # Match the exact visible label text (not a tag/role guess,
            # since Instagram's menu items aren't plain <a> elements) and
            # rely on the click event bubbling up to whatever element
            # actually owns the click handler.
            try:
                post_option = page.get_by_text("Post", exact=True).first
                post_option.wait_for(state="visible", timeout=5000)
                post_option.click()
                step("Selected 'Post' from create menu...", 15)
            except PWTimeout:
                pass  # some accounts skip the dropdown entirely

            # There's a brief loading-spinner transition between the "Post"
            # click and the "Create new post" dialog actually finishing its
            # render (seen directly in debug screenshots) — clicking too
            # early can land on a not-yet-interactive button. Wait for a
            # concrete signal (the dialog heading) rather than a blind
            # sleep, then add a short settle buffer since React can finish
            # painting slightly before its click handlers are wired up.
            try:
                page.get_by_text("Create new post", exact=True).wait_for(
                    state="visible", timeout=10000
                )
            except PWTimeout:
                pass  # proceed anyway — some accounts/UI variants may skip this heading
            page.wait_for_timeout(2000)

            # Scope everything to the actual dialog container rather than
            # the whole page. The page has other hidden file inputs
            # elsewhere (profile photo, stories, etc.) — a page-wide
            # selector can silently grab one of THOSE instead of the one
            # inside this dialog, with no error, which is exactly what kept
            # happening. Restricting the search to inside the dialog makes
            # that impossible.
            dialog = page.locator("[role='dialog'], [aria-modal='true']").first
            try:
                dialog.wait_for(state="visible", timeout=5000)
                scope = dialog
            except PWTimeout:
                scope = page  # no dialog container found — fall back to page-wide as a last resort

            uploaded = False
            try:
                with page.expect_file_chooser(timeout=15000) as fc_info:
                    select_btn = scope.get_by_text(re.compile("select from computer", re.I)).first
                    select_btn.wait_for(state="visible", timeout=10000)
                    select_btn.click()
                file_chooser = fc_info.value
                file_chooser.set_files(video_path)
                logger.info(f"[account {account}] Uploaded video via filechooser (Select from computer).")
                uploaded = True
            except Exception as e:
                logger.info(f"[account {account}] filechooser path failed ({e}), trying scoped input.")

            if not uploaded:
                # Fallback: a direct <input type=file>, but SCOPED to the
                # dialog only — never page-wide, to avoid the wrong-input
                # bug above.
                file_input = scope.locator("input[accept*='video']").first
                file_input.wait_for(state="attached", timeout=15000)
                file_input.set_input_files(video_path)
                logger.info(f"[account {account}] Uploaded video via scoped direct input.")

            # Immediate snapshot right after the file is set — before any
            # waiting — to catch a transient error toast/state that might
            # otherwise disappear before the later failure screenshot.
            if DEBUG_SCREENSHOTS:
                _save_screenshot(page, account, "immediately_after_setfiles")
                _dump_page_elements(page, account, "immediately_after_setfiles")

            # Verify the upload actually registered — don't just trust that
            # set_files()/set_input_files() didn't throw. If the dialog is
            # still showing the empty drag-and-drop screen after a generous
            # wait (VPS upload bandwidth to Instagram can be slow for larger
            # files), something is genuinely wrong and continuing further
            # would waste time waiting on a screen that will never appear.
            try:
                page.locator("text=Drag photos and videos here").wait_for(
                    state="hidden", timeout=40000
                )
            except PWTimeout:
                shot = _save_screenshot(page, account, "upload_did_not_register")
                dump = _dump_page_elements(page, account, "upload_did_not_register")
                err = PublishError(
                    "Video file was selected (no error from Playwright) but the upload "
                    "dialog never advanced past the empty drag-and-drop screen even after "
                    "40s — Instagram may be silently rejecting this file, or the upload is "
                    "unusually slow. Check the video file itself (format/size/duration)."
                )
                err.screenshot_path = shot
                err.elements_path = dump
                raise err

            step("Video file selected, uploading...", 25)
            # Give the crop screen a moment to actually finish rendering
            # after the upload registers, same reasoning as the "Create new
            # post" modal above — the next() button can exist in the DOM
            # slightly before it's genuinely ready to be clicked.
            page.wait_for_timeout(2000)

            def _dismiss_reels_notice():
                """The 'Video posts are now shared as reels' interstitial can
                appear at different points depending on the account/session
                (right after upload, mid-crop, or not at all — it's shown
                once per account and never again after that). Safe to call
                repeatedly: a fast no-op every time it isn't currently
                showing, so it doesn't slow down accounts that never see it."""
                try:
                    page.locator("text=shared as reels").wait_for(state="visible", timeout=1200)
                    page.locator("button:has-text('OK')").first.click()
                    step("Dismissed 'shared as reels' info popup.", None)
                    return True
                except PWTimeout:
                    return False

            _dismiss_reels_notice()

            # "Next" can appear as different element types across UI
            # variants (plain div[role='button'] vs. link-styled text — see
            # the same issue already found for "Share"). Also don't assume
            # exactly 2 Next screens — click through however many appear
            # (crop, then edit/filters, occasionally more), stopping as
            # soon as no more "Next" shows up, up to a safety cap.
            next_selector = "div[role='button']:has-text('Next'), a:has-text('Next'), button:has-text('Next')"
            next_count = 0
            for _ in range(4):
                _dismiss_reels_notice()
                next_btn = page.locator(next_selector).first
                try:
                    next_btn.wait_for(state="visible", timeout=8000)
                    next_btn.click()
                    next_count += 1
                    step(f"Clicked 'Next' (screen {next_count})...", min(30 + next_count * 12, 55))
                    # Same settle buffer — the following screen (edit/caption)
                    # can take a moment to fully render after each Next click.
                    page.wait_for_timeout(1500)
                except PWTimeout:
                    break

            # One more check right before the caption step, in case the
            # notice only appears after the final Next click on this
            # account.
            _dismiss_reels_notice()

            step("Looking for caption field...", 60)
            # Confirmed via manual walkthrough screenshots: this account's
            # caption box has no "caption"-labeled aria attribute at all —
            # it's a plain, unlabeled contenteditable field directly under
            # the username. Try the labeled variants first (older UI), then
            # fall back to any contenteditable element in the panel.
            caption_box = None
            for sel in (
                "div[aria-label*='caption' i]",
                "textarea[aria-label*='caption' i]",
                "div[contenteditable='true']",
                "[contenteditable='true']",
                "textarea",
            ):
                candidate = page.locator(sel).first
                try:
                    candidate.wait_for(state="visible", timeout=6000)
                    caption_box = candidate
                    break
                except PWTimeout:
                    continue
            if caption_box is None:
                shot = _save_screenshot(page, account, "no_caption_box")
                dump = _dump_page_elements(page, account, "no_caption_box")
                err = PublishError("Could not locate the caption input field on the share screen.")
                err.screenshot_path = shot
                err.elements_path = dump
                raise err
            caption_box.click()
            caption_box.fill(caption)
            step("Caption entered.", 78)

            # "Share" renders as plain link-styled text in this UI, not
            # necessarily a div[role='button'] — match either.
            share_btn = page.locator("div[role='button']:has-text('Share'), a:has-text('Share')").first
            share_btn.wait_for(state="visible", timeout=15000)
            step("Found 'Share' button, submitting...", 88)
            # Same settle-buffer reasoning as the other steps — an
            # in-progress animation/transition can leave a transient
            # element overlapping Share right as it becomes "visible",
            # which is what caused the click to be misrouted before.
            page.wait_for_timeout(1500)

            # POINT OF NO RETURN: the flag is set BEFORE calling click(), not
            # after. This matters because click() can itself raise an
            # exception (e.g. Playwright's "execution context destroyed"
            # error, thrown when the click's own navigation/DOM update races
            # the action) even though the click already registered on
            # Instagram's side and the post may have been submitted. If we
            # only set the flag on a *successful return* from click(), that
            # exact race would fall through to the retryable PublishError
            # path below and risk a duplicate post. Setting it first means
            # ANY exception from this point on — including from click()
            # itself — is treated as uncertain, never retried.
            share_clicked = True
            try:
                # NOT using force=True here: it was tried in an earlier
                # version to work around a "some element intercepts pointer
                # events" failure, but force=True dispatches the click at
                # the target's coordinates regardless of what's on top —
                # meaning the real browser hit-test can still route the
                # click to that SAME overlapping element instead of Share.
                # That's exactly what happened: it silently hit Instagram's
                # close ("X") button, which opened a "Discard post?"
                # confirmation instead of actually sharing, and the
                # confirmation-detection logic below misread that as
                # success. Fail safely (uncertain) instead of guessing.
                share_btn.click(timeout=15000)
            except Exception as e:
                raise PublishUncertainError(
                    f"Error while clicking Share — outcome unknown, the click may have "
                    f"already registered before this error: {e}. Verify the account "
                    f"manually before resending, to avoid a duplicate post."
                )

            step("Waiting for Instagram to confirm the post...", 93)
            # A single "text=A, text=B" selector string does NOT behave as an OR in
            # Playwright — it's parsed as one combined (and usually invalid) selector.
            # Use separate locators combined with .or_(), plus a DOM-based fallback
            # signal, since the toast text/wording changes across Instagram UI versions.
            confirmed = False
            try:
                toast = page.locator("text=Your reel has been shared").or_(
                    page.locator("text=Post shared")
                ).or_(
                    page.locator("text=shared")
                )
                toast.first.wait_for(state="visible", timeout=90000)
                confirmed = True
            except PWTimeout:
                pass

            # NEGATIVE signal check, before ever trusting the weaker
            # "detached" fallback below: if a "Discard post?" dialog is
            # showing, the click did NOT share anything — it triggered
            # Instagram's leave-without-saving confirmation instead (seen
            # directly in a real run). This must never be read as success.
            if not confirmed:
                try:
                    discard_dialog = page.get_by_text("Discard post?", exact=True)
                    discard_dialog.wait_for(state="visible", timeout=3000)
                    # Click Cancel — stay put, don't actually discard —
                    # since we don't know the true state and want to leave
                    # it exactly as a human would find it for manual review.
                    try:
                        page.get_by_text("Cancel", exact=True).first.click(timeout=5000)
                    except Exception:
                        pass
                    shot = _save_screenshot(page, account, "discard_dialog_appeared")
                    dump = _dump_page_elements(page, account, "discard_dialog_appeared")
                    err = PublishUncertainError(
                        "A 'Discard post?' dialog appeared after clicking Share instead of "
                        "a success confirmation — the click likely landed on the wrong "
                        "element (e.g. a close button) rather than actually sharing. "
                        "Verify the account manually before resending, to avoid a duplicate."
                    )
                    err.screenshot_path = shot
                    err.elements_path = dump
                    raise err
                except PWTimeout:
                    pass  # no discard dialog — proceed to the weaker fallback below

            if not confirmed:
                try:
                    # Re-check via the same locator we already successfully
                    # matched for the caption box (whichever selector that
                    # turned out to be), rather than a hardcoded guess.
                    caption_box.wait_for(state="detached", timeout=30000)
                    step("Share dialog closed — post likely succeeded, but no confirmation "
                           "toast was seen.", 97)
                    confirmed = True
                except PWTimeout:
                    pass

            if not confirmed:
                # We clicked Share and genuinely don't know what happened.
                # This must NOT be retried automatically.
                shot = _save_screenshot(page, account, "uncertain")
                dump = _dump_page_elements(page, account, "uncertain")
                err = PublishUncertainError(
                    "Share was clicked but no confirmation was seen within the timeout. "
                    "The post may or may not have gone through — check the account manually "
                    "before resending, to avoid a duplicate."
                )
                err.screenshot_path = shot
                err.elements_path = dump
                raise err

            step("Publish confirmed.", 100)

            # Final, independent verification — much stronger proof than any
            # toast/DOM heuristic during the compose flow (this is exactly
            # what would have caught the earlier false-positive, where a
            # misrouted click was misread as success). Wait for Instagram to
            # fully process the new post, then visit the account's own
            # profile and screenshot it. Best-effort: sent unconditionally
            # (not gated by DEBUG_SCREENSHOTS) since this is the actual
            # proof-of-publish the person wants to see, not a debug aid —
            # but never fails the whole publish if this step has trouble,
            # since the post itself was already confirmed above.
            try:
                report(
                    f"Waiting {PUBLISH_VERIFY_DELAY_SECONDS}s, then checking your profile "
                    f"to confirm the post is really there...",
                    100,
                )
                page.wait_for_timeout(PUBLISH_VERIFY_DELAY_SECONDS * 1000)
                avatar_img = page.locator("img[alt*='profile picture' i]").first
                avatar_img.wait_for(state="visible", timeout=10000)
                avatar_link = avatar_img.locator("xpath=ancestor::a[1]")
                avatar_link.click()
                page.wait_for_timeout(3000)
                shot = _save_screenshot(page, account, "final_profile_verification")
                if shot and screenshot_cb:
                    screenshot_cb(shot, "✅ Final check — your profile right after posting")
            except Exception as e:
                logger.warning(
                    f"[account {account}] Final profile verification screenshot failed "
                    f"(non-fatal, post was already confirmed above): {e}"
                )

        except (SessionExpiredError, ChallengeRequiredError, PublishError, PublishUncertainError):
            raise
        except Exception as e:
            # Any OTHER unexpected error (Playwright crash, network drop, etc.)
            # after Share was clicked is just as ambiguous as a confirmation
            # timeout — treat it the same way: uncertain, not retryable.
            shot = _save_screenshot(page, account, "unexpected")
            dump = _dump_page_elements(page, account, "unexpected")
            if share_clicked:
                err = PublishUncertainError(
                    f"Unexpected error after Share was clicked: {e}. Verify the account "
                    f"manually before resending, to avoid a duplicate post."
                )
                err.screenshot_path = shot
                err.elements_path = dump
                raise err
            err = PublishError(f"Unexpected error before Share was clicked: {e}")
            err.screenshot_path = shot
            err.elements_path = dump
            raise err


def publish_reel(account: int, video_path: str, caption: str, status_cb=None, screenshot_cb=None):
    """Publish with retry on transient, PRE-share PublishError only.
    SessionExpiredError, ChallengeRequiredError, and PublishUncertainError
    are never retried — the first two need a human to resolve manually,
    the third risks a duplicate post."""
    last_err = None
    for attempt in range(1, MAX_RETRIES + 2):  # +2 = at least 1 try + MAX_RETRIES
        try:
            _publish_once(account, video_path, caption, status_cb=status_cb, screenshot_cb=screenshot_cb)
            return True
        except SessionExpiredError:
            raise
        except ChallengeRequiredError:
            raise
        except PublishUncertainError:
            raise
        except PublishError as e:
            last_err = e
            logger.warning(f"[account {account}] attempt {attempt} failed (pre-share, safe to retry): {e}")
            if attempt <= MAX_RETRIES:
                # A deliberate pause before retrying — not a detection-evasion
                # trick, just not hammering Instagram with back-to-back
                # attempts right after a failure, which is reasonable
                # behavior for any automated client against any service.
                if status_cb:
                    status_cb(f"Attempt {attempt} failed, waiting {RETRY_BACKOFF_SECONDS}s before retrying...")
                time.sleep(RETRY_BACKOFF_SECONDS)
            else:
                if status_cb:
                    status_cb("Giving up.")
    raise last_err
